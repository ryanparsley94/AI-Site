ALTER TABLE supplier_accounts ADD COLUMN IF NOT EXISTS minimum_order numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE supplier_accounts ADD COLUMN IF NOT EXISTS delivery_charge numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE supplier_accounts ADD COLUMN IF NOT EXISTS free_delivery_threshold numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE supplier_accounts ADD COLUMN IF NOT EXISTS delivery_lead_time_days integer;

CREATE TABLE IF NOT EXISTS goods_receipts (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  purchase_order_id integer NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  delivery_id integer REFERENCES deliveries(id) ON DELETE SET NULL,
  reference text,
  received_at timestamptz NOT NULL DEFAULT now(),
  received_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS goods_receipts_company_po_idx ON goods_receipts(company_id, purchase_order_id);

CREATE TABLE IF NOT EXISTS goods_receipt_items (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  goods_receipt_id integer NOT NULL REFERENCES goods_receipts(id) ON DELETE CASCADE,
  purchase_order_item_id integer NOT NULL REFERENCES purchase_order_items(id) ON DELETE RESTRICT,
  quantity_received numeric(12,3) NOT NULL,
  condition text NOT NULL DEFAULT 'accepted',
  notes text
);
CREATE INDEX IF NOT EXISTS goods_receipt_items_company_poitem_idx ON goods_receipt_items(company_id, purchase_order_item_id);

CREATE TABLE IF NOT EXISTS supplier_invoices (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  supplier_id integer NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
  supplier_account_id integer REFERENCES supplier_accounts(id) ON DELETE SET NULL,
  purchase_order_id integer REFERENCES purchase_orders(id) ON DELETE SET NULL,
  invoice_number text NOT NULL,
  invoice_date timestamptz NOT NULL,
  due_date timestamptz,
  subtotal numeric(12,2) NOT NULL DEFAULT 0,
  vat numeric(12,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'received',
  match_summary jsonb NOT NULL DEFAULT '{}'::jsonb,
  notes text,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS supplier_invoices_company_po_idx ON supplier_invoices(company_id, purchase_order_id);
CREATE UNIQUE INDEX IF NOT EXISTS supplier_invoices_company_supplier_number_uidx ON supplier_invoices(company_id, supplier_id, invoice_number);

CREATE TABLE IF NOT EXISTS supplier_invoice_items (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  supplier_invoice_id integer NOT NULL REFERENCES supplier_invoices(id) ON DELETE CASCADE,
  purchase_order_item_id integer REFERENCES purchase_order_items(id) ON DELETE SET NULL,
  description text NOT NULL,
  quantity numeric(12,3) NOT NULL,
  unit_cost numeric(12,4) NOT NULL,
  line_total numeric(12,2) NOT NULL
);
CREATE INDEX IF NOT EXISTS supplier_invoice_items_company_invoice_idx ON supplier_invoice_items(company_id, supplier_invoice_id);
