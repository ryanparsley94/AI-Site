CREATE TABLE IF NOT EXISTS site_material_requests (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  requested_by_worker_id integer REFERENCES workforce_profiles(id) ON DELETE SET NULL,
  requested_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  product_id integer REFERENCES procurement_products(id) ON DELETE SET NULL,
  description text NOT NULL,
  quantity numeric(12,3) NOT NULL,
  unit text NOT NULL DEFAULT 'each',
  needed_by timestamptz,
  urgency text NOT NULL DEFAULT 'normal',
  reason text,
  status text NOT NULL DEFAULT 'requested',
  procurement_reference text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS site_material_requests_company_job_status_idx ON site_material_requests(company_id,job_id,status);

CREATE TABLE IF NOT EXISTS site_issues (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  reported_by_worker_id integer REFERENCES workforce_profiles(id) ON DELETE SET NULL,
  reported_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  issue_type text NOT NULL DEFAULT 'site',
  title text NOT NULL,
  description text NOT NULL,
  severity text NOT NULL DEFAULT 'medium',
  potential_variation text NOT NULL DEFAULT 'no',
  estimated_impact numeric(12,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'open',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);
CREATE INDEX IF NOT EXISTS site_issues_company_job_status_idx ON site_issues(company_id,job_id,status);
