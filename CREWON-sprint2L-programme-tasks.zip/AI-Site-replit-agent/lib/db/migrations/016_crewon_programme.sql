CREATE TABLE IF NOT EXISTS project_milestones (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  target_date timestamptz,
  completed_at timestamptz,
  status text NOT NULL DEFAULT 'planned',
  sort_order integer NOT NULL DEFAULT 0,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS project_milestones_company_job_idx ON project_milestones(company_id,job_id,sort_order);

CREATE TABLE IF NOT EXISTS project_tasks (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  milestone_id integer REFERENCES project_milestones(id) ON DELETE SET NULL,
  parent_task_id integer,
  title text NOT NULL,
  description text,
  trade text,
  status text NOT NULL DEFAULT 'not_started',
  planned_start timestamptz,
  planned_finish timestamptz,
  actual_start timestamptz,
  actual_finish timestamptz,
  planned_hours numeric(10,2) NOT NULL DEFAULT 0,
  progress_percent numeric(6,2) NOT NULL DEFAULT 0,
  critical_path boolean NOT NULL DEFAULT false,
  blocker_reason text,
  sort_order integer NOT NULL DEFAULT 0,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS project_tasks_company_job_status_idx ON project_tasks(company_id,job_id,status);

CREATE TABLE IF NOT EXISTS project_task_dependencies (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  task_id integer NOT NULL REFERENCES project_tasks(id) ON DELETE CASCADE,
  depends_on_task_id integer NOT NULL REFERENCES project_tasks(id) ON DELETE CASCADE,
  dependency_type text NOT NULL DEFAULT 'finish_to_start',
  lag_days integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS project_task_dependencies_job_idx ON project_task_dependencies(company_id,job_id);

CREATE TABLE IF NOT EXISTS project_task_assignments (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  task_id integer NOT NULL REFERENCES project_tasks(id) ON DELETE CASCADE,
  worker_id integer NOT NULL REFERENCES workforce_profiles(id) ON DELETE CASCADE,
  planned_hours numeric(10,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS project_task_assignments_job_task_idx ON project_task_assignments(company_id,job_id,task_id);
