-- CREWON Procurement foundation: supplier trade accounts, product catalogue,
-- customer-specific pricing, RFQs, purchase orders and deliveries.

CREATE TABLE IF NOT EXISTS suppliers (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name text NOT NULL,
  phone text,
  email text,
  website text,
  address text,
  preferred boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'active',
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS suppliers_company_idx ON suppliers(company_id);
CREATE INDEX IF NOT EXISTS suppliers_company_name_idx ON suppliers(company_id, name);

CREATE TABLE IF NOT EXISTS supplier_accounts (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  supplier_id integer NOT NULL REFERENCES suppliers(id) ON DELETE CASCADE,
  account_name text NOT NULL,
  account_number text,
  branch text,
  pricing_method text NOT NULL DEFAULT 'manual',
  currency text NOT NULL DEFAULT 'GBP',
  delivery_terms text,
  is_default boolean NOT NULL DEFAULT false,
  last_synced_at timestamptz,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS supplier_accounts_company_idx ON supplier_accounts(company_id);
CREATE INDEX IF NOT EXISTS supplier_accounts_supplier_idx ON supplier_accounts(supplier_id);

CREATE TABLE IF NOT EXISTS procurement_products (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  sku text,
  name text NOT NULL,
  description text,
  category text,
  manufacturer text,
  manufacturer_part_number text,
  unit text NOT NULL DEFAULT 'each',
  default_waste_percent numeric(6,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS procurement_products_company_idx ON procurement_products(company_id);
CREATE INDEX IF NOT EXISTS procurement_products_company_name_idx ON procurement_products(company_id, name);

CREATE TABLE IF NOT EXISTS supplier_prices (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  product_id integer NOT NULL REFERENCES procurement_products(id) ON DELETE CASCADE,
  supplier_id integer NOT NULL REFERENCES suppliers(id) ON DELETE CASCADE,
  supplier_account_id integer REFERENCES supplier_accounts(id) ON DELETE SET NULL,
  supplier_sku text,
  supplier_description text,
  unit_cost numeric(12,4) NOT NULL,
  quantity_break numeric(12,3) NOT NULL DEFAULT 1,
  availability text,
  lead_time_days integer,
  source text NOT NULL DEFAULT 'manual',
  valid_from timestamptz NOT NULL DEFAULT now(),
  valid_to timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS supplier_prices_company_product_idx ON supplier_prices(company_id, product_id);
CREATE INDEX IF NOT EXISTS supplier_prices_company_supplier_idx ON supplier_prices(company_id, supplier_id);
CREATE INDEX IF NOT EXISTS supplier_prices_product_valid_idx ON supplier_prices(product_id, valid_from DESC);

CREATE TABLE IF NOT EXISTS rfqs (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer REFERENCES jobs(id) ON DELETE SET NULL,
  quote_id integer REFERENCES quotes(id) ON DELETE SET NULL,
  title text NOT NULL,
  status text NOT NULL DEFAULT 'draft',
  due_at timestamptz,
  notes text,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS rfqs_company_status_idx ON rfqs(company_id, status);

CREATE TABLE IF NOT EXISTS rfq_items (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  rfq_id integer NOT NULL REFERENCES rfqs(id) ON DELETE CASCADE,
  product_id integer REFERENCES procurement_products(id) ON DELETE SET NULL,
  description text NOT NULL,
  quantity numeric(12,3) NOT NULL,
  unit text NOT NULL DEFAULT 'each'
);
CREATE INDEX IF NOT EXISTS rfq_items_rfq_idx ON rfq_items(rfq_id);

CREATE TABLE IF NOT EXISTS rfq_responses (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  rfq_id integer NOT NULL REFERENCES rfqs(id) ON DELETE CASCADE,
  supplier_id integer NOT NULL REFERENCES suppliers(id) ON DELETE CASCADE,
  supplier_account_id integer REFERENCES supplier_accounts(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'received',
  reference text,
  subtotal numeric(12,2),
  vat numeric(12,2),
  total numeric(12,2),
  notes text,
  received_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS rfq_responses_rfq_idx ON rfq_responses(rfq_id);

CREATE TABLE IF NOT EXISTS purchase_orders (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  po_number text NOT NULL,
  supplier_id integer NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
  supplier_account_id integer REFERENCES supplier_accounts(id) ON DELETE SET NULL,
  job_id integer REFERENCES jobs(id) ON DELETE SET NULL,
  quote_id integer REFERENCES quotes(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'draft',
  delivery_address text,
  required_by timestamptz,
  subtotal numeric(12,2) NOT NULL DEFAULT 0,
  vat numeric(12,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  notes text,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  approved_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  approved_at timestamptz,
  ordered_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS purchase_orders_company_number_uidx ON purchase_orders(company_id, po_number);
CREATE INDEX IF NOT EXISTS purchase_orders_company_status_idx ON purchase_orders(company_id, status);
CREATE INDEX IF NOT EXISTS purchase_orders_job_idx ON purchase_orders(job_id);

CREATE TABLE IF NOT EXISTS purchase_order_items (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  purchase_order_id integer NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  product_id integer REFERENCES procurement_products(id) ON DELETE SET NULL,
  description text NOT NULL,
  supplier_sku text,
  quantity numeric(12,3) NOT NULL,
  unit text NOT NULL DEFAULT 'each',
  unit_cost numeric(12,4) NOT NULL,
  line_total numeric(12,2) NOT NULL
);
CREATE INDEX IF NOT EXISTS purchase_order_items_po_idx ON purchase_order_items(purchase_order_id);

CREATE TABLE IF NOT EXISTS deliveries (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  purchase_order_id integer REFERENCES purchase_orders(id) ON DELETE SET NULL,
  supplier_id integer REFERENCES suppliers(id) ON DELETE SET NULL,
  job_id integer REFERENCES jobs(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'scheduled',
  reference text,
  scheduled_at timestamptz,
  received_at timestamptz,
  delivery_address text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS deliveries_company_status_idx ON deliveries(company_id, status);
CREATE INDEX IF NOT EXISTS deliveries_job_idx ON deliveries(job_id);
