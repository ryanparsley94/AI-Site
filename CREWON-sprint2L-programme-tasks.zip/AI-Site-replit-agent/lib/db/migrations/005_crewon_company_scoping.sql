-- CREWON foundation: make business data company-scoped.
-- This migration upgrades the original single-company prototype safely.
-- Existing unscoped rows are assigned to the earliest company record.

DO $$
DECLARE
  default_company_id integer;
BEGIN
  SELECT id INTO default_company_id FROM companies ORDER BY id LIMIT 1;

  IF default_company_id IS NULL THEN
    INSERT INTO companies (name, phone, timezone)
    VALUES ('Your Company', '00000000000', 'Europe/London')
    RETURNING id INTO default_company_id;
  END IF;

  ALTER TABLE assistants       ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE contacts         ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE calls            ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE certificates     ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE conversations    ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE email_threads    ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE integrations     ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE invoices         ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE quotes           ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE marketing_drafts ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE jobs             ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE tasks            ADD COLUMN IF NOT EXISTS company_id integer;

  UPDATE assistants       SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE contacts         SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE calls            SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE certificates     SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE conversations    SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE email_threads    SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE integrations     SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE invoices         SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE quotes           SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE marketing_drafts SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE jobs             SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE tasks            SET company_id = default_company_id WHERE company_id IS NULL;

  ALTER TABLE assistants       ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE contacts         ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE calls            ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE certificates     ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE conversations    ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE email_threads    ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE integrations     ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE invoices         ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE quotes           ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE marketing_drafts ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE jobs             ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE tasks            ALTER COLUMN company_id SET NOT NULL;

  -- Add foreign keys if they do not already exist. Constraint names are explicit
  -- so repeated deployments can safely detect them.
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='assistants_company_id_fkey') THEN
    ALTER TABLE assistants ADD CONSTRAINT assistants_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='contacts_company_id_fkey') THEN
    ALTER TABLE contacts ADD CONSTRAINT contacts_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='calls_company_id_fkey') THEN
    ALTER TABLE calls ADD CONSTRAINT calls_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='certificates_company_id_fkey') THEN
    ALTER TABLE certificates ADD CONSTRAINT certificates_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='conversations_company_id_fkey') THEN
    ALTER TABLE conversations ADD CONSTRAINT conversations_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='email_threads_company_id_fkey') THEN
    ALTER TABLE email_threads ADD CONSTRAINT email_threads_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='integrations_company_id_fkey') THEN
    ALTER TABLE integrations ADD CONSTRAINT integrations_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='invoices_company_id_fkey') THEN
    ALTER TABLE invoices ADD CONSTRAINT invoices_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='quotes_company_id_fkey') THEN
    ALTER TABLE quotes ADD CONSTRAINT quotes_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='marketing_drafts_company_id_fkey') THEN
    ALTER TABLE marketing_drafts ADD CONSTRAINT marketing_drafts_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='jobs_company_id_fkey') THEN
    ALTER TABLE jobs ADD CONSTRAINT jobs_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='tasks_company_id_fkey') THEN
    ALTER TABLE tasks ADD CONSTRAINT tasks_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
END $$;

-- The old schema allowed only one provider globally. Drop that uniqueness and
-- replace it with one provider connection per company.
ALTER TABLE integrations DROP CONSTRAINT IF EXISTS integrations_provider_unique;
CREATE UNIQUE INDEX IF NOT EXISTS integrations_company_provider_uidx
  ON integrations(company_id, provider);

CREATE INDEX IF NOT EXISTS assistants_company_idx       ON assistants(company_id);
CREATE INDEX IF NOT EXISTS contacts_company_idx         ON contacts(company_id);
CREATE INDEX IF NOT EXISTS calls_company_idx            ON calls(company_id);
CREATE INDEX IF NOT EXISTS certificates_company_idx     ON certificates(company_id);
CREATE INDEX IF NOT EXISTS conversations_company_idx    ON conversations(company_id);
CREATE INDEX IF NOT EXISTS email_threads_company_idx    ON email_threads(company_id);
CREATE INDEX IF NOT EXISTS invoices_company_idx         ON invoices(company_id);
CREATE INDEX IF NOT EXISTS quotes_company_idx           ON quotes(company_id);
CREATE INDEX IF NOT EXISTS marketing_drafts_company_idx ON marketing_drafts(company_id);
CREATE INDEX IF NOT EXISTS jobs_company_idx             ON jobs(company_id);
CREATE INDEX IF NOT EXISTS tasks_company_idx            ON tasks(company_id);

-- Apply CREWON's default electric-blue accent only where the original prototype
-- still has the old construction-orange defaults. Existing customer custom colours are preserved.
UPDATE companies SET quote_accent_color = '#1687ff' WHERE quote_accent_color = '#f97316';
UPDATE companies SET widget_color = '#1687ff' WHERE widget_color = '#f97316';
