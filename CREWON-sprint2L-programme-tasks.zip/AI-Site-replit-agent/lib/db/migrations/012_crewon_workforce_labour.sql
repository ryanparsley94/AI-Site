CREATE TABLE IF NOT EXISTS workforce_profiles (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id integer REFERENCES users(id) ON DELETE SET NULL,
  name text NOT NULL,
  worker_type text NOT NULL DEFAULT 'employee',
  trade text,
  phone text,
  email text,
  cost_rate numeric(10,2) NOT NULL DEFAULT 0,
  charge_rate numeric(10,2) NOT NULL DEFAULT 0,
  overtime_multiplier numeric(6,2) NOT NULL DEFAULT 1.5,
  active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS workforce_profiles_company_user_uidx ON workforce_profiles(company_id,user_id);

CREATE TABLE IF NOT EXISTS workforce_allocations (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  worker_id integer NOT NULL REFERENCES workforce_profiles(id) ON DELETE CASCADE,
  role text,
  planned_hours numeric(10,2) NOT NULL DEFAULT 0,
  planned_cost numeric(12,2) NOT NULL DEFAULT 0,
  start_date timestamptz,
  end_date timestamptz,
  status text NOT NULL DEFAULT 'allocated',
  notes text,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS workforce_allocations_company_job_idx ON workforce_allocations(company_id,job_id);

CREATE TABLE IF NOT EXISTS workforce_time_entries (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  worker_id integer NOT NULL REFERENCES workforce_profiles(id) ON DELETE CASCADE,
  allocation_id integer REFERENCES workforce_allocations(id) ON DELETE SET NULL,
  work_date timestamptz NOT NULL,
  started_at timestamptz,
  ended_at timestamptz,
  regular_hours numeric(10,2) NOT NULL DEFAULT 0,
  overtime_hours numeric(10,2) NOT NULL DEFAULT 0,
  cost_rate numeric(10,2) NOT NULL DEFAULT 0,
  overtime_multiplier numeric(6,2) NOT NULL DEFAULT 1.5,
  total_cost numeric(12,2) NOT NULL DEFAULT 0,
  notes text,
  status text NOT NULL DEFAULT 'submitted',
  submitted_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  approved_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  approved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS workforce_time_entries_company_job_status_idx ON workforce_time_entries(company_id,job_id,status);
CREATE INDEX IF NOT EXISTS workforce_time_entries_worker_date_idx ON workforce_time_entries(worker_id,work_date);

CREATE TABLE IF NOT EXISTS site_progress_updates (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  worker_id integer REFERENCES workforce_profiles(id) ON DELETE SET NULL,
  progress_percent numeric(6,2) NOT NULL DEFAULT 0,
  summary text NOT NULL,
  blockers text,
  submitted_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS site_progress_updates_company_job_idx ON site_progress_updates(company_id,job_id,created_at DESC);
