CREATE TABLE IF NOT EXISTS project_commercial_snapshots (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  quote_id integer REFERENCES quotes(id) ON DELETE SET NULL,
  contract_value numeric(14,2) NOT NULL DEFAULT 0,
  baseline_cost numeric(14,2) NOT NULL DEFAULT 0,
  baseline_margin numeric(14,2) NOT NULL DEFAULT 0,
  baseline_margin_percent numeric(7,2) NOT NULL DEFAULT 0,
  committed_procurement numeric(14,2) NOT NULL DEFAULT 0,
  invoiced_procurement numeric(14,2) NOT NULL DEFAULT 0,
  procurement_variance numeric(14,2) NOT NULL DEFAULT 0,
  approved_variations numeric(14,2) NOT NULL DEFAULT 0,
  pending_variations numeric(14,2) NOT NULL DEFAULT 0,
  labour_actual numeric(14,2) NOT NULL DEFAULT 0,
  other_actual numeric(14,2) NOT NULL DEFAULT 0,
  forecast_final_cost numeric(14,2) NOT NULL DEFAULT 0,
  forecast_revenue numeric(14,2) NOT NULL DEFAULT 0,
  forecast_margin numeric(14,2) NOT NULL DEFAULT 0,
  forecast_margin_percent numeric(7,2) NOT NULL DEFAULT 0,
  margin_movement numeric(14,2) NOT NULL DEFAULT 0,
  margin_movement_points numeric(7,2) NOT NULL DEFAULT 0,
  risk_level text NOT NULL DEFAULT 'low',
  drivers jsonb NOT NULL DEFAULT '[]'::jsonb,
  calculated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS project_commercial_snapshots_company_job_idx ON project_commercial_snapshots(company_id, job_id, calculated_at DESC);

CREATE TABLE IF NOT EXISTS project_cost_adjustments (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  type text NOT NULL,
  description text NOT NULL,
  amount numeric(14,2) NOT NULL,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS project_cost_adjustments_company_job_idx ON project_cost_adjustments(company_id, job_id);

CREATE TABLE IF NOT EXISTS project_variations (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  reference text,
  description text NOT NULL,
  value numeric(14,2) NOT NULL,
  estimated_cost numeric(14,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending',
  client_approval_reference text,
  approved_at timestamptz,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS project_variations_company_job_idx ON project_variations(company_id, job_id);

CREATE TABLE IF NOT EXISTS margin_protection_alerts (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  snapshot_id integer REFERENCES project_commercial_snapshots(id) ON DELETE SET NULL,
  severity text NOT NULL,
  category text NOT NULL,
  title text NOT NULL,
  explanation text NOT NULL,
  recommended_action text,
  financial_impact numeric(14,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'open',
  acknowledged_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  acknowledged_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS margin_protection_alerts_company_job_status_idx ON margin_protection_alerts(company_id, job_id, status);
