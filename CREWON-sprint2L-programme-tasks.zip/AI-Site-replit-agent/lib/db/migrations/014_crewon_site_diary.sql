CREATE TABLE IF NOT EXISTS site_diaries (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  worker_id integer REFERENCES workforce_profiles(id) ON DELETE SET NULL,
  submitted_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  source text NOT NULL DEFAULT 'voice_transcript',
  transcript text NOT NULL,
  summary text,
  weather_note text,
  progress_percent numeric(6,2),
  structured_output jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'draft',
  created_at timestamptz NOT NULL DEFAULT now(),
  committed_at timestamptz
);
CREATE INDEX IF NOT EXISTS site_diaries_company_job_idx ON site_diaries(company_id,job_id,created_at DESC);

CREATE TABLE IF NOT EXISTS site_evidence (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  diary_id integer REFERENCES site_diaries(id) ON DELETE CASCADE,
  evidence_type text NOT NULL DEFAULT 'photo',
  file_name text,
  mime_type text NOT NULL DEFAULT 'image/jpeg',
  data_url text NOT NULL,
  caption text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS site_evidence_company_job_idx ON site_evidence(company_id,job_id,created_at DESC);
