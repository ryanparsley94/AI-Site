CREATE TABLE IF NOT EXISTS material_requirements (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  quote_id integer REFERENCES quotes(id) ON DELETE CASCADE,
  job_id integer REFERENCES jobs(id) ON DELETE SET NULL,
  product_id integer REFERENCES procurement_products(id) ON DELETE SET NULL,
  description text NOT NULL,
  quantity numeric(12,3) NOT NULL,
  unit text NOT NULL DEFAULT 'each',
  waste_percent numeric(6,2) NOT NULL DEFAULT 0,
  required_by timestamptz,
  status text NOT NULL DEFAULT 'required',
  source text NOT NULL DEFAULT 'quote',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS material_requirements_company_quote_idx ON material_requirements(company_id, quote_id);
CREATE INDEX IF NOT EXISTS material_requirements_company_job_idx ON material_requirements(company_id, job_id);

CREATE TABLE IF NOT EXISTS procurement_authority (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  mode text NOT NULL DEFAULT 'assist',
  auto_approve_purchase_limit numeric(12,2) NOT NULL DEFAULT 0,
  preferred_suppliers_only boolean NOT NULL DEFAULT false,
  require_known_price_source boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS procurement_authority_company_uidx ON procurement_authority(company_id);

CREATE TABLE IF NOT EXISTS procurement_plans (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  quote_id integer REFERENCES quotes(id) ON DELETE CASCADE,
  job_id integer REFERENCES jobs(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'draft',
  strategy text NOT NULL DEFAULT 'best_line_price',
  estimated_subtotal numeric(12,2) NOT NULL DEFAULT 0,
  savings_vs_single_supplier numeric(12,2) NOT NULL DEFAULT 0,
  missing_item_count integer NOT NULL DEFAULT 0,
  recommendation jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS procurement_plans_company_quote_idx ON procurement_plans(company_id, quote_id);
