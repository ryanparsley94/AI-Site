CREATE TABLE IF NOT EXISTS margin_recovery_actions (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  snapshot_id integer REFERENCES project_commercial_snapshots(id) ON DELETE SET NULL,
  category text NOT NULL,
  title text NOT NULL,
  action text NOT NULL,
  estimated_recovery numeric(14,2) NOT NULL DEFAULT 0,
  authority_mode text NOT NULL DEFAULT 'assist',
  status text NOT NULL DEFAULT 'proposed',
  requires_human_approval boolean NOT NULL DEFAULT true,
  approved_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  approved_at timestamptz,
  actioned_at timestamptz,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS margin_recovery_actions_company_job_idx ON margin_recovery_actions(company_id,job_id,status);
