ALTER TABLE site_evidence ADD COLUMN IF NOT EXISTS entity_type text;
ALTER TABLE site_evidence ADD COLUMN IF NOT EXISTS entity_id integer;
CREATE INDEX IF NOT EXISTS site_evidence_entity_idx ON site_evidence(company_id,job_id,entity_type,entity_id);
