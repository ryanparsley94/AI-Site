import { pgTable, text, serial, timestamp, integer, numeric, jsonb } from "drizzle-orm/pg-core";
import { companiesTable } from "./companies";
import { jobsTable } from "./jobs";
import { usersTable } from "./users";
import { workforceProfilesTable } from "./workforce";

export const siteDiariesTable = pgTable("site_diaries", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  workerId: integer("worker_id").references(() => workforceProfilesTable.id, { onDelete: "set null" }),
  submittedByUserId: integer("submitted_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  source: text("source").notNull().default("voice_transcript"), // voice_transcript | typed | imported
  transcript: text("transcript").notNull(),
  summary: text("summary"),
  weatherNote: text("weather_note"),
  progressPercent: numeric("progress_percent", { precision: 6, scale: 2 }),
  structuredOutput: jsonb("structured_output").notNull().default({}),
  status: text("status").notNull().default("draft"), // draft | reviewed | committed
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  committedAt: timestamp("committed_at", { withTimezone: true }),
});

export const siteEvidenceTable = pgTable("site_evidence", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  diaryId: integer("diary_id").references(() => siteDiariesTable.id, { onDelete: "cascade" }),
  entityType: text("entity_type"), // site_diary | site_issue | delivery | progress | general
  entityId: integer("entity_id"),
  evidenceType: text("evidence_type").notNull().default("photo"),
  fileName: text("file_name"),
  mimeType: text("mime_type").notNull().default("image/jpeg"),
  dataUrl: text("data_url").notNull(),
  caption: text("caption"),
  metadata: jsonb("metadata").notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
