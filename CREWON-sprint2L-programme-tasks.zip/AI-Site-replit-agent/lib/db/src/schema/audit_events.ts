import { pgTable, text, serial, timestamp, integer, jsonb, index } from "drizzle-orm/pg-core";
import { companiesTable } from "./companies";
import { usersTable } from "./users";

/** Immutable business/security audit trail for CREWON actions and approvals. */
export const auditEventsTable = pgTable("audit_events", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  userId: integer("user_id").references(() => usersTable.id, { onDelete: "set null" }),
  actorType: text("actor_type").notNull().default("user"), // user | ai | system | integration
  actorLabel: text("actor_label"),
  action: text("action").notNull(),
  entityType: text("entity_type"),
  entityId: text("entity_id"),
  metadata: jsonb("metadata").notNull().default({}),
  ipAddress: text("ip_address"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("audit_events_company_created_idx").on(table.companyId, table.createdAt),
  index("audit_events_entity_idx").on(table.entityType, table.entityId),
]);

export type AuditEvent = typeof auditEventsTable.$inferSelect;
