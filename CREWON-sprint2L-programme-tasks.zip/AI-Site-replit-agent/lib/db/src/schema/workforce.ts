import { pgTable, text, serial, timestamp, integer, numeric, boolean, jsonb, uniqueIndex } from "drizzle-orm/pg-core";
import { companiesTable } from "./companies";
import { jobsTable } from "./jobs";
import { usersTable } from "./users";

/** People who can be allocated to site work. A worker may be a CREWON user or an external subcontractor. */
export const workforceProfilesTable = pgTable("workforce_profiles", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  userId: integer("user_id").references(() => usersTable.id, { onDelete: "set null" }),
  name: text("name").notNull(),
  workerType: text("worker_type").notNull().default("employee"), // employee | subcontractor
  trade: text("trade"),
  phone: text("phone"),
  email: text("email"),
  costRate: numeric("cost_rate", { precision: 10, scale: 2 }).notNull().default("0"),
  chargeRate: numeric("charge_rate", { precision: 10, scale: 2 }).notNull().default("0"),
  overtimeMultiplier: numeric("overtime_multiplier", { precision: 6, scale: 2 }).notNull().default("1.5"),
  active: boolean("active").notNull().default(true),
  metadata: jsonb("metadata").notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (table) => [
  uniqueIndex("workforce_profiles_company_user_uidx").on(table.companyId, table.userId),
]);

export const workforceAllocationsTable = pgTable("workforce_allocations", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  workerId: integer("worker_id").notNull().references(() => workforceProfilesTable.id, { onDelete: "cascade" }),
  role: text("role"),
  plannedHours: numeric("planned_hours", { precision: 10, scale: 2 }).notNull().default("0"),
  plannedCost: numeric("planned_cost", { precision: 12, scale: 2 }).notNull().default("0"),
  startDate: timestamp("start_date", { withTimezone: true }),
  endDate: timestamp("end_date", { withTimezone: true }),
  status: text("status").notNull().default("allocated"), // allocated | active | complete | cancelled
  notes: text("notes"),
  createdByUserId: integer("created_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const workforceTimeEntriesTable = pgTable("workforce_time_entries", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  workerId: integer("worker_id").notNull().references(() => workforceProfilesTable.id, { onDelete: "cascade" }),
  allocationId: integer("allocation_id").references(() => workforceAllocationsTable.id, { onDelete: "set null" }),
  workDate: timestamp("work_date", { withTimezone: true }).notNull(),
  startedAt: timestamp("started_at", { withTimezone: true }),
  endedAt: timestamp("ended_at", { withTimezone: true }),
  regularHours: numeric("regular_hours", { precision: 10, scale: 2 }).notNull().default("0"),
  overtimeHours: numeric("overtime_hours", { precision: 10, scale: 2 }).notNull().default("0"),
  costRate: numeric("cost_rate", { precision: 10, scale: 2 }).notNull().default("0"),
  overtimeMultiplier: numeric("overtime_multiplier", { precision: 6, scale: 2 }).notNull().default("1.5"),
  totalCost: numeric("total_cost", { precision: 12, scale: 2 }).notNull().default("0"),
  notes: text("notes"),
  status: text("status").notNull().default("submitted"), // draft | submitted | approved | rejected
  submittedByUserId: integer("submitted_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  approvedByUserId: integer("approved_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  approvedAt: timestamp("approved_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const siteProgressUpdatesTable = pgTable("site_progress_updates", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  workerId: integer("worker_id").references(() => workforceProfilesTable.id, { onDelete: "set null" }),
  progressPercent: numeric("progress_percent", { precision: 6, scale: 2 }).notNull().default("0"),
  summary: text("summary").notNull(),
  blockers: text("blockers"),
  submittedByUserId: integer("submitted_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
