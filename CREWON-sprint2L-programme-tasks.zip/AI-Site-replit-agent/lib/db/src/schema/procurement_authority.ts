import { pgTable, text, serial, timestamp, integer, numeric, boolean, jsonb, uniqueIndex } from "drizzle-orm/pg-core";
import { companiesTable } from "./companies";
import { quotesTable } from "./quotes";
import { jobsTable } from "./jobs";
import { procurementProductsTable, suppliersTable } from "./procurement";
import { usersTable } from "./users";

/** Structured bill-of-material requirements bridging Estimate/Quote -> Procurement. */
export const materialRequirementsTable = pgTable("material_requirements", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  quoteId: integer("quote_id").references(() => quotesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").references(() => jobsTable.id, { onDelete: "set null" }),
  productId: integer("product_id").references(() => procurementProductsTable.id, { onDelete: "set null" }),
  description: text("description").notNull(),
  quantity: numeric("quantity", { precision: 12, scale: 3 }).notNull(),
  unit: text("unit").notNull().default("each"),
  wastePercent: numeric("waste_percent", { precision: 6, scale: 2 }).notNull().default("0"),
  requiredBy: timestamp("required_by", { withTimezone: true }),
  status: text("status").notNull().default("required"), // required | planned | ordered | received | cancelled
  source: text("source").notNull().default("quote"),
  metadata: jsonb("metadata").notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

/** Company-controlled autonomy rules. V1 starts with purchasing approval thresholds. */
export const procurementAuthorityTable = pgTable("procurement_authority", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  mode: text("mode").notNull().default("assist"), // observe | assist | operate
  autoApprovePurchaseLimit: numeric("auto_approve_purchase_limit", { precision: 12, scale: 2 }).notNull().default("0"),
  preferredSuppliersOnly: boolean("preferred_suppliers_only").notNull().default(false),
  requireKnownPriceSource: boolean("require_known_price_source").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (table) => [
  uniqueIndex("procurement_authority_company_uidx").on(table.companyId),
]);

/** A persisted recommendation makes AI/human purchasing decisions reviewable and auditable. */
export const procurementPlansTable = pgTable("procurement_plans", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  quoteId: integer("quote_id").references(() => quotesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").references(() => jobsTable.id, { onDelete: "set null" }),
  status: text("status").notNull().default("draft"), // draft | ready | converted | superseded
  strategy: text("strategy").notNull().default("best_line_price"),
  estimatedSubtotal: numeric("estimated_subtotal", { precision: 12, scale: 2 }).notNull().default("0"),
  savingsVsSingleSupplier: numeric("savings_vs_single_supplier", { precision: 12, scale: 2 }).notNull().default("0"),
  missingItemCount: integer("missing_item_count").notNull().default(0),
  recommendation: jsonb("recommendation").notNull().default({}),
  createdByUserId: integer("created_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});
