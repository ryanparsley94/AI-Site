import { pgTable, text, serial, timestamp, integer, numeric, jsonb } from "drizzle-orm/pg-core";
import { companiesTable } from "./companies";
import { jobsTable } from "./jobs";
import { usersTable } from "./users";
import { workforceProfilesTable } from "./workforce";
import { procurementProductsTable } from "./procurement";

export const siteMaterialRequestsTable = pgTable("site_material_requests", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  requestedByWorkerId: integer("requested_by_worker_id").references(() => workforceProfilesTable.id, { onDelete: "set null" }),
  requestedByUserId: integer("requested_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  productId: integer("product_id").references(() => procurementProductsTable.id, { onDelete: "set null" }),
  description: text("description").notNull(),
  quantity: numeric("quantity", { precision: 12, scale: 3 }).notNull(),
  unit: text("unit").notNull().default("each"),
  neededBy: timestamp("needed_by", { withTimezone: true }),
  urgency: text("urgency").notNull().default("normal"), // low | normal | urgent | critical
  reason: text("reason"),
  status: text("status").notNull().default("requested"), // requested | approved | ordered | delivered | declined
  procurementReference: text("procurement_reference"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const siteIssuesTable = pgTable("site_issues", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  reportedByWorkerId: integer("reported_by_worker_id").references(() => workforceProfilesTable.id, { onDelete: "set null" }),
  reportedByUserId: integer("reported_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  issueType: text("issue_type").notNull().default("site"), // site | client_instruction | delay | quality | commercial | safety
  title: text("title").notNull(),
  description: text("description").notNull(),
  severity: text("severity").notNull().default("medium"), // low | medium | high | critical
  potentialVariation: text("potential_variation").notNull().default("no"), // no | review | yes
  estimatedImpact: numeric("estimated_impact", { precision: 12, scale: 2 }).notNull().default("0"),
  status: text("status").notNull().default("open"), // open | reviewing | resolved | escalated
  metadata: jsonb("metadata").notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
});
