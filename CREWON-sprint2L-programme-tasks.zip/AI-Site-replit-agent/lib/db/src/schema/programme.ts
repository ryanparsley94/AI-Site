import { pgTable, text, serial, timestamp, integer, numeric, boolean, jsonb } from "drizzle-orm/pg-core";
import { companiesTable } from "./companies";
import { jobsTable } from "./jobs";
import { usersTable } from "./users";
import { workforceProfilesTable } from "./workforce";

export const projectMilestonesTable = pgTable("project_milestones", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description"),
  targetDate: timestamp("target_date", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  status: text("status").notNull().default("planned"), // planned | at_risk | complete | missed
  sortOrder: integer("sort_order").notNull().default(0),
  createdByUserId: integer("created_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const projectTasksTable = pgTable("project_tasks", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  milestoneId: integer("milestone_id").references(() => projectMilestonesTable.id, { onDelete: "set null" }),
  parentTaskId: integer("parent_task_id"),
  title: text("title").notNull(),
  description: text("description"),
  trade: text("trade"),
  status: text("status").notNull().default("not_started"), // not_started | ready | in_progress | blocked | complete
  plannedStart: timestamp("planned_start", { withTimezone: true }),
  plannedFinish: timestamp("planned_finish", { withTimezone: true }),
  actualStart: timestamp("actual_start", { withTimezone: true }),
  actualFinish: timestamp("actual_finish", { withTimezone: true }),
  plannedHours: numeric("planned_hours", { precision: 10, scale: 2 }).notNull().default("0"),
  progressPercent: numeric("progress_percent", { precision: 6, scale: 2 }).notNull().default("0"),
  criticalPath: boolean("critical_path").notNull().default(false),
  blockerReason: text("blocker_reason"),
  sortOrder: integer("sort_order").notNull().default(0),
  metadata: jsonb("metadata").notNull().default({}),
  createdByUserId: integer("created_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const projectTaskDependenciesTable = pgTable("project_task_dependencies", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  taskId: integer("task_id").notNull().references(() => projectTasksTable.id, { onDelete: "cascade" }),
  dependsOnTaskId: integer("depends_on_task_id").notNull().references(() => projectTasksTable.id, { onDelete: "cascade" }),
  dependencyType: text("dependency_type").notNull().default("finish_to_start"),
  lagDays: integer("lag_days").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const projectTaskAssignmentsTable = pgTable("project_task_assignments", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  taskId: integer("task_id").notNull().references(() => projectTasksTable.id, { onDelete: "cascade" }),
  workerId: integer("worker_id").notNull().references(() => workforceProfilesTable.id, { onDelete: "cascade" }),
  plannedHours: numeric("planned_hours", { precision: 10, scale: 2 }).notNull().default("0"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
