import { pgTable, text, serial, timestamp, integer, numeric, boolean, jsonb } from "drizzle-orm/pg-core";
import { companiesTable } from "./companies";
import { jobsTable } from "./jobs";
import { quotesTable } from "./quotes";
import { usersTable } from "./users";

export const suppliersTable = pgTable("suppliers", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email"),
  website: text("website"),
  address: text("address"),
  preferred: boolean("preferred").notNull().default(false),
  status: text("status").notNull().default("active"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const supplierAccountsTable = pgTable("supplier_accounts", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  supplierId: integer("supplier_id").notNull().references(() => suppliersTable.id, { onDelete: "cascade" }),
  accountName: text("account_name").notNull(),
  accountNumber: text("account_number"),
  branch: text("branch"),
  pricingMethod: text("pricing_method").notNull().default("manual"),
  currency: text("currency").notNull().default("GBP"),
  deliveryTerms: text("delivery_terms"),
  minimumOrder: numeric("minimum_order", { precision: 12, scale: 2 }).notNull().default("0"),
  deliveryCharge: numeric("delivery_charge", { precision: 12, scale: 2 }).notNull().default("0"),
  freeDeliveryThreshold: numeric("free_delivery_threshold", { precision: 12, scale: 2 }).notNull().default("0"),
  deliveryLeadTimeDays: integer("delivery_lead_time_days"),
  isDefault: boolean("is_default").notNull().default(false),
  lastSyncedAt: timestamp("last_synced_at", { withTimezone: true }),
  metadata: jsonb("metadata").notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const procurementProductsTable = pgTable("procurement_products", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  sku: text("sku"),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category"),
  manufacturer: text("manufacturer"),
  manufacturerPartNumber: text("manufacturer_part_number"),
  unit: text("unit").notNull().default("each"),
  defaultWastePercent: numeric("default_waste_percent", { precision: 6, scale: 2 }).notNull().default("0"),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const supplierPricesTable = pgTable("supplier_prices", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  productId: integer("product_id").notNull().references(() => procurementProductsTable.id, { onDelete: "cascade" }),
  supplierId: integer("supplier_id").notNull().references(() => suppliersTable.id, { onDelete: "cascade" }),
  supplierAccountId: integer("supplier_account_id").references(() => supplierAccountsTable.id, { onDelete: "set null" }),
  supplierSku: text("supplier_sku"),
  supplierDescription: text("supplier_description"),
  unitCost: numeric("unit_cost", { precision: 12, scale: 4 }).notNull(),
  quantityBreak: numeric("quantity_break", { precision: 12, scale: 3 }).notNull().default("1"),
  availability: text("availability"),
  leadTimeDays: integer("lead_time_days"),
  source: text("source").notNull().default("manual"),
  validFrom: timestamp("valid_from", { withTimezone: true }).notNull().defaultNow(),
  validTo: timestamp("valid_to", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const rfqsTable = pgTable("rfqs", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").references(() => jobsTable.id, { onDelete: "set null" }),
  quoteId: integer("quote_id").references(() => quotesTable.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  status: text("status").notNull().default("draft"),
  dueAt: timestamp("due_at", { withTimezone: true }),
  notes: text("notes"),
  createdByUserId: integer("created_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const rfqItemsTable = pgTable("rfq_items", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  rfqId: integer("rfq_id").notNull().references(() => rfqsTable.id, { onDelete: "cascade" }),
  productId: integer("product_id").references(() => procurementProductsTable.id, { onDelete: "set null" }),
  description: text("description").notNull(),
  quantity: numeric("quantity", { precision: 12, scale: 3 }).notNull(),
  unit: text("unit").notNull().default("each"),
});

export const rfqResponsesTable = pgTable("rfq_responses", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  rfqId: integer("rfq_id").notNull().references(() => rfqsTable.id, { onDelete: "cascade" }),
  supplierId: integer("supplier_id").notNull().references(() => suppliersTable.id, { onDelete: "cascade" }),
  supplierAccountId: integer("supplier_account_id").references(() => supplierAccountsTable.id, { onDelete: "set null" }),
  status: text("status").notNull().default("received"),
  reference: text("reference"),
  subtotal: numeric("subtotal", { precision: 12, scale: 2 }),
  vat: numeric("vat", { precision: 12, scale: 2 }),
  total: numeric("total", { precision: 12, scale: 2 }),
  notes: text("notes"),
  receivedAt: timestamp("received_at", { withTimezone: true }).notNull().defaultNow(),
});

export const purchaseOrdersTable = pgTable("purchase_orders", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  poNumber: text("po_number").notNull(),
  supplierId: integer("supplier_id").notNull().references(() => suppliersTable.id, { onDelete: "restrict" }),
  supplierAccountId: integer("supplier_account_id").references(() => supplierAccountsTable.id, { onDelete: "set null" }),
  jobId: integer("job_id").references(() => jobsTable.id, { onDelete: "set null" }),
  quoteId: integer("quote_id").references(() => quotesTable.id, { onDelete: "set null" }),
  status: text("status").notNull().default("draft"),
  deliveryAddress: text("delivery_address"),
  requiredBy: timestamp("required_by", { withTimezone: true }),
  subtotal: numeric("subtotal", { precision: 12, scale: 2 }).notNull().default("0"),
  vat: numeric("vat", { precision: 12, scale: 2 }).notNull().default("0"),
  total: numeric("total", { precision: 12, scale: 2 }).notNull().default("0"),
  notes: text("notes"),
  createdByUserId: integer("created_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  approvedByUserId: integer("approved_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  approvedAt: timestamp("approved_at", { withTimezone: true }),
  orderedAt: timestamp("ordered_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const purchaseOrderItemsTable = pgTable("purchase_order_items", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  purchaseOrderId: integer("purchase_order_id").notNull().references(() => purchaseOrdersTable.id, { onDelete: "cascade" }),
  productId: integer("product_id").references(() => procurementProductsTable.id, { onDelete: "set null" }),
  description: text("description").notNull(),
  supplierSku: text("supplier_sku"),
  quantity: numeric("quantity", { precision: 12, scale: 3 }).notNull(),
  unit: text("unit").notNull().default("each"),
  unitCost: numeric("unit_cost", { precision: 12, scale: 4 }).notNull(),
  lineTotal: numeric("line_total", { precision: 12, scale: 2 }).notNull(),
});

export const deliveriesTable = pgTable("deliveries", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  purchaseOrderId: integer("purchase_order_id").references(() => purchaseOrdersTable.id, { onDelete: "set null" }),
  supplierId: integer("supplier_id").references(() => suppliersTable.id, { onDelete: "set null" }),
  jobId: integer("job_id").references(() => jobsTable.id, { onDelete: "set null" }),
  status: text("status").notNull().default("scheduled"),
  reference: text("reference"),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }),
  receivedAt: timestamp("received_at", { withTimezone: true }),
  deliveryAddress: text("delivery_address"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});


/** Line-level goods receipt records support PO -> delivery -> invoice three-way matching. */
export const goodsReceiptsTable = pgTable("goods_receipts", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  purchaseOrderId: integer("purchase_order_id").notNull().references(() => purchaseOrdersTable.id, { onDelete: "cascade" }),
  deliveryId: integer("delivery_id").references(() => deliveriesTable.id, { onDelete: "set null" }),
  reference: text("reference"),
  receivedAt: timestamp("received_at", { withTimezone: true }).notNull().defaultNow(),
  receivedByUserId: integer("received_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const goodsReceiptItemsTable = pgTable("goods_receipt_items", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  goodsReceiptId: integer("goods_receipt_id").notNull().references(() => goodsReceiptsTable.id, { onDelete: "cascade" }),
  purchaseOrderItemId: integer("purchase_order_item_id").notNull().references(() => purchaseOrderItemsTable.id, { onDelete: "restrict" }),
  quantityReceived: numeric("quantity_received", { precision: 12, scale: 3 }).notNull(),
  condition: text("condition").notNull().default("accepted"), // accepted | damaged | rejected
  notes: text("notes"),
});

/** Supplier invoices remain operational procurement records until exported/synced to accounting. */
export const supplierInvoicesTable = pgTable("supplier_invoices", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  supplierId: integer("supplier_id").notNull().references(() => suppliersTable.id, { onDelete: "restrict" }),
  supplierAccountId: integer("supplier_account_id").references(() => supplierAccountsTable.id, { onDelete: "set null" }),
  purchaseOrderId: integer("purchase_order_id").references(() => purchaseOrdersTable.id, { onDelete: "set null" }),
  invoiceNumber: text("invoice_number").notNull(),
  invoiceDate: timestamp("invoice_date", { withTimezone: true }).notNull(),
  dueDate: timestamp("due_date", { withTimezone: true }),
  subtotal: numeric("subtotal", { precision: 12, scale: 2 }).notNull().default("0"),
  vat: numeric("vat", { precision: 12, scale: 2 }).notNull().default("0"),
  total: numeric("total", { precision: 12, scale: 2 }).notNull().default("0"),
  status: text("status").notNull().default("received"), // received | matched | variance | approved | exported
  matchSummary: jsonb("match_summary").notNull().default({}),
  notes: text("notes"),
  createdByUserId: integer("created_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const supplierInvoiceItemsTable = pgTable("supplier_invoice_items", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  supplierInvoiceId: integer("supplier_invoice_id").notNull().references(() => supplierInvoicesTable.id, { onDelete: "cascade" }),
  purchaseOrderItemId: integer("purchase_order_item_id").references(() => purchaseOrderItemsTable.id, { onDelete: "set null" }),
  description: text("description").notNull(),
  quantity: numeric("quantity", { precision: 12, scale: 3 }).notNull(),
  unitCost: numeric("unit_cost", { precision: 12, scale: 4 }).notNull(),
  lineTotal: numeric("line_total", { precision: 12, scale: 2 }).notNull(),
});
