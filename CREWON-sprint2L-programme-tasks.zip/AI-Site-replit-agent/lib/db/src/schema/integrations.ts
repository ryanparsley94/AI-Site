import { pgTable, text, serial, timestamp, jsonb, integer, uniqueIndex } from "drizzle-orm/pg-core";
import { companiesTable } from "./companies";

export const integrationsTable = pgTable("integrations", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  provider: text("provider").notNull(), // 'google' | 'quickbooks' | 'xero'
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  metadata: jsonb("metadata"), // e.g. QB realm ID, Xero tenant ID
  connectedAt: timestamp("connected_at", { withTimezone: true }).notNull().defaultNow(),
  lastSyncAt: timestamp("last_sync_at", { withTimezone: true }),
}, (table) => [
  uniqueIndex("integrations_company_provider_uidx").on(table.companyId, table.provider),
]);

export type Integration = typeof integrationsTable.$inferSelect;
