import { pgTable, text, serial, timestamp, integer, numeric, jsonb, boolean } from "drizzle-orm/pg-core";
import { companiesTable } from "./companies";
import { jobsTable } from "./jobs";
import { quotesTable } from "./quotes";
import { usersTable } from "./users";

export const projectCommercialSnapshotsTable = pgTable("project_commercial_snapshots", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  quoteId: integer("quote_id").references(() => quotesTable.id, { onDelete: "set null" }),
  contractValue: numeric("contract_value", { precision: 14, scale: 2 }).notNull().default("0"),
  baselineCost: numeric("baseline_cost", { precision: 14, scale: 2 }).notNull().default("0"),
  baselineMargin: numeric("baseline_margin", { precision: 14, scale: 2 }).notNull().default("0"),
  baselineMarginPercent: numeric("baseline_margin_percent", { precision: 7, scale: 2 }).notNull().default("0"),
  committedProcurement: numeric("committed_procurement", { precision: 14, scale: 2 }).notNull().default("0"),
  invoicedProcurement: numeric("invoiced_procurement", { precision: 14, scale: 2 }).notNull().default("0"),
  procurementVariance: numeric("procurement_variance", { precision: 14, scale: 2 }).notNull().default("0"),
  approvedVariations: numeric("approved_variations", { precision: 14, scale: 2 }).notNull().default("0"),
  pendingVariations: numeric("pending_variations", { precision: 14, scale: 2 }).notNull().default("0"),
  labourActual: numeric("labour_actual", { precision: 14, scale: 2 }).notNull().default("0"),
  otherActual: numeric("other_actual", { precision: 14, scale: 2 }).notNull().default("0"),
  forecastFinalCost: numeric("forecast_final_cost", { precision: 14, scale: 2 }).notNull().default("0"),
  forecastRevenue: numeric("forecast_revenue", { precision: 14, scale: 2 }).notNull().default("0"),
  forecastMargin: numeric("forecast_margin", { precision: 14, scale: 2 }).notNull().default("0"),
  forecastMarginPercent: numeric("forecast_margin_percent", { precision: 7, scale: 2 }).notNull().default("0"),
  marginMovement: numeric("margin_movement", { precision: 14, scale: 2 }).notNull().default("0"),
  marginMovementPoints: numeric("margin_movement_points", { precision: 7, scale: 2 }).notNull().default("0"),
  riskLevel: text("risk_level").notNull().default("low"),
  drivers: jsonb("drivers").notNull().default([]),
  calculatedAt: timestamp("calculated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const projectCostAdjustmentsTable = pgTable("project_cost_adjustments", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  type: text("type").notNull(), // labour_actual | other_actual | forecast_cost
  description: text("description").notNull(),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull().defaultNow(),
  createdByUserId: integer("created_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  metadata: jsonb("metadata").notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const projectVariationsTable = pgTable("project_variations", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  reference: text("reference"),
  description: text("description").notNull(),
  value: numeric("value", { precision: 14, scale: 2 }).notNull(),
  estimatedCost: numeric("estimated_cost", { precision: 14, scale: 2 }).notNull().default("0"),
  status: text("status").notNull().default("pending"), // pending | approved | rejected
  clientApprovalReference: text("client_approval_reference"),
  approvedAt: timestamp("approved_at", { withTimezone: true }),
  createdByUserId: integer("created_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const marginProtectionAlertsTable = pgTable("margin_protection_alerts", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  snapshotId: integer("snapshot_id").references(() => projectCommercialSnapshotsTable.id, { onDelete: "set null" }),
  severity: text("severity").notNull(),
  category: text("category").notNull(),
  title: text("title").notNull(),
  explanation: text("explanation").notNull(),
  recommendedAction: text("recommended_action"),
  financialImpact: numeric("financial_impact", { precision: 14, scale: 2 }).notNull().default("0"),
  status: text("status").notNull().default("open"),
  acknowledgedByUserId: integer("acknowledged_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  acknowledgedAt: timestamp("acknowledged_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});


export const marginRecoveryActionsTable = pgTable("margin_recovery_actions", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  jobId: integer("job_id").notNull().references(() => jobsTable.id, { onDelete: "cascade" }),
  snapshotId: integer("snapshot_id").references(() => projectCommercialSnapshotsTable.id, { onDelete: "set null" }),
  category: text("category").notNull(),
  title: text("title").notNull(),
  action: text("action").notNull(),
  estimatedRecovery: numeric("estimated_recovery", { precision: 14, scale: 2 }).notNull().default("0"),
  authorityMode: text("authority_mode").notNull().default("assist"),
  status: text("status").notNull().default("proposed"), // proposed | approved | actioned | dismissed
  requiresHumanApproval: boolean("requires_human_approval").notNull().default(true),
  approvedByUserId: integer("approved_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  approvedAt: timestamp("approved_at", { withTimezone: true }),
  actionedAt: timestamp("actioned_at", { withTimezone: true }),
  metadata: jsonb("metadata").notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
