import { pgTable, text, serial, timestamp, integer, uniqueIndex, jsonb } from "drizzle-orm/pg-core";
import { companiesTable } from "./companies";

/**
 * CREWON identity foundation.
 *
 * Authentication is still using the legacy bootstrap admin password while the
 * commercial login/onboarding UI is built. These tables are the target model
 * for multi-user, multi-company access and can be populated incrementally.
 */
export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  passwordHash: text("password_hash"),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const companyMembersTable = pgTable("company_members", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companiesTable.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  role: text("role").notNull().default("operative"),
  permissions: jsonb("permissions").notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (table) => [
  uniqueIndex("company_members_company_user_uidx").on(table.companyId, table.userId),
]);

export type User = typeof usersTable.$inferSelect;
export type CompanyMember = typeof companyMembersTable.$inferSelect;
