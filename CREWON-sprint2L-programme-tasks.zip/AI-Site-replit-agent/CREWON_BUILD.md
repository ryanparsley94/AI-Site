# CREWON build status

Working product: **CREWON — Your AI workforce. Always on.**

This repository is an evolution of the original Replit BuildAI prototype. Sprint 1 deliberately focuses on making the existing product safer and structurally ready for a multi-company SaaS before adding autonomous procurement and project-management features.

## Sprint 1 implemented

### Security and authentication
- Protected dashboard/management routes now require a signed session.
- Bootstrap login is rate-limited and validates the password before touching tenant data.
- Session tokens are signed, company-bound and timestamped with server-side expiry checks.
- First real owner-account flow added (`/api/auth/bootstrap-owner`).
- Real user login added (`/api/auth/user-login`) using scrypt password hashing.
- Company membership is re-checked on protected requests so revoked users lose access immediately.
- Browser-origin checks added to reduce CSRF/cross-origin risk. Public widget/support endpoints remain intentionally embeddable.
- OAuth state is signed, expires after 10 minutes and is bound to the current company.
- OAuth access/refresh tokens are encrypted at rest with AES-256-GCM (legacy plaintext can still be read during migration).
- Protected mutations produce best-effort immutable audit events.

### Multi-company foundation
- Added `users`, `company_members` and `audit_events` tables.
- Added mandatory `company_id` ownership to core business tables.
- Integration uniqueness changed from global provider uniqueness to `(company_id, provider)`.
- Core API reads/writes are company scoped.
- Existing single-company data is safely backfilled to the first/default company by the idempotent startup migration.

### Deployment-safe migrations
- Deployment-critical migrations are bundled into the API build in `src/lib/startup-migrations.ts`.
- Migrations execute transactionally before the HTTP server accepts traffic.
- Source SQL copies remain in `lib/db/migrations/004_crewon_identity_audit.sql` and `005_crewon_company_scoping.sql` for review/history.

### Product/brand conversion
- Visible BuildAI branding changed to CREWON across web, mobile and API copy.
- Core brand palette moved from construction orange to CREWON electric blue (`#1687FF`).
- Landing proposition changed to **Your AI Workforce. Always On.**
- Unsupported claims such as blanket “GDPR compliant / UK servers” were removed and replaced with accurate pre-launch wording.
- UK terminology/formatting improved in estimating and certificates.
- US-style “Lien Waiver” UI changed to a UK-oriented Final Account acknowledgement while retaining the internal API type for compatibility.

### Estimating/procurement safety
- The existing “price search” endpoint is explicitly labelled internally as a benchmark estimate, not live supplier pricing.
- It must not claim access to negotiated wholesaler prices until real supplier integrations exist.
- Call-to-material extraction now prefers UK metric units and can return no materials rather than inventing a list from a vague call.

## Important environment variables

Required:
- `DATABASE_URL`
- `PORT`
- `SESSION_SECRET` — transitional bootstrap/admin secret; use a long random value
- `OAUTH_TOKEN_SECRET` — separate long random key recommended; falls back to `SESSION_SECRET` only for compatibility

For a separate web frontend origin:
- `CREWON_APP_ORIGINS` — comma-separated exact origins, e.g. `https://app.crewon.co.uk,https://staging.crewon.co.uk`

Integration variables remain provider-specific (QuickBooks/Xero/Google/Resend etc.).

## First upgraded launch flow

1. Start the upgraded API. Bundled idempotent migrations run automatically.
2. On the CREWON login screen choose **Setting up this CREWON workspace for the first time?**
3. Enter the existing server setup password (`SESSION_SECRET`).
4. Create the first named owner account with email and a 12+ character password.
5. The browser receives a real user/company session and normal future sign-ins use email + password.

The bootstrap password remains available only as a migration/recovery path for now. A later sprint should replace it with a formal account-recovery/admin process.

## Known V1 limitations / do not misrepresent

- Inbound email currently routes to the bootstrap/default company because per-company inbound aliases have not yet been built.
- The wholesaler/material endpoint does **not** yet have live account pricing.
- Real telephony provider orchestration still needs production integration/testing.
- Roles are stored and enforced at membership validity level, but fine-grained route permissions are not yet fully applied.
- A shared/distributed rate-limit store is required before horizontally scaling the API.
- The final isolated CREWON logo asset still needs to replace the old `logo-mark.png` file; current generated branding is a concept board, not a production SVG.

## Validation performed in this environment

- Source/static review of tenant scoping and protected route placement.
- TypeScript parser pass on modified server files: no syntax/parser diagnostics found.
- TypeScript parser pass on the new auth UI: no syntax/parser diagnostics found.

A full dependency-aware `pnpm typecheck`/build could not be run in this sandbox because the uploaded ZIP does not include `node_modules`, `pnpm` is not installed, and internet access is disabled. **Run the normal workspace typecheck/build in Replit/GitHub CI before production deployment.**

## Next build priorities

1. Apply fine-grained permissions to individual read/write routes and add per-member overrides UI.
2. Add SMS/WhatsApp/web-chat adapters to the Unified Inbox conversation model.
3. Procurement data model: suppliers, accounts, catalogues, products, price history, RFQs, purchase orders and deliveries.
4. Real supplier pricing connectors/imports, beginning with UK trade use cases.
5. Sales opportunities/pipeline model and lead-rescue workflow.
6. Project budgets + actual costs + variation workflow + Margin Protection Engine.
7. CREWON agent/orchestration layer with OBSERVE / ASSIST / OPERATE authority policies.
8. Command Centre intelligence and owner briefing.

## Sprint 2A implemented — team access + unified inbox

### Team roles and invitations
- Added CREWON role presets: owner/director, office manager, estimator, project manager, site supervisor, operative/engineer and finance/bookkeeper.
- Added server-side permission helper with role defaults plus per-member overrides ready for later granular controls.
- Added company-scoped team management API for member listing, role changes and removal.
- Added expiring, cryptographically random team invitation tokens stored only as SHA-256 hashes.
- Added public invitation acceptance flow that creates the user/membership and issues a company-bound session.
- Added Team & Permissions web screen and secure invitation acceptance screen.
- Ownership changes are restricted to owners/bootstrap admin; the final owner cannot be silently demoted.
- V1 invite delivery is intentionally a copyable secure link until per-tenant transactional email is wired.

### Unified Inbox V1
- Added a company-scoped `/api/inbox` aggregation endpoint normalising phone calls and email threads into one work queue.
- Added channel/search filtering and attention counts.
- Added the Unified Inbox web screen and promoted it into the main CREWON navigation.
- Existing call/email detail tools remain available behind the unified queue.
- Architecture is deliberately ready for SMS, WhatsApp and web-chat channels next.

### Validation
- TypeScript parser/transpile checks passed for all files changed in Sprint 2A.
- A full dependency-aware workspace build still needs to run in the deployment environment/CI before release.

## Sprint 2B — Procurement foundation (17 Aug 2026)

Implemented the first CREWON Procurement data and workflow layer.

### Added
- Company-scoped suppliers and preferred-supplier records.
- Multiple trade accounts/branches per supplier, including pricing route (`manual`, `import`, future `api`, or `rfq`).
- Canonical company product catalogue, ready for AI take-off/product matching later.
- Supplier/account-specific price history with source, availability, lead time and quantity break.
- Batch price-ingestion endpoint so CSV/catalogue/API connectors can feed the same trusted price store.
- Basket comparison endpoint that can compare a bill of materials against recorded supplier prices, show line-by-line alternatives, split-basket cost and full-basket single-supplier options.
- RFQs, RFQ items and supplier response recording for suppliers without APIs.
- Purchase orders and PO line items with approval/order/receipt lifecycle states.
- Deliveries linked to purchase orders, suppliers and future jobs/projects.
- Procurement permissions added to CREWON team roles.
- Procurement web workspace with Suppliers, Products & Prices, RFQs, Purchase Orders and Deliveries tabs.
- Runtime startup migration plus auditable SQL migration `007_crewon_procurement.sql`.

### Important product rule
CREWON now has a first-class place to store attributable supplier pricing. AI-estimated retail/web prices must not be presented as a contractor's live trade-account price. Future wholesaler connectors should write into `supplier_prices` with a source and timestamp.

### Next procurement work
1. Product matching/import wizard for wholesaler CSVs and supplier quotation PDFs.
2. Real supplier connector framework (API/auth/sync status per trade account).
3. Build estimate/BOM -> Procurement comparison workflow.
4. Company approval thresholds and CREWON Authority rules for PO creation/order placement.
5. Part-delivery, back-order and goods-received detail at line-item level.
6. Supplier invoice/PO/delivery three-way matching and variance alerts.
7. Site-supervisor material request flow from mobile -> purchasing approval/order.
8. Delivery cost/minimum-order logic so cheapest line price is not incorrectly treated as cheapest basket.


## Sprint 2C — Estimate/BOM + CREWON Authority (17 Aug 2026)

Implemented the first end-to-end bridge from estimating into controlled purchasing.

### Estimate / BOM -> Procurement
- Added structured `material_requirements` so quote materials become auditable procurement requirements rather than remaining only JSON inside a quote.
- Quote materials can link directly by product ID or match the CREWON catalogue by exact product/SKU.
- Product waste percentages are applied when the procurement requirement is created.
- Added persisted `procurement_plans` so supplier recommendations can be reviewed later rather than existing only as a transient AI response.
- Planning compares attributable supplier/account price records, respects quantity breaks, and can optionally restrict recommendations to preferred suppliers.
- Shows best-line basket cost, complete single-supplier alternatives, missing/unpriced lines, and estimated saving.
- A ready plan can be converted into supplier-grouped purchase orders.

### CREWON Authority — purchasing
- Added company-level `observe`, `assist`, and `operate` modes.
- Added automatic purchase approval threshold (inc VAT).
- Added preferred-supplier-only and attributable-price controls.
- In `operate` mode, plan-generated POs at/below the configured limit can be auto-approved; all others are created as `approval_required`.
- Plan creation, authority changes and PO conversion are written to the CREWON audit trail.
- Added Procurement UI tabs for **BOM Planner** and **Authority**.

### Next
1. Fuzzy/AI-assisted product matching with mandatory human confirmation for uncertain matches.
2. Delivery charge, minimum order, lead-time and preferred-supplier weighting in basket optimisation.
3. Goods received at PO-line level and back-order handling.
4. Supplier invoice -> PO -> delivery three-way matching.
5. Site-supervisor material requests from mobile.
6. Real wholesaler connector framework and first supplier integration.


## Sprint 2D — Procurement Control & Margin Protection (17 Aug 2026)

Built the next procurement-control layer on top of Sprint 2C.

### Smarter material matching
- Added deterministic fuzzy catalogue matching using normalised product names/descriptions and manufacturer part numbers.
- High-confidence matches can be linked automatically; lower-confidence matches remain suggestions for a human to confirm.
- Added endpoints for unresolved material requirements and explicit human match confirmation.
- Match decisions are auditable.

### Landed-cost supplier optimisation
- Supplier trade accounts now support minimum order value, standard delivery charge, free-delivery threshold and typical delivery lead time.
- Basket planning now considers delivery/minimum-order rules instead of choosing the cheapest line in isolation.
- Added a delivery-aware consolidation optimiser that can move lines between suppliers where doing so lowers total landed cost.
- Pricing provenance rules prevent CREWON autonomous purchasing from relying on AI/benchmark/unknown prices when attributable pricing is required.
- Plan-generated purchase orders include supplier delivery charges in committed project cost.

### Goods received
- Added line-level goods receipts linked to PO and optional delivery.
- Supports accepted, damaged and rejected quantities.
- CREWON prevents cumulative accepted quantities from exceeding ordered quantities.
- PO status updates automatically to part-received / received based on actual accepted goods.
- Delivery can close automatically when the linked PO is fully received.

### Supplier invoices & three-way matching
- Added operational supplier-invoice records and invoice lines.
- Invoice can be created from a PO as a starting point; later OCR/email/API extraction can populate the same model.
- CREWON now performs PO ↔ goods received ↔ supplier invoice three-way matching.
- It flags quantity discrepancies, goods invoiced before receipt, unit-price changes, line-value variances, unlinked invoice lines and invoice-total vs PO-total mismatches.
- Match results persist as `matched` or `variance`, with a detailed issue list and audit event.

### Procurement UI
- Added **Receiving** and **Supplier Invoices** tabs.
- Trade-account forms now capture minimum order, delivery fee, free-delivery threshold and lead time.
- Three-way match results/variances surface directly in the procurement workspace.

### Next procurement milestones
1. Supplier invoice ingestion from email/PDF with AI extraction and human confirmation.
2. Site-supervisor/mobile material requests feeding purchasing.
3. Back-order and partial-delivery allocation by project.
4. First real UK wholesaler connector/data-feed implementation.
5. Accounting sync for approved/matched supplier bills.
6. Procurement variance -> live Project Margin Protection feed.


## Sprint 2E — Margin Protection (17 Aug 2026)

### Live project commercial model
- Added persistent commercial snapshots by project.
- Tracks contract/forecast revenue, baseline cost/margin, committed procurement, supplier invoices,
  procurement variance, labour/other cost pressure, approved/pending variations, forecast final cost,
  forecast margin and margin-point movement.
- Adds CREWON risk classification: low / medium / high / critical.
- Stores ranked margin drivers so CREWON explains *why* the margin moved.

### Commercial interventions
- CREWON generates margin alerts when forecast margin materially deteriorates.
- Pending variations are flagged because they are excluded from forecast revenue until approved.
- Supplier invoice overspend is surfaced as a commercial intervention.
- Each alert includes a recommended next action and financial impact.

### Cost & variation controls
- Added project cost-pressure records for labour actuals, other actuals and forecast cost adjustments.
- Added project variations with pending / approved / rejected workflow.
- Recalculates the commercial position immediately after cost or variation changes.

### Margin Protection command centre
- New navigation item and dedicated project view.
- Shows baseline vs projected margin, margin movement, forecast final cost, procurement commitments,
  supplier invoices, pending variations, ranked drivers and CREWON interventions.
- Allows commercial users to add costs and raise/approve/reject variations from the same screen.

### Next
- Replace provisional baseline material-allocation logic with explicit estimate cost-category budgets.
- Feed labour timesheets/site productivity into actual labour automatically.
- Connect supplier invoice PDF/email extraction into the existing three-way match.
- Add CREWON Authority actions for margin recovery.
- Add portfolio-level director dashboard and margin-at-risk totals.


## Sprint 2F — Director Portfolio & Margin Recovery
- Added director-level portfolio KPIs: forecast revenue, portfolio margin, margin at risk, open interventions and proposed recovery.
- Added portfolio risk counts and project risk ordering.
- Added persistent CREWON margin-recovery actions.
- Recovery actions are generated from live commercial drivers: procurement pressure, invoice variances, labour pressure and pending variations.
- V1 deliberately keeps recovery actions human-approved even when CREWON Authority is in operate mode.
- Added approve / actioned / dismiss workflow and audit events for commercial recovery decisions.
- Margin Protection UI now combines project diagnostics, director oversight and governed CREWON intervention.


## Sprint 2G — Site Workforce & Labour Control
- Added workforce profiles for employees and subcontractors, optionally linked to CREWON users.
- Added hourly cost/charge rates and overtime multiplier.
- Added project crew allocations with planned hours and planned labour cost.
- Added site timesheets with regular/overtime hours, frozen labour cost at time of submission, supervisor approval/rejection and audit logging.
- Added site progress updates with progress %, summary and blockers.
- Added labour-control API showing planned vs approved actual hours/cost and productivity variance against site progress.
- Added CREWON team -> workforce profile sync.
- Approved timesheet labour now feeds Margin Protection automatically.
- Margin Protection only treats labour above the planned allocation as new labour pressure, avoiding double-counting the original job allowance.
- Added Site Workforce dashboard with People, Allocations, Timesheets and Labour Control views.
- Extended CREWON role permissions for workforce management, approval, reading and own-time submission.

### Next
1. Mobile-first operative/supervisor Today screen.
2. Clock-in/out and location-aware job selection (with privacy-safe controls).
3. Site material requests -> Procurement.
4. Voice site diary -> progress / issues / material request / potential variation extraction.
5. Task/programme planning so productivity can compare progress at task level, not only whole-project %.


## Sprint 2H — Supervisor Experience

Built the first role-specific CREWON site-supervisor workflow across mobile and office procurement.

### Supervisor Today
- Added a dedicated mobile **Supervisor** tab.
- Shows today's allocated jobs (or today's company jobs until the supervisor is allocated), crew, latest project progress, live deliveries, open material requests and open site issues.
- Shows a supervisor-level daily count of jobs, pending timesheet approvals, deliveries and issues.
- Includes one-tap customer call action.

### Fast site actions
- **Progress** — supervisor can update project completion percentage, summary and blockers.
- **Materials** — supervisor can request material, quantity/unit, urgency and reason directly from site.
- **Issue** — supervisor can record site/client/commercial issues with severity and estimated impact.
- Supervisor can approve/reject submitted workforce timesheets from the mobile Today screen.

### Site -> Procurement
- Added persistent `site_material_requests`.
- Requests are company/job scoped and retain requester, urgency, needed-by and procurement status.
- Added a new **Site Requests** tab to the desktop Procurement workspace.
- Procurement can approve, decline, mark ordered and mark delivered.
- Supervisor requests do not autonomously place orders; they become controlled procurement demand.

### Site issues / variation pathway
- Added persistent `site_issues`.
- Issues can be classified and escalated with severity, commercial impact and potential-variation status.
- API supports turning a reviewed site issue into a pending commercial variation.
- This gives CREWON a clean path from site instruction/problem -> commercial review -> Margin Protection.

### Mobile polish
- Added Supervisor to native and classic tab navigation.
- Corrected existing mobile job value/date formatting from US dollars/locale to UK GBP / en-GB.

### Next
1. Voice Site Diary: one spoken update -> progress, issue, material request and potential variation suggestions.
2. Camera/photo evidence linked to site issue, progress update and variation.
3. Delivery receipt from mobile, including damaged/missing quantities.
4. Supervisor project task/programme view.
5. Push/attention model for urgent approvals and site blockers.


## Sprint 2I — Voice Site Diary + Photo Evidence

### Voice-ready site diary
- Added persistent `site_diaries` with original transcript, CREWON summary, explicit progress %, structured extraction and review/commit status.
- Added AI analysis endpoint that converts a natural supervisor diary into:
  - factual site summary
  - explicit progress update
  - blockers/delays
  - material requests
  - site/client/commercial issues
  - potential variation suggestions
  - essential follow-up questions
- CREWON is instructed not to invent progress percentages, material quantities, costs or client instructions.
- Potential variations are commercial-review suggestions only; they are never auto-approved.

### Review before action
- Diary analysis is separated from commitment.
- Supervisor first sees what CREWON extracted.
- Saving the reviewed diary preserves transcript + evidence.
- Committing then creates only sufficiently specific progress/material/issue records.
- Material requests with unknown quantities remain in the diary rather than CREWON guessing an order quantity.
- Commit is idempotent: an already committed diary cannot be committed twice.
- Actions are company/job scoped and audit logged.

### Photo evidence
- Added `site_evidence` linked to diary/project.
- Supervisor mobile can take site photos directly from the diary form.
- V1 stores compressed photo data with the diary so evidence travels with the commercial/site record.
- Limited to 8 images per diary and capped payload size per image.
- Production storage should move these blobs to durable object storage before scaled rollout.

### Mobile Supervisor
- Added **Diary** quick action.
- Uses the phone's native keyboard dictation for voice-to-text without adding an untested recording dependency to the Expo build.
- Supervisor can dictate/type the update, take photos, ask CREWON to analyse it, review extracted actions, save it and then explicitly commit.
- The committed outputs flow into existing Progress, Site Requests and Site Issues workflows.

### Next
1. Durable cloud/object storage for evidence and thumbnails.
2. Native in-app audio recording + transcription once the Expo audio dependency is added/tested in Replit.
3. Desktop project Site Diary / Evidence timeline.
4. Photo-to-issue AI assistance with human confirmation.
5. Delivery receipt photos and damaged/missing item evidence.


## Sprint 2J — Project Timeline & Evidence

### Unified project history
- Added a desktop **Project Timeline & Evidence** workspace.
- Aggregates site diaries, progress updates, site material requests, issues, deliveries, goods receipts,
  variations, labour timesheets, Margin Protection snapshots and commercial alerts into one chronological project record.
- Includes project-level summary counts for progress, diaries, photos, open issues, material requests and pending variations.
- Timeline can be filtered by event type.

### Evidence trail
- Generalised `site_evidence` so photos can attach to a site diary, site issue, delivery, progress event or general project record.
- Site diary photos render inline against the diary event.
- Issue and delivery evidence renders against the relevant timeline event.
- Desktop users can add general project evidence directly from the timeline.
- Mobile supervisors can now take a delivery photo from the Supervisor screen and attach it directly to that delivery's project evidence trail.

### Commercial continuity
- Variations and Margin Protection events appear in the same dated history as the site evidence that may have caused them.
- This creates a traceable route from:
  site event -> diary/photo -> issue/material request -> delivery/progress -> commercial variation -> live margin impact.

### Production note
- Evidence remains stored as compressed data URLs for the prototype.
- Before scaled deployment, move images to object storage and store only durable asset URLs plus metadata in PostgreSQL.

### Next
1. Proper object-storage evidence service.
2. Project detail page combining Timeline, Labour, Procurement, Commercial and Documents.
3. Native audio recording/transcription for site diary.
4. Photo-assisted issue classification and variation evidence packs.
5. Delivery receiving from mobile with quantity/damage evidence.


## Sprint 2K — Project Command Centre

### One project home
- Added a consolidated **Project Command Centre** API and desktop workspace.
- Brings together:
  - project/job details
  - latest progress
  - workforce allocation and approved labour
  - procurement commitments, POs, invoices and deliveries
  - live material requests from site
  - Margin Protection commercial position and drivers
  - pending/approved variations
  - open site issues
  - recent site diaries and evidence counts

### Attention model
- CREWON now builds a cross-module project attention queue from:
  - Margin Protection alerts
  - critical/high site issues
  - urgent/critical material requests
  - supplier invoice three-way-match variances
- Items are prioritised by severity with a clear next action.

### Project controls
- Top-level cards show forecast revenue, projected margin, approved labour, committed procurement,
  open issues and evidence volume.
- Tabs provide focused Workforce, Procurement, Commercial and Site/Evidence views without leaving the project.
- This becomes the foundation for the future director/project-manager command workflow.

### Next
1. Add project task/programme planning and milestones.
2. Make Project Command Centre the default route when opening a job.
3. Add documents/certificates/drawings/RFIs to the command centre.
4. Add direct action links from attention items.
5. Add mobile project command summary for supervisors/project managers.


## Sprint 2L — Project Programme & Tasks

### Programme planning
- Added project milestones with target dates and status.
- Added programme tasks with trade, planned dates, planned hours, progress, blocker reason and critical-path flag.
- Added finish-to-start task dependencies with optional lag.
- Added task-level workforce assignment and planned hours.

### Programme controls
- Project managers can start, block, progress and complete tasks.
- Actual start/finish dates are captured from status changes.
- Programme progress is weighted by planned task hours where available.
- CREWON detects late tasks, blocked tasks and late critical-path tasks.
- Programme risk is classified low / medium / high / critical.

### CREWON attention / Margin Protection
- Programme risk feeds the Project Command Centre attention queue.
- Recalculate-risk can create a Margin Protection programme alert when the project is high/critical risk.
- The alert explains late/blocked task counts and recommends dependency / crew / recovery-sequence review.

### User experience
- Added dedicated **Programme** workspace for milestones, task creation, dependencies and task crew assignments.
- Added Programme tab inside Project Command Centre.
- Command Centre now displays programme progress, risk, late/critical tasks and blockers alongside commercial, labour and procurement information.

### Next
1. Gantt-style visual programme timeline.
2. Supervisor mobile Today Tasks / blockers.
3. Task-linked timesheets so productivity is calculated against specific work packages.
4. Automatic look-ahead (7/14/28 day) planning.
5. Delay impact and programme recovery suggestions through CREWON Authority.
