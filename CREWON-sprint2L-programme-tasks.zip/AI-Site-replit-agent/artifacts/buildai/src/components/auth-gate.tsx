/**
 * CREWON app-level authentication gate.
 *
 * Supports the new multi-user account flow while retaining the old
 * SESSION_SECRET bootstrap login solely to create the first owner account.
 */
import { useState, useEffect, useCallback } from "react";
import { Loader2, Lock, Eye, EyeOff, Mail, UserRound, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

type AuthMode = "user" | "bootstrap" | null;
type AuthCheck = { authenticated: boolean; mode: AuthMode };

async function checkAuth(): Promise<AuthCheck> {
  try {
    const res = await fetch(`${BASE}/api/auth/check`, { credentials: "include" });
    if (!res.ok) return { authenticated: false, mode: null };
    const data = (await res.json()) as AuthCheck;
    return { authenticated: data.authenticated === true, mode: data.mode ?? null };
  } catch {
    return { authenticated: false, mode: null };
  }
}

async function userLogin(email: string, password: string): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch(`${BASE}/api/auth/user-login`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    if (res.ok) return { ok: true };
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    return { ok: false, error: data.error ?? "Invalid email or password" };
  } catch {
    return { ok: false, error: "Could not reach the server" };
  }
}

async function bootstrapLogin(password: string): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch(`${BASE}/api/auth/login`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
    });
    if (res.ok) return { ok: true };
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    return { ok: false, error: data.error ?? "Incorrect setup password" };
  } catch {
    return { ok: false, error: "Could not reach the server" };
  }
}

async function createOwnerAccount(input: { name: string; email: string; password: string }): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch(`${BASE}/api/auth/bootstrap-owner`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    });
    if (res.ok) return { ok: true };
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    return { ok: false, error: data.error ?? "Could not create owner account" };
  } catch {
    return { ok: false, error: "Could not reach the server" };
  }
}

function BrandHeader({ subtitle }: { subtitle: string }) {
  return (
    <div className="flex flex-col items-center gap-3 text-center">
      <img src="/logo-mark.png" alt="CREWON" className="w-12 h-12 object-contain" />
      <div>
        <h1 className="text-2xl font-bold text-white">
          CREW<span className="text-[#1687FF]">ON</span>
        </h1>
        <p className="text-sm text-white/50 mt-1">{subtitle}</p>
      </div>
    </div>
  );
}

function PasswordField({ value, onChange, label = "Password", placeholder = "Enter your password" }: {
  value: string;
  onChange: (value: string) => void;
  label?: string;
  placeholder?: string;
}) {
  const [showPassword, setShowPassword] = useState(false);
  return (
    <div className="space-y-2">
      <Label className="text-white/80 text-sm">{label}</Label>
      <div className="relative">
        <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
        <Input
          type={showPassword ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          required
          autoComplete="current-password"
          className="pl-9 pr-9 bg-white/10 border-white/20 text-white placeholder:text-white/30 focus-visible:ring-[#1687FF]"
        />
        <button
          type="button"
          onClick={() => setShowPassword((s) => !s)}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors"
          aria-label={showPassword ? "Hide password" : "Show password"}
        >
          {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
        </button>
      </div>
    </div>
  );
}

function LoginScreen({ onAuthenticated }: { onAuthenticated: (mode: Exclude<AuthMode, null>) => void }) {
  const [setupMode, setSetupMode] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const result = setupMode ? await bootstrapLogin(password) : await userLogin(email, password);
    if (result.ok) {
      onAuthenticated(setupMode ? "bootstrap" : "user");
      return;
    }
    setError(result.error ?? "Login failed");
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0d1117]">
      <div className="w-full max-w-sm space-y-6 p-8">
        <BrandHeader subtitle={setupMode ? "First-time company setup" : "Sign in to your workspace"} />

        <form onSubmit={handleSubmit} className="space-y-4 bg-white/5 border border-white/10 rounded-2xl p-6">
          {setupMode ? (
            <div className="rounded-xl border border-[#1687FF]/20 bg-[#1687FF]/10 px-3 py-2.5 text-xs leading-relaxed text-blue-100/80">
              Use the existing server setup password once. CREWON will then create your named owner account so the shared setup password is no longer your day-to-day login.
            </div>
          ) : (
            <div className="space-y-2">
              <Label htmlFor="email" className="text-white/80 text-sm">Email</Label>
              <div className="relative">
                <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@company.co.uk"
                  required
                  autoComplete="email"
                  className="pl-9 bg-white/10 border-white/20 text-white placeholder:text-white/30 focus-visible:ring-[#1687FF]"
                />
              </div>
            </div>
          )}

          <PasswordField
            value={password}
            onChange={setPassword}
            label={setupMode ? "Server setup password" : "Password"}
            placeholder={setupMode ? "Enter setup password" : "Enter your password"}
          />

          {error && <p className="text-sm text-red-400 bg-red-400/10 border border-red-400/20 rounded-lg px-3 py-2">{error}</p>}

          <Button
            type="submit"
            disabled={loading || !password.trim() || (!setupMode && !email.trim())}
            className="w-full bg-[#1687FF] hover:bg-[#0D6FE8] text-white border-0 font-semibold"
          >
            {loading ? <Loader2 size={16} className="animate-spin mr-2" /> : null}
            {loading ? "Signing in…" : setupMode ? "Continue Setup" : "Sign In"}
          </Button>

          <button
            type="button"
            onClick={() => { setSetupMode((value) => !value); setError(null); setPassword(""); }}
            className="w-full text-xs text-white/45 hover:text-white/75 transition-colors"
          >
            {setupMode ? "Back to normal sign in" : "Setting up this CREWON workspace for the first time?"}
          </button>
        </form>

        <p className="text-center text-xs text-white/30">Your AI workforce. Always on.</p>
      </div>
    </div>
  );
}

function OwnerSetupScreen({ onComplete, onBack }: { onComplete: () => void; onBack: () => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (password.length < 12) {
      setError("Use at least 12 characters for your owner password.");
      return;
    }
    if (password !== confirm) {
      setError("Passwords do not match.");
      return;
    }
    setLoading(true);
    const result = await createOwnerAccount({ name, email, password });
    if (result.ok) {
      onComplete();
      return;
    }
    setError(result.error ?? "Could not create owner account");
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0d1117]">
      <div className="w-full max-w-md space-y-6 p-8">
        <BrandHeader subtitle="Create the first owner account" />
        <form onSubmit={submit} className="space-y-4 bg-white/5 border border-white/10 rounded-2xl p-6">
          <div className="rounded-xl border border-emerald-400/20 bg-emerald-400/10 px-3 py-2.5 text-xs leading-relaxed text-emerald-100/80">
            Setup password accepted. Now create your personal owner login. This is the account you will use day to day.
          </div>

          <div className="space-y-2">
            <Label className="text-white/80 text-sm">Your name</Label>
            <div className="relative">
              <UserRound size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
              <Input value={name} onChange={(e) => setName(e.target.value)} required placeholder="Your name" autoComplete="name" className="pl-9 bg-white/10 border-white/20 text-white placeholder:text-white/30 focus-visible:ring-[#1687FF]" />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-white/80 text-sm">Email</Label>
            <div className="relative">
              <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required placeholder="you@company.co.uk" autoComplete="email" className="pl-9 bg-white/10 border-white/20 text-white placeholder:text-white/30 focus-visible:ring-[#1687FF]" />
            </div>
          </div>

          <PasswordField value={password} onChange={setPassword} label="New owner password" placeholder="At least 12 characters" />
          <PasswordField value={confirm} onChange={setConfirm} label="Confirm password" placeholder="Repeat your password" />

          {error && <p className="text-sm text-red-400 bg-red-400/10 border border-red-400/20 rounded-lg px-3 py-2">{error}</p>}

          <Button type="submit" disabled={loading || !name.trim() || !email.trim() || !password || !confirm} className="w-full bg-[#1687FF] hover:bg-[#0D6FE8] text-white border-0 font-semibold">
            {loading ? <Loader2 size={16} className="animate-spin mr-2" /> : null}
            {loading ? "Creating owner…" : "Create Owner Account"}
          </Button>

          <button type="button" onClick={onBack} className="w-full flex items-center justify-center gap-1 text-xs text-white/45 hover:text-white/75 transition-colors">
            <ArrowLeft size={12} /> Back to sign in
          </button>
        </form>
      </div>
    </div>
  );
}

type AuthState = "checking" | "authenticated" | "bootstrap" | "unauthenticated";

export function AuthGate({ children }: { children: React.ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>("checking");

  const checkAndSetAuth = useCallback(async () => {
    const auth = await checkAuth();
    if (!auth.authenticated) setAuthState("unauthenticated");
    else if (auth.mode === "bootstrap") setAuthState("bootstrap");
    else setAuthState("authenticated");
  }, []);

  useEffect(() => { void checkAndSetAuth(); }, [checkAndSetAuth]);

  if (authState === "checking") {
    return <div className="min-h-screen flex items-center justify-center bg-[#0d1117]"><Loader2 size={28} className="animate-spin text-[#1687FF]" /></div>;
  }

  if (authState === "unauthenticated") {
    return <LoginScreen onAuthenticated={(mode) => setAuthState(mode === "bootstrap" ? "bootstrap" : "authenticated")} />;
  }

  if (authState === "bootstrap") {
    return <OwnerSetupScreen onComplete={() => setAuthState("authenticated")} onBack={() => setAuthState("unauthenticated")} />;
  }

  return <>{children}</>;
}
