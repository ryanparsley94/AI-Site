import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const API = (import.meta.env.VITE_API_URL || "/api").replace(/\/$/, "");

export default function AcceptInvite() {
  const [, navigate] = useLocation();
  const token = new URLSearchParams(window.location.search).get("token") || "";
  const [name,setName]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState(""); const [pending,setPending]=useState(false);
  const submit = async () => {
    setPending(true); setError("");
    try {
      const res=await fetch(`${API}/auth/accept-invite`,{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({token,name,password})});
      const body=await res.json(); if(!res.ok) throw new Error(body.error||"Invite could not be accepted");
      navigate("/dashboard");
    } catch(e){setError(e instanceof Error?e.message:"Invite could not be accepted");} finally{setPending(false);}
  };
  return <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4"><Card className="w-full max-w-md"><CardHeader><CardTitle>Join CREWON</CardTitle><CardDescription>Set up your secure account to join your company workspace.</CardDescription></CardHeader><CardContent className="space-y-4"><div><Label>Name</Label><Input className="mt-1.5" value={name} onChange={e=>setName(e.target.value)}/></div><div><Label>Password</Label><Input className="mt-1.5" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 12 characters"/></div>{error&&<p className="text-sm text-destructive">{error}</p>}<Button className="w-full" disabled={pending||!token||name.length<2||password.length<12} onClick={submit}>{pending?"Joining…":"Join CREWON"}</Button></CardContent></Card></div>;
}
