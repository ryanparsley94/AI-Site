import { useEffect, useMemo, useRef, useState } from "react";
import { AlertTriangle, Camera, ClipboardList, FileImage, Filter, Package, PoundSterling, RefreshCw, ShieldCheck, Truck, UsersRound } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

const API=(import.meta.env.VITE_API_URL||"/api").replace(/\/$/,"");
async function api<T=any>(path:string,init?:RequestInit):Promise<T>{
  const r=await fetch(`${API}${path}`,{credentials:"include",headers:init?.body?{"Content-Type":"application/json",...(init.headers||{})}:init?.headers,...init});
  const body=await r.json().catch(()=>({}));if(!r.ok)throw new Error(body.error||`CREWON request failed (${r.status})`);return body;
}
type Job={id:number;title:string;status:string;address?:string|null;scheduledAt:string};
type Event={type:string;date:string;title:string;detail:string;severity?:string|null;data:any};
type Timeline={job:Job;summary:{diaries:number;photos:number;openIssues:number;openMaterialRequests:number;pendingVariations:number;latestProgress:number};events:Event[]};

const icons:Record<string,any>={site_diary:ClipboardList,progress:ShieldCheck,material_request:Package,site_issue:AlertTriangle,delivery:Truck,goods_received:Truck,variation:PoundSterling,margin:PoundSterling,labour:UsersRound,commercial_alert:AlertTriangle,evidence:FileImage};
const labels:Record<string,string>={site_diary:"Site diary",progress:"Progress",material_request:"Materials",site_issue:"Issue",delivery:"Delivery",goods_received:"Goods received",variation:"Variation",margin:"Margin",labour:"Labour",commercial_alert:"Commercial alert",evidence:"Evidence"};

export default function ProjectTimeline(){
  const {toast}=useToast();const [jobs,setJobs]=useState<Job[]>([]);const [jobId,setJobId]=useState("");const [timeline,setTimeline]=useState<Timeline|null>(null);const [filter,setFilter]=useState("all");const [loading,setLoading]=useState(false);const [caption,setCaption]=useState("");const fileRef=useRef<HTMLInputElement|null>(null);
  const loadJobs=async()=>{const j=await api<Job[]>("/jobs");setJobs(j);if(!jobId&&j[0])setJobId(String(j[0].id));};
  const load=async(id=jobId)=>{if(!id)return;setLoading(true);try{setTimeline(await api<Timeline>(`/projects/${id}/timeline`));}catch(e:any){toast({title:"Could not load project timeline",description:e.message,variant:"destructive"});}finally{setLoading(false)}};
  useEffect(()=>{void loadJobs().catch(()=>{})},[]);
  useEffect(()=>{if(jobId)void load(jobId)},[jobId]);

  const filtered=useMemo(()=>timeline?.events.filter(e=>filter==="all"||e.type===filter)??[],[timeline,filter]);
  const photoCount=timeline?.summary.photos??0;
  const addPhoto=async(file:File)=>{
    if(!jobId)return;
    if(!file.type.startsWith("image/"))return toast({title:"Choose an image file",variant:"destructive"});
    if(file.size>5_000_000)return toast({title:"Please use an image under 5 MB",description:"CREWON will use durable object storage for larger evidence in production.",variant:"destructive"});
    const reader=new FileReader();
    reader.onload=async()=>{
      try{
        await api(`/projects/${jobId}/evidence`,{method:"POST",body:JSON.stringify({fileName:file.name,mimeType:file.type,dataUrl:String(reader.result),caption,entityType:"general",source:"desktop"})});
        setCaption("");toast({title:"Project evidence added"});await load(jobId);
      }catch(e:any){toast({title:"Could not add evidence",description:e.message,variant:"destructive"})}
    };
    reader.readAsDataURL(file);
  };

  return <div className="space-y-6">
    <div className="flex flex-col gap-3 xl:flex-row xl:items-end xl:justify-between">
      <div><div className="flex items-center gap-2"><ClipboardList className="text-primary"/><h1 className="text-2xl font-bold">Project Timeline & Evidence</h1></div><p className="mt-1 text-sm text-muted-foreground">One chronological record of site diaries, photos, progress, labour, materials, deliveries, variations and margin events.</p></div>
      <div className="flex flex-wrap gap-2"><Select value={jobId} onValueChange={setJobId}><SelectTrigger className="w-[280px]"><SelectValue placeholder="Choose project"/></SelectTrigger><SelectContent>{jobs.map(j=><SelectItem key={j.id} value={String(j.id)}>{j.title}</SelectItem>)}</SelectContent></Select><Button variant="outline" onClick={()=>void load()} disabled={loading||!jobId}><RefreshCw className="mr-2 h-4 w-4"/>Refresh</Button></div>
    </div>

    {timeline?<>
      <Card className="border-primary/20"><CardContent className="pt-6"><div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between"><div><div className="text-lg font-semibold">{timeline.job.title}</div><div className="text-sm text-muted-foreground">{timeline.job.address||"No project address"} · {timeline.job.status.replaceAll("_"," ")}</div></div><div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
        <Metric label="Progress" value={`${timeline.summary.latestProgress.toFixed(0)}%`}/><Metric label="Diaries" value={String(timeline.summary.diaries)}/><Metric label="Photos" value={String(photoCount)}/><Metric label="Open issues" value={String(timeline.summary.openIssues)}/><Metric label="Material reqs" value={String(timeline.summary.openMaterialRequests)}/><Metric label="Variations" value={String(timeline.summary.pendingVariations)}/>
      </div></div></CardContent></Card>

      <div className="grid gap-4 xl:grid-cols-[1fr_330px]">
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2"><Filter className="h-4 w-4 text-muted-foreground"/><Select value={filter} onValueChange={setFilter}><SelectTrigger className="w-[200px]"><SelectValue/></SelectTrigger><SelectContent><SelectItem value="all">All project events</SelectItem>{Object.entries(labels).map(([k,v])=><SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent></Select><span className="text-xs text-muted-foreground">{filtered.length} event(s)</span></div>
          {filtered.map((event,i)=><TimelineEvent key={`${event.type}-${event.date}-${i}`} event={event}/>)}
          {!filtered.length?<Card><CardContent className="py-12 text-center text-sm text-muted-foreground">No project events match this filter yet.</CardContent></Card>:null}
        </div>
        <div className="space-y-4">
          <Card><CardHeader><CardTitle className="flex items-center gap-2 text-base"><Camera className="h-4 w-4 text-primary"/>Add project evidence</CardTitle></CardHeader><CardContent className="space-y-3"><p className="text-sm text-muted-foreground">Add a general project photo now. Photos taken from Supervisor diaries are already linked automatically.</p><Input placeholder="Photo caption / what this proves" value={caption} onChange={e=>setCaption(e.target.value)}/><input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e=>{const f=e.target.files?.[0];if(f)void addPhoto(f);e.currentTarget.value="";}}/><Button className="w-full" variant="outline" onClick={()=>fileRef.current?.click()}><Camera className="mr-2 h-4 w-4"/>Choose photo</Button></CardContent></Card>
          <Card><CardHeader><CardTitle className="text-base">Why this matters</CardTitle></CardHeader><CardContent className="space-y-2 text-sm text-muted-foreground"><p>CREWON now has a dated evidence trail linking what happened on site to operational and commercial decisions.</p><p>That means a client instruction, photo, material request and later variation can be viewed in the same project history rather than reconstructed weeks later.</p></CardContent></Card>
        </div>
      </div>
    </>:<Card><CardContent className="py-12 text-center text-sm text-muted-foreground">{loading?"Loading project evidence…":"Choose a project to open its timeline."}</CardContent></Card>}
  </div>
}
function Metric({label,value}:{label:string;value:string}){return <div className="rounded-lg border p-2.5 text-center"><div className="text-lg font-semibold">{value}</div><div className="text-[10px] text-muted-foreground">{label}</div></div>}
function TimelineEvent({event}:{event:Event}){
  const Icon=icons[event.type]||ClipboardList;const photos=Array.isArray(event.data?.evidence)?event.data.evidence:[];
  const variant=event.severity==="critical"||event.severity==="high"?"destructive":event.severity==="medium"?"secondary":"outline";
  return <Card><CardContent className="p-4"><div className="flex gap-3"><div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted"><Icon className="h-4 w-4 text-primary"/></div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-start justify-between gap-2"><div><div className="font-semibold">{event.title}</div><div className="mt-0.5 text-xs text-muted-foreground">{new Date(event.date).toLocaleString("en-GB",{dateStyle:"medium",timeStyle:"short"})} · {labels[event.type]||event.type}</div></div>{event.severity?<Badge variant={variant as any} className="capitalize">{event.severity}</Badge>:null}</div><p className="mt-2 whitespace-pre-wrap text-sm text-muted-foreground">{event.detail}</p>{event.type==="variation"&&event.data?.value!==undefined?<div className="mt-2 text-sm">Client value <strong>£{Number(event.data.value).toFixed(2)}</strong> · estimated cost £{Number(event.data.estimatedCost||0).toFixed(2)}</div>:null}{event.type==="margin"?<div className="mt-2 text-sm">Forecast margin <strong>{Number(event.data?.forecastMarginPercent||0).toFixed(1)}%</strong></div>:null}{photos.length?<div className="mt-3 grid grid-cols-2 gap-2 md:grid-cols-4">{photos.map((p:any)=><figure key={p.id} className="overflow-hidden rounded-lg border"><img src={p.dataUrl} alt={p.caption||p.fileName||"Project evidence"} className="h-32 w-full object-cover"/>{p.caption?<figcaption className="p-2 text-xs text-muted-foreground">{p.caption}</figcaption>:null}</figure>)}</div>:null}</div></div></CardContent></Card>
}
