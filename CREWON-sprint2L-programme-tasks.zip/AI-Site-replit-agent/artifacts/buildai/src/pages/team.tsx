import { useEffect, useState } from "react";
import { Copy, ShieldCheck, Trash2, UserPlus, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

const API = (import.meta.env.VITE_API_URL || "/api").replace(/\/$/, "");
const ROLE_LABELS: Record<string, string> = {
  owner: "Owner / Director",
  office_manager: "Office Manager",
  estimator: "Estimator",
  project_manager: "Project Manager",
  supervisor: "Site Supervisor",
  operative: "Operative / Engineer",
  finance: "Finance / Bookkeeper",
};

type TeamData = {
  members: Array<{ membershipId: number; userId: number; name: string; email: string; status: string; role: string }>;
  invites: Array<{ id: number; email: string; role: string; status: string; expiresAt: string }>;
  roles: string[];
};

export default function Team() {
  const [data, setData] = useState<TeamData | null>(null);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("operative");
  const [pending, setPending] = useState(false);
  const [latestInviteUrl, setLatestInviteUrl] = useState("");
  const { toast } = useToast();

  const load = async () => {
    const res = await fetch(`${API}/team`, { credentials: "include" });
    if (res.ok) setData(await res.json());
  };
  useEffect(() => { void load(); }, []);

  const invite = async () => {
    setPending(true);
    try {
      const res = await fetch(`${API}/team/invitations`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, role }),
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || "Invite failed");
      const inviteUrl = body.inviteUrl?.startsWith("http") ? body.inviteUrl : `${window.location.origin}${body.inviteUrl}`;
      setLatestInviteUrl(inviteUrl);
      setEmail("");
      toast({ title: "Invitation created", description: "Copy the secure invitation link and send it to the team member." });
      await load();
    } catch (error) {
      toast({ title: "Could not create invitation", description: error instanceof Error ? error.message : "Please try again", variant: "destructive" });
    } finally { setPending(false); }
  };

  const changeRole = async (membershipId: number, nextRole: string) => {
    const res = await fetch(`${API}/team/members/${membershipId}`, {
      method: "PATCH", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ role: nextRole }),
    });
    if (!res.ok) {
      const body = await res.json();
      toast({ title: "Role not changed", description: body.error, variant: "destructive" });
      return;
    }
    await load();
  };

  const removeMember = async (membershipId: number) => {
    const res = await fetch(`${API}/team/members/${membershipId}`, { method: "DELETE", credentials: "include" });
    if (!res.ok) {
      const body = await res.json();
      toast({ title: "Member not removed", description: body.error, variant: "destructive" });
      return;
    }
    await load();
  };

  return <div className="space-y-6">
    <div>
      <div className="flex items-center gap-2"><Users className="h-6 w-6 text-primary"/><h1 className="text-2xl font-bold">Team & Permissions</h1></div>
      <p className="text-sm text-muted-foreground mt-1">Give each person the CREWON access their job requires. Owner access remains protected.</p>
    </div>

    <Card>
      <CardHeader><CardTitle className="flex items-center gap-2 text-base"><UserPlus className="h-4 w-4"/>Invite a team member</CardTitle></CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 md:grid-cols-[1fr_240px_auto] md:items-end">
          <div><Label>Email</Label><Input className="mt-1.5" type="email" value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="name@company.co.uk"/></div>
          <div><Label>Role</Label><Select value={role} onValueChange={setRole}><SelectTrigger className="mt-1.5"><SelectValue/></SelectTrigger><SelectContent>{Object.entries(ROLE_LABELS).filter(([k])=>k!=="owner").map(([k,v])=><SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent></Select></div>
          <Button onClick={invite} disabled={pending || !email.includes("@")}>{pending ? "Creating…" : "Create invite"}</Button>
        </div>
        {latestInviteUrl && <div className="rounded-lg border bg-muted/30 p-3 flex gap-2 items-center"><code className="text-xs flex-1 break-all">{latestInviteUrl}</code><Button variant="outline" size="sm" onClick={()=>{void navigator.clipboard.writeText(latestInviteUrl); toast({title:"Invite link copied"});}}><Copy className="h-4 w-4"/></Button></div>}
        <p className="text-xs text-muted-foreground">V1 returns a secure one-time-style link for manual sharing. Company-branded invitation email delivery is the next integration step.</p>
      </CardContent>
    </Card>

    <Card>
      <CardHeader><CardTitle className="flex items-center gap-2 text-base"><ShieldCheck className="h-4 w-4"/>Active team</CardTitle></CardHeader>
      <CardContent>
        <Table><TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Email</TableHead><TableHead>Role</TableHead><TableHead className="w-16"></TableHead></TableRow></TableHeader><TableBody>
          {data?.members.map((m)=><TableRow key={m.membershipId}><TableCell className="font-medium">{m.name}</TableCell><TableCell>{m.email}</TableCell><TableCell><Select value={m.role} onValueChange={(v)=>void changeRole(m.membershipId,v)}><SelectTrigger className="w-48"><SelectValue/></SelectTrigger><SelectContent>{Object.entries(ROLE_LABELS).map(([k,v])=><SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent></Select></TableCell><TableCell><Button variant="ghost" size="icon" onClick={()=>void removeMember(m.membershipId)} disabled={m.role==="owner"}><Trash2 className="h-4 w-4"/></Button></TableCell></TableRow>)}
        </TableBody></Table>
      </CardContent>
    </Card>

    {(data?.invites.length ?? 0) > 0 && <Card><CardHeader><CardTitle className="text-base">Pending invitations</CardTitle></CardHeader><CardContent className="space-y-2">{data?.invites.map(i=><div key={i.id} className="flex items-center gap-3 rounded-lg border p-3"><div className="flex-1"><div className="font-medium">{i.email}</div><div className="text-xs text-muted-foreground">Expires {new Date(i.expiresAt).toLocaleDateString("en-GB")}</div></div><Badge variant="outline">{ROLE_LABELS[i.role] || i.role}</Badge></div>)}</CardContent></Card>}
  </div>;
}
