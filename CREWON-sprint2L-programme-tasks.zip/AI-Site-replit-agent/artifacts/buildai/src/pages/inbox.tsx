import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { Inbox as InboxIcon, Mail, Phone, Search, AlertCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

function apiBase() {
  return (import.meta.env.VITE_API_URL || "/api").replace(/\/$/, "");
}

type InboxItem = {
  id: string;
  channel: "phone" | "email";
  title: string;
  subtitle: string;
  preview: string;
  status: string;
  createdAt: string;
  sourceId: number;
};

type InboxResponse = {
  items: InboxItem[];
  counts: { all: number; phone: number; email: number; attention: number };
};

export default function UnifiedInbox() {
  const [data, setData] = useState<InboxResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [channel, setChannel] = useState<"all" | "phone" | "email">("all");
  const [search, setSearch] = useState("");

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetch(`${apiBase()}/inbox?channel=${channel}&search=${encodeURIComponent(search)}`, { credentials: "include" })
      .then(async (res) => {
        if (!res.ok) throw new Error("Unable to load inbox");
        return res.json() as Promise<InboxResponse>;
      })
      .then((next) => { if (!cancelled) setData(next); })
      .catch(() => { if (!cancelled) setData(null); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [channel, search]);

  const filters = useMemo(() => [
    { key: "all" as const, label: "All", count: data?.counts.all ?? 0 },
    { key: "phone" as const, label: "Calls", count: data?.counts.phone ?? 0 },
    { key: "email" as const, label: "Email", count: data?.counts.email ?? 0 },
  ], [data]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <InboxIcon className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold">Unified Inbox</h1>
        </div>
        <p className="text-sm text-muted-foreground">Calls and emails in one CREWON work queue. SMS, WhatsApp and web chat plug into this same model next.</p>
      </div>

      <div className="grid gap-3 sm:grid-cols-4">
        <Card><CardContent className="p-4"><div className="text-2xl font-semibold">{data?.counts.all ?? "—"}</div><div className="text-xs text-muted-foreground">Conversations</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-2xl font-semibold">{data?.counts.phone ?? "—"}</div><div className="text-xs text-muted-foreground">Calls</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-2xl font-semibold">{data?.counts.email ?? "—"}</div><div className="text-xs text-muted-foreground">Emails</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="flex items-center gap-2 text-2xl font-semibold"><AlertCircle className="h-5 w-5 text-amber-500" />{data?.counts.attention ?? "—"}</div><div className="text-xs text-muted-foreground">Needs attention</div></CardContent></Card>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="flex gap-2">
          {filters.map((filter) => (
            <Button key={filter.key} variant={channel === filter.key ? "default" : "outline"} size="sm" onClick={() => setChannel(filter.key)}>
              {filter.label} <span className="ml-1 opacity-70">{filter.count}</span>
            </Button>
          ))}
        </div>
        <div className="relative sm:ml-auto sm:w-80">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search conversations" className="pl-9" />
        </div>
      </div>

      <Card>
        <CardContent className="p-0 divide-y">
          {loading && <div className="p-8 text-center text-sm text-muted-foreground">Loading CREWON inbox…</div>}
          {!loading && !data && <div className="p-8 text-center text-sm text-destructive">Inbox could not be loaded.</div>}
          {!loading && data?.items.length === 0 && <div className="p-8 text-center text-sm text-muted-foreground">No conversations match this view.</div>}
          {data?.items.map((item) => {
            const href = item.channel === "phone" ? `/calls/${item.sourceId}` : "/email-inbox";
            return (
              <Link href={href} key={item.id} className="flex gap-4 p-4 hover:bg-muted/40 transition-colors">
                <div className="mt-1 h-9 w-9 shrink-0 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                  {item.channel === "phone" ? <Phone className="h-4 w-4" /> : <Mail className="h-4 w-4" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-start gap-2">
                    <div className="font-medium truncate">{item.title}</div>
                    <Badge variant={item.status === "pending" || item.status === "unresolved" ? "secondary" : "outline"} className="ml-auto shrink-0 capitalize">{item.status}</Badge>
                  </div>
                  <div className="text-sm text-muted-foreground truncate">{item.subtitle}</div>
                  <div className="mt-1 text-sm text-muted-foreground line-clamp-2">{item.preview}</div>
                  <div className="mt-2 text-xs text-muted-foreground">{new Date(item.createdAt).toLocaleString("en-GB")}</div>
                </div>
              </Link>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}
