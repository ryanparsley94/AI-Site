import { useEffect, useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Boxes, Building2, ClipboardList, PackageCheck, Plus, PoundSterling, RefreshCw, ShoppingCart, Truck, ShieldCheck, WandSparkles } from "lucide-react";

const API = (import.meta.env.VITE_API_URL || "/api").replace(/\/$/, "");
const gbp = new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" });

async function api<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API}${path}`, {
    credentials: "include",
    ...options,
    headers: options?.body ? { "Content-Type": "application/json", ...(options.headers || {}) } : options?.headers,
  });
  const body = res.status === 204 ? null : await res.json().catch(() => null);
  if (!res.ok) throw new Error(body?.error || `CREWON request failed (${res.status})`);
  return body as T;
}

type Summary = { suppliers: number; products: number; openPurchaseOrders: number; pendingDeliveries: number; openRfqs: number; committedSpend: number };
type SupplierAccount = { id: number; accountName: string; accountNumber?: string | null; branch?: string | null; pricingMethod: string; minimumOrder?: number | string; deliveryCharge?: number | string; freeDeliveryThreshold?: number | string; deliveryLeadTimeDays?: number | null; isDefault: boolean };
type Supplier = { id: number; name: string; phone?: string | null; email?: string | null; website?: string | null; preferred: boolean; status: string; accounts: SupplierAccount[] };
type Price = { id: number; supplierId: number; supplierName: string; supplierAccountId?: number | null; supplierSku?: string | null; unitCost: number; availability?: string | null; leadTimeDays?: number | null; source: string; validFrom: string };
type Product = { id: number; sku?: string | null; name: string; category?: string | null; manufacturer?: string | null; manufacturerPartNumber?: string | null; unit: string; defaultWastePercent: number; prices: Price[] };
type Rfq = { id: number; title: string; status: string; dueAt?: string | null; items: Array<{ id: number; description: string; quantity: number; unit: string }>; responses: Array<{ id: number; supplierName: string; total: number; reference?: string | null }> };
type PoItem = { id: number; description: string; quantity: number; unit: string; unitCost: number; lineTotal: number };
type PurchaseOrder = { id: number; poNumber: string; supplierId: number; supplierName: string; jobId?: number | null; status: string; total: number; requiredBy?: string | null; items: PoItem[] };
type QuoteLite = { id: number; title: string; jobId?: number | null; materials: Array<Record<string, unknown>>; totalIncVat?: number | null };
type Authority = { mode: "observe" | "assist" | "operate"; autoApprovePurchaseLimit: number; preferredSuppliersOnly: boolean; requireKnownPriceSource: boolean };
type Plan = { id: number; quoteId?: number | null; jobId?: number | null; status: string; estimatedSubtotal: number; savingsVsSingleSupplier: number; missingItemCount: number; recommendation: { deliveryFees?: number; landedTotal?: number; lines?: Array<{ description: string; quantity: number; unit: string; best?: { supplierName: string; lineTotal: number } | null }> } };
type GoodsReceipt = { id: number; purchaseOrderId: number; reference?: string | null; receivedAt: string; items: Array<{ id: number; purchaseOrderItemId: number; quantityReceived: number; condition: string }> };
type SupplierInvoice = { id: number; supplierId: number; supplierName: string; purchaseOrderId?: number | null; invoiceNumber: string; invoiceDate: string; subtotal: number; vat: number; total: number; status: string; matchSummary?: { issueCount?: number; issues?: string[] }; items: Array<{ id: number; purchaseOrderItemId?: number | null; description: string; quantity: number; unitCost: number; lineTotal: number }> };
type SiteMaterialRequest = { id:number; jobId:number; description:string; quantity:number; unit:string; urgency:string; reason?:string|null; status:string; procurementReference?:string|null; createdAt:string };
type Delivery = { id: number; purchaseOrderId?: number | null; supplierName?: string | null; status: string; reference?: string | null; scheduledAt?: string | null; receivedAt?: string | null; deliveryAddress?: string | null };

type Data = { summary: Summary | null; suppliers: Supplier[]; products: Product[]; rfqs: Rfq[]; purchaseOrders: PurchaseOrder[]; deliveries: Delivery[]; quotes: QuoteLite[]; plans: Plan[]; authority: Authority; goodsReceipts: GoodsReceipt[]; supplierInvoices: SupplierInvoice[]; siteMaterialRequests: SiteMaterialRequest[] };

const emptyData: Data = { summary: null, suppliers: [], products: [], rfqs: [], purchaseOrders: [], deliveries: [], quotes: [], plans: [], authority: { mode: "assist", autoApprovePurchaseLimit: 0, preferredSuppliersOnly: false, requireKnownPriceSource: true }, goodsReceipts: [], supplierInvoices: [], siteMaterialRequests: [] };

export default function Procurement() {
  const [data, setData] = useState<Data>(emptyData);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const [supplierForm, setSupplierForm] = useState({ name: "", accountNumber: "", branch: "", preferred: true });
  const [accountForm, setAccountForm] = useState({ supplierId: "", accountName: "Trade account", accountNumber: "", branch: "", pricingMethod: "manual", minimumOrder: "", deliveryCharge: "", freeDeliveryThreshold: "", deliveryLeadTimeDays: "" });
  const [productForm, setProductForm] = useState({ name: "", sku: "", category: "", manufacturer: "", unit: "each" });
  const [priceForm, setPriceForm] = useState({ productId: "", supplierId: "", supplierAccountId: "", supplierSku: "", unitCost: "", availability: "In stock", leadTimeDays: "", source: "manual" });
  const [rfqForm, setRfqForm] = useState({ title: "", description: "", quantity: "1", unit: "each", dueAt: "" });
  const [rfqResponseForm, setRfqResponseForm] = useState({ rfqId: "", supplierId: "", total: "", reference: "" });
  const [poForm, setPoForm] = useState({ supplierId: "", supplierAccountId: "", description: "", quantity: "1", unit: "each", unitCost: "", requiredBy: "", deliveryAddress: "" });
  const [deliveryForm, setDeliveryForm] = useState({ purchaseOrderId: "", scheduledAt: "", reference: "", deliveryAddress: "" });
  const [planQuoteId, setPlanQuoteId] = useState("");
  const [authorityForm, setAuthorityForm] = useState<Authority>(emptyData.authority);
  const [receiptForm, setReceiptForm] = useState({ purchaseOrderId: "", reference: "", purchaseOrderItemId: "", quantityReceived: "", condition: "accepted" });
  const [invoiceForm, setInvoiceForm] = useState({ purchaseOrderId: "", invoiceNumber: "", invoiceDate: new Date().toISOString().slice(0,10), dueDate: "" });


  const load = async () => {
    setLoading(true);
    try {
      const [summary, suppliers, products, rfqs, purchaseOrders, deliveries, quotes, plans, authority, goodsReceipts, supplierInvoices, siteMaterialRequests] = await Promise.all([
        api<Summary>("/procurement/summary"), api<Supplier[]>("/procurement/suppliers"), api<Product[]>("/procurement/products"),
        api<Rfq[]>("/procurement/rfqs"), api<PurchaseOrder[]>("/procurement/purchase-orders"), api<Delivery[]>("/procurement/deliveries"),
        api<QuoteLite[]>("/quotes"), api<Plan[]>("/procurement/plans"), api<Authority>("/procurement/authority"), api<GoodsReceipt[]>("/procurement/goods-receipts"), api<SupplierInvoice[]>("/procurement/supplier-invoices"), api<SiteMaterialRequest[]>("/supervisor/material-requests"),
      ]);
      setData({ summary, suppliers, products, rfqs, purchaseOrders, deliveries, quotes, plans, authority, goodsReceipts, supplierInvoices, siteMaterialRequests }); setAuthorityForm(authority);
    } catch (error) {
      toast({ title: "Procurement could not be loaded", description: error instanceof Error ? error.message : "Please try again", variant: "destructive" });
    } finally { setLoading(false); }
  };
  useEffect(() => { void load(); }, []);

  const save = async (work: () => Promise<unknown>, success: string) => {
    setSaving(true);
    try { await work(); toast({ title: success }); await load(); }
    catch (error) { toast({ title: "CREWON couldn't save that", description: error instanceof Error ? error.message : "Please try again", variant: "destructive" }); }
    finally { setSaving(false); }
  };

  const selectedSupplier = useMemo(() => data.suppliers.find((s) => String(s.id) === priceForm.supplierId), [data.suppliers, priceForm.supplierId]);
  const poSupplier = useMemo(() => data.suppliers.find((s) => String(s.id) === poForm.supplierId), [data.suppliers, poForm.supplierId]);

  const addSupplier = () => save(async () => {
    const supplier = await api<Supplier>("/procurement/suppliers", { method: "POST", body: JSON.stringify({ name: supplierForm.name, preferred: supplierForm.preferred }) });
    if (supplierForm.accountNumber || supplierForm.branch) {
      await api(`/procurement/suppliers/${supplier.id}/accounts`, { method: "POST", body: JSON.stringify({ accountName: "Trade account", accountNumber: supplierForm.accountNumber, branch: supplierForm.branch, pricingMethod: "manual", isDefault: true }) });
    }
    setSupplierForm({ name: "", accountNumber: "", branch: "", preferred: true });
  }, "Supplier added");

  const addAccount = () => save(async () => {
    await api(`/procurement/suppliers/${accountForm.supplierId}/accounts`, { method: "POST", body: JSON.stringify({ ...accountForm, supplierId: undefined, isDefault: true }) });
    setAccountForm({ supplierId: "", accountName: "Trade account", accountNumber: "", branch: "", pricingMethod: "manual", minimumOrder: "", deliveryCharge: "", freeDeliveryThreshold: "", deliveryLeadTimeDays: "" });
  }, "Trade account added");

  const addProduct = () => save(async () => {
    await api("/procurement/products", { method: "POST", body: JSON.stringify(productForm) });
    setProductForm({ name: "", sku: "", category: "", manufacturer: "", unit: "each" });
  }, "Product added to CREWON catalogue");

  const addPrice = () => save(async () => {
    await api(`/procurement/products/${priceForm.productId}/prices`, { method: "POST", body: JSON.stringify({ ...priceForm, productId: undefined, supplierId: Number(priceForm.supplierId), supplierAccountId: priceForm.supplierAccountId ? Number(priceForm.supplierAccountId) : null, unitCost: Number(priceForm.unitCost), leadTimeDays: priceForm.leadTimeDays ? Number(priceForm.leadTimeDays) : null }) });
    setPriceForm({ productId: "", supplierId: "", supplierAccountId: "", supplierSku: "", unitCost: "", availability: "In stock", leadTimeDays: "", source: "manual" });
  }, "Supplier price recorded");

  const addRfq = () => save(async () => {
    await api("/procurement/rfqs", { method: "POST", body: JSON.stringify({ title: rfqForm.title, dueAt: rfqForm.dueAt || null, items: [{ description: rfqForm.description, quantity: Number(rfqForm.quantity), unit: rfqForm.unit }] }) });
    setRfqForm({ title: "", description: "", quantity: "1", unit: "each", dueAt: "" });
  }, "RFQ created");

  const addRfqResponse = () => save(async () => {
    await api(`/procurement/rfqs/${rfqResponseForm.rfqId}/responses`, { method: "POST", body: JSON.stringify({ supplierId: Number(rfqResponseForm.supplierId), total: Number(rfqResponseForm.total), reference: rfqResponseForm.reference }) });
    setRfqResponseForm({ rfqId: "", supplierId: "", total: "", reference: "" });
  }, "Supplier RFQ response recorded");

  const addPo = () => save(async () => {
    await api("/procurement/purchase-orders", { method: "POST", body: JSON.stringify({ supplierId: Number(poForm.supplierId), supplierAccountId: poForm.supplierAccountId ? Number(poForm.supplierAccountId) : null, requiredBy: poForm.requiredBy || null, deliveryAddress: poForm.deliveryAddress || null, items: [{ description: poForm.description, quantity: Number(poForm.quantity), unit: poForm.unit, unitCost: Number(poForm.unitCost) }] }) });
    setPoForm({ supplierId: "", supplierAccountId: "", description: "", quantity: "1", unit: "each", unitCost: "", requiredBy: "", deliveryAddress: "" });
  }, "Purchase order created");

  const setPoStatus = (id: number, status: string) => save(() => api(`/procurement/purchase-orders/${id}/status`, { method: "PATCH", body: JSON.stringify({ status }) }), `PO marked ${status.replaceAll("_", " ")}`);

  const addDelivery = () => save(async () => {
    await api("/procurement/deliveries", { method: "POST", body: JSON.stringify({ purchaseOrderId: Number(deliveryForm.purchaseOrderId), scheduledAt: deliveryForm.scheduledAt || null, reference: deliveryForm.reference, deliveryAddress: deliveryForm.deliveryAddress }) });
    setDeliveryForm({ purchaseOrderId: "", scheduledAt: "", reference: "", deliveryAddress: "" });
  }, "Delivery scheduled");
  const receiveDelivery = (id: number) => save(() => api(`/procurement/deliveries/${id}`, { method: "PATCH", body: JSON.stringify({ status: "received" }) }), "Delivery marked received");

  const buildPlan = () => save(async () => {
    if (!planQuoteId) throw new Error("Choose an estimate/quote first");
    await api(`/procurement/quotes/${planQuoteId}/plan`, { method: "POST" });
  }, "CREWON procurement plan created");

  const createPlanPos = (id: number) => save(
    () => api(`/procurement/plans/${id}/create-pos`, { method: "POST" }),
    "Purchase orders created from the CREWON plan"
  );

  const saveAuthority = () => save(
    () => api("/procurement/authority", { method: "PUT", body: JSON.stringify(authorityForm) }),
    "CREWON purchasing authority updated"
  );

  const selectedReceiptPo = useMemo(() => data.purchaseOrders.find((po) => String(po.id) === receiptForm.purchaseOrderId), [data.purchaseOrders, receiptForm.purchaseOrderId]);

  const recordReceipt = () => save(async () => {
    if (!receiptForm.purchaseOrderId || !receiptForm.purchaseOrderItemId || !receiptForm.quantityReceived) throw new Error("Choose the PO line and received quantity");
    await api("/procurement/goods-receipts", { method: "POST", body: JSON.stringify({
      purchaseOrderId: Number(receiptForm.purchaseOrderId), reference: receiptForm.reference,
      items: [{ purchaseOrderItemId: Number(receiptForm.purchaseOrderItemId), quantityReceived: Number(receiptForm.quantityReceived), condition: receiptForm.condition }],
    }) });
    setReceiptForm({ purchaseOrderId: "", reference: "", purchaseOrderItemId: "", quantityReceived: "", condition: "accepted" });
  }, "Goods receipt recorded");

  const recordSupplierInvoice = () => save(async () => {
    const po = data.purchaseOrders.find((p) => String(p.id) === invoiceForm.purchaseOrderId);
    if (!po || !invoiceForm.invoiceNumber) throw new Error("Choose a PO and enter the supplier invoice number");
    await api("/procurement/supplier-invoices", { method: "POST", body: JSON.stringify({
      supplierId: po.supplierId, purchaseOrderId: po.id, invoiceNumber: invoiceForm.invoiceNumber,
      invoiceDate: invoiceForm.invoiceDate, dueDate: invoiceForm.dueDate || null,
    }) });
    setInvoiceForm({ purchaseOrderId: "", invoiceNumber: "", invoiceDate: new Date().toISOString().slice(0,10), dueDate: "" });
  }, "Supplier invoice recorded from PO");

  const matchSupplierInvoice = (id: number) => save(
    () => api(`/procurement/supplier-invoices/${id}/match`, { method: "POST" }),
    "CREWON completed the three-way match"
  );
  const updateSiteRequest = (id:number,status:string) => save(
    () => api(`/supervisor/material-requests/${id}`, { method: "PATCH", body: JSON.stringify({ status }) }),
    `Site material request ${status}`
  );

  return <div className="space-y-6 p-4 md:p-6 lg:p-8">
    <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
      <div>
        <div className="flex items-center gap-2"><ShoppingCart className="h-6 w-6 text-primary"/><h1 className="text-2xl font-bold">Procurement</h1></div>
        <p className="mt-1 max-w-3xl text-sm text-muted-foreground">Supplier accounts, real price history, RFQs, purchase orders and site deliveries. This is the data layer CREWON will use instead of inventing material prices.</p>
      </div>
      <Button variant="outline" onClick={() => void load()} disabled={loading}><RefreshCw className={`mr-2 h-4 w-4 ${loading ? "animate-spin" : ""}`}/>Refresh</Button>
    </div>

    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-6">
      <Metric icon={Building2} label="Suppliers" value={data.summary?.suppliers ?? "—"}/>
      <Metric icon={Boxes} label="Products" value={data.summary?.products ?? "—"}/>
      <Metric icon={ClipboardList} label="Open RFQs" value={data.summary?.openRfqs ?? "—"}/>
      <Metric icon={ShoppingCart} label="Open POs" value={data.summary?.openPurchaseOrders ?? "—"}/>
      <Metric icon={Truck} label="Due deliveries" value={data.summary?.pendingDeliveries ?? "—"}/>
      <Metric icon={PoundSterling} label="Committed spend" value={data.summary ? gbp.format(data.summary.committedSpend) : "—"}/>
    </div>

    <Card className="border-primary/20 bg-primary/5"><CardContent className="p-4 text-sm"><strong>CREWON Procurement principle:</strong> prices stored here are attributable to a supplier/account/source. AI may help match products or read quotations later, but it must not present a guessed web price as your trade-account cost.</CardContent></Card>

    <Tabs defaultValue="planner" className="space-y-4">
      <TabsList className="h-auto flex-wrap justify-start">
        <TabsTrigger value="site-requests">Site Requests</TabsTrigger><TabsTrigger value="planner">BOM Planner</TabsTrigger><TabsTrigger value="authority">Authority</TabsTrigger><TabsTrigger value="receiving">Receiving</TabsTrigger><TabsTrigger value="invoices">Supplier Invoices</TabsTrigger><TabsTrigger value="suppliers">Suppliers</TabsTrigger><TabsTrigger value="products">Products & Prices</TabsTrigger><TabsTrigger value="rfqs">RFQs</TabsTrigger><TabsTrigger value="pos">Purchase Orders</TabsTrigger><TabsTrigger value="deliveries">Deliveries</TabsTrigger>
      </TabsList>

      <TabsContent value="site-requests" className="space-y-4">
        <Card><CardHeader><CardTitle className="text-base">Requests from site supervisors</CardTitle></CardHeader><CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">Site requests enter Procurement as controlled demand. Approval here does not place an order; it confirms Procurement should source or allocate the requirement.</p>
          {data.siteMaterialRequests.length ? <Table><TableHeader><TableRow><TableHead>Requested</TableHead><TableHead>Job</TableHead><TableHead>Material</TableHead><TableHead>Urgency</TableHead><TableHead>Status</TableHead><TableHead/></TableRow></TableHeader><TableBody>{data.siteMaterialRequests.map(r=><TableRow key={r.id}><TableCell>{new Date(r.createdAt).toLocaleDateString("en-GB")}</TableCell><TableCell>Job #{r.jobId}</TableCell><TableCell><div className="font-medium">{r.quantity} {r.unit} · {r.description}</div>{r.reason?<div className="text-xs text-muted-foreground">{r.reason}</div>:null}</TableCell><TableCell><Badge variant={r.urgency==="critical"?"destructive":r.urgency==="urgent"?"secondary":"outline"} className="capitalize">{r.urgency}</Badge></TableCell><TableCell><Badge variant="outline" className="capitalize">{r.status}</Badge></TableCell><TableCell>{r.status==="requested"?<div className="flex gap-1"><Button size="sm" onClick={()=>void updateSiteRequest(r.id,"approved")}>Approve</Button><Button size="sm" variant="outline" onClick={()=>void updateSiteRequest(r.id,"declined")}>Decline</Button></div>:r.status==="approved"?<Button size="sm" variant="outline" onClick={()=>void updateSiteRequest(r.id,"ordered")}>Mark ordered</Button>:r.status==="ordered"?<Button size="sm" variant="outline" onClick={()=>void updateSiteRequest(r.id,"delivered")}>Delivered</Button>:null}</TableCell></TableRow>)}</TableBody></Table> : <div className="py-10 text-center text-sm text-muted-foreground">No site material requests yet.</div>}
        </CardContent></Card>
      </TabsContent>

      <TabsContent value="planner" className="space-y-4">
        <Card className="border-primary/20"><CardHeader><CardTitle className="flex items-center gap-2 text-base"><WandSparkles className="h-4 w-4 text-primary"/>Estimate / BOM → Procurement</CardTitle></CardHeader><CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">Choose an estimate. CREWON converts its materials into a structured bill of materials, matches catalogue products, applies waste, compares recorded trade-account prices and creates an auditable purchasing recommendation.</p>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <div className="min-w-0 flex-1"><Field label="Estimate / quote"><Select value={planQuoteId} onValueChange={setPlanQuoteId}><SelectTrigger><SelectValue placeholder="Choose quote with materials"/></SelectTrigger><SelectContent>{data.quotes.filter(q=>Array.isArray(q.materials)&&q.materials.length).map(q=><SelectItem key={q.id} value={String(q.id)}>#{q.id} · {q.title} · {q.materials.length} material line(s)</SelectItem>)}</SelectContent></Select></Field></div>
            <Button onClick={buildPlan} disabled={saving || !planQuoteId}><WandSparkles className="mr-2 h-4 w-4"/>Build procurement plan</Button>
          </div>
        </CardContent></Card>
        <div className="space-y-3">{data.plans.map(plan=><Card key={plan.id}><CardContent className="p-4">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between"><div><div className="flex items-center gap-2"><span className="font-semibold">Plan #{plan.id}</span><Badge variant={plan.status==="ready"?"default":"outline"} className="capitalize">{plan.status}</Badge></div><div className="mt-1 text-sm text-muted-foreground">Quote #{plan.quoteId ?? "—"} · {plan.recommendation?.lines?.length ?? 0} BOM lines · {plan.missingItemCount} need pricing/matching</div></div><div className="flex flex-wrap items-center gap-4"><div><div className="text-xs text-muted-foreground">Optimised landed cost</div><div className="font-semibold">{gbp.format(plan.estimatedSubtotal)}</div>{plan.recommendation?.deliveryFees ? <div className="text-xs text-muted-foreground">incl. {gbp.format(plan.recommendation.deliveryFees)} delivery</div> : null}</div><div><div className="text-xs text-muted-foreground">Saving vs best complete supplier</div><div className="font-semibold text-emerald-500">{gbp.format(plan.savingsVsSingleSupplier)}</div></div><Button onClick={()=>void createPlanPos(plan.id)} disabled={saving || plan.status!=="ready"}>Create controlled POs</Button></div></div>
          {!!plan.recommendation?.lines?.length && <div className="mt-4 grid gap-2 md:grid-cols-2 xl:grid-cols-3">{plan.recommendation.lines.slice(0,6).map((line,i)=><div key={i} className="rounded-md border p-3 text-sm"><div className="font-medium">{line.description}</div><div className="text-muted-foreground">{line.quantity} {line.unit}</div><div className="mt-1">{line.best ? <><span className="text-primary">{line.best.supplierName}</span> · {gbp.format(line.best.lineTotal)}</> : <span className="text-amber-500">Needs catalogue match / price</span>}</div></div>)}</div>}
        </CardContent></Card>)}
        {!data.plans.length && <Card><CardContent className="py-10 text-center text-sm text-muted-foreground">No procurement plans yet. Build one from an estimate above.</CardContent></Card>}</div>
      </TabsContent>

      <TabsContent value="authority" className="space-y-4">
        <Card><CardHeader><CardTitle className="flex items-center gap-2 text-base"><ShieldCheck className="h-4 w-4 text-primary"/>CREWON Authority — Purchasing</CardTitle></CardHeader><CardContent className="space-y-5">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Autonomy mode"><Select value={authorityForm.mode} onValueChange={(v)=>setAuthorityForm({...authorityForm,mode:v as Authority["mode"]})}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent><SelectItem value="observe">Observe — recommend only</SelectItem><SelectItem value="assist">Assist — prepare actions for approval</SelectItem><SelectItem value="operate">Operate — auto-approve within rules</SelectItem></SelectContent></Select></Field>
            <Field label="Automatic purchase approval limit (£ inc VAT)"><Input type="number" min="0" step="50" value={authorityForm.autoApprovePurchaseLimit} onChange={(e)=>setAuthorityForm({...authorityForm,autoApprovePurchaseLimit:Number(e.target.value)||0})}/></Field>
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            <label className="flex items-start gap-3 rounded-md border p-3 text-sm"><input type="checkbox" className="mt-1" checked={authorityForm.preferredSuppliersOnly} onChange={(e)=>setAuthorityForm({...authorityForm,preferredSuppliersOnly:e.target.checked})}/><span><strong>Preferred suppliers only</strong><br/><span className="text-muted-foreground">CREWON will exclude non-preferred suppliers from automated recommendations.</span></span></label>
            <label className="flex items-start gap-3 rounded-md border p-3 text-sm"><input type="checkbox" className="mt-1" checked={authorityForm.requireKnownPriceSource} onChange={(e)=>setAuthorityForm({...authorityForm,requireKnownPriceSource:e.target.checked})}/><span><strong>Require attributable pricing</strong><br/><span className="text-muted-foreground">Do not auto-act on AI benchmark/unknown pricing.</span></span></label>
          </div>
          <div className="rounded-md bg-muted p-3 text-sm">{authorityForm.mode==="operate" ? <>CREWON may approve a generated PO automatically only when it satisfies these rules and totals <strong>{gbp.format(authorityForm.autoApprovePurchaseLimit)}</strong> or less. Larger orders remain approval-required.</> : <>CREWON will not autonomously approve purchases in <strong>{authorityForm.mode}</strong> mode.</>}</div>
          <Button onClick={saveAuthority} disabled={saving}>Save purchasing authority</Button>
        </CardContent></Card>
      </TabsContent>

      <TabsContent value="receiving" className="space-y-4">
        <Card><CardHeader><CardTitle className="text-base">Goods received</CardTitle></CardHeader><CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">Record what actually arrived. CREWON compares cumulative accepted quantities with the purchase order and automatically moves the PO to part-received or received.</p>
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-5">
            <Field label="Purchase order"><Select value={receiptForm.purchaseOrderId} onValueChange={(v)=>setReceiptForm({...receiptForm,purchaseOrderId:v,purchaseOrderItemId:""})}><SelectTrigger><SelectValue placeholder="Choose PO"/></SelectTrigger><SelectContent>{data.purchaseOrders.filter(po=>["ordered","part_received","approved"].includes(po.status)).map(po=><SelectItem key={po.id} value={String(po.id)}>{po.poNumber} · {po.supplierName}</SelectItem>)}</SelectContent></Select></Field>
            <Field label="PO line"><Select value={receiptForm.purchaseOrderItemId} onValueChange={(v)=>setReceiptForm({...receiptForm,purchaseOrderItemId:v})}><SelectTrigger><SelectValue placeholder="Choose item"/></SelectTrigger><SelectContent>{(selectedReceiptPo?.items ?? []).filter(i=>i.unit!=="delivery").map(i=><SelectItem key={i.id} value={String(i.id)}>{i.description} · ordered {i.quantity}</SelectItem>)}</SelectContent></Select></Field>
            <Field label="Quantity received"><Input type="number" min="0" step="0.001" value={receiptForm.quantityReceived} onChange={(e)=>setReceiptForm({...receiptForm,quantityReceived:e.target.value})}/></Field>
            <Field label="Condition"><Select value={receiptForm.condition} onValueChange={(v)=>setReceiptForm({...receiptForm,condition:v})}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent><SelectItem value="accepted">Accepted</SelectItem><SelectItem value="damaged">Damaged</SelectItem><SelectItem value="rejected">Rejected</SelectItem></SelectContent></Select></Field>
            <Field label="Delivery note / reference"><Input value={receiptForm.reference} onChange={(e)=>setReceiptForm({...receiptForm,reference:e.target.value})}/></Field>
          </div>
          <Button onClick={recordReceipt} disabled={saving}>Record goods received</Button>
        </CardContent></Card>
        <Card><CardHeader><CardTitle className="text-base">Recent receipts</CardTitle></CardHeader><CardContent><Table><TableHeader><TableRow><TableHead>Received</TableHead><TableHead>PO</TableHead><TableHead>Reference</TableHead><TableHead>Lines</TableHead></TableRow></TableHeader><TableBody>{data.goodsReceipts.map(r=><TableRow key={r.id}><TableCell>{new Date(r.receivedAt).toLocaleDateString("en-GB")}</TableCell><TableCell>PO #{r.purchaseOrderId}</TableCell><TableCell>{r.reference || "—"}</TableCell><TableCell>{r.items.length}</TableCell></TableRow>)}</TableBody></Table></CardContent></Card>
      </TabsContent>

      <TabsContent value="invoices" className="space-y-4">
        <Card><CardHeader><CardTitle className="text-base">Supplier invoice → three-way match</CardTitle></CardHeader><CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">For V1, create an invoice from the PO then edit/extract real invoice lines later. CREWON checks ordered quantity and cost against goods actually received and what the supplier invoiced.</p>
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            <Field label="Purchase order"><Select value={invoiceForm.purchaseOrderId} onValueChange={(v)=>setInvoiceForm({...invoiceForm,purchaseOrderId:v})}><SelectTrigger><SelectValue placeholder="Choose PO"/></SelectTrigger><SelectContent>{data.purchaseOrders.filter(po=>!["draft","cancelled"].includes(po.status)).map(po=><SelectItem key={po.id} value={String(po.id)}>{po.poNumber} · {po.supplierName} · {gbp.format(po.total)}</SelectItem>)}</SelectContent></Select></Field>
            <Field label="Supplier invoice no."><Input value={invoiceForm.invoiceNumber} onChange={(e)=>setInvoiceForm({...invoiceForm,invoiceNumber:e.target.value})}/></Field>
            <Field label="Invoice date"><Input type="date" value={invoiceForm.invoiceDate} onChange={(e)=>setInvoiceForm({...invoiceForm,invoiceDate:e.target.value})}/></Field>
            <Field label="Due date"><Input type="date" value={invoiceForm.dueDate} onChange={(e)=>setInvoiceForm({...invoiceForm,dueDate:e.target.value})}/></Field>
          </div>
          <Button onClick={recordSupplierInvoice} disabled={saving}>Record invoice from PO</Button>
        </CardContent></Card>
        <Card><CardHeader><CardTitle className="text-base">Supplier invoices</CardTitle></CardHeader><CardContent><Table><TableHeader><TableRow><TableHead>Invoice</TableHead><TableHead>Supplier</TableHead><TableHead>PO</TableHead><TableHead>Total</TableHead><TableHead>Status</TableHead><TableHead>Result</TableHead></TableRow></TableHeader><TableBody>{data.supplierInvoices.map(inv=><TableRow key={inv.id}><TableCell>{inv.invoiceNumber}</TableCell><TableCell>{inv.supplierName}</TableCell><TableCell>{inv.purchaseOrderId ? `PO #${inv.purchaseOrderId}` : "—"}</TableCell><TableCell>{gbp.format(inv.total)}</TableCell><TableCell><Badge variant={inv.status==="matched"?"default":inv.status==="variance"?"destructive":"outline"} className="capitalize">{inv.status}</Badge></TableCell><TableCell>{inv.status==="received" ? <Button size="sm" variant="outline" onClick={()=>void matchSupplierInvoice(inv.id)} disabled={saving}>Run 3-way match</Button> : inv.status==="variance" ? <span className="text-sm text-destructive">{inv.matchSummary?.issueCount ?? 0} issue(s)</span> : <span className="text-sm text-emerald-500">Matched</span>}</TableCell></TableRow>)}</TableBody></Table></CardContent></Card>
        {data.supplierInvoices.filter(i=>i.status==="variance" && i.matchSummary?.issues?.length).map(inv=><Card key={`issues-${inv.id}`} className="border-destructive/30"><CardHeader><CardTitle className="text-sm">Invoice {inv.invoiceNumber} — CREWON found variances</CardTitle></CardHeader><CardContent><ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">{inv.matchSummary!.issues!.map((issue,i)=><li key={i}>{issue}</li>)}</ul></CardContent></Card>)}
      </TabsContent>

      <TabsContent value="suppliers" className="space-y-4">
        <div className="grid gap-4 xl:grid-cols-2">
          <Card><CardHeader><CardTitle className="text-base">Add supplier</CardTitle></CardHeader><CardContent className="space-y-3">
            <Field label="Supplier / wholesaler"><Input value={supplierForm.name} onChange={(e)=>setSupplierForm({...supplierForm,name:e.target.value})} placeholder="e.g. CEF"/></Field>
            <div className="grid gap-3 sm:grid-cols-2"><Field label="Trade account number"><Input value={supplierForm.accountNumber} onChange={(e)=>setSupplierForm({...supplierForm,accountNumber:e.target.value})}/></Field><Field label="Branch"><Input value={supplierForm.branch} onChange={(e)=>setSupplierForm({...supplierForm,branch:e.target.value})} placeholder="Maldon"/></Field></div>
            <Button onClick={addSupplier} disabled={saving || !supplierForm.name.trim()}><Plus className="mr-2 h-4 w-4"/>Add supplier</Button>
          </CardContent></Card>
          <Card><CardHeader><CardTitle className="text-base">Add another trade account</CardTitle></CardHeader><CardContent className="space-y-3">
            <Field label="Supplier"><SupplierSelect suppliers={data.suppliers} value={accountForm.supplierId} onValue={(v)=>setAccountForm({...accountForm,supplierId:v})}/></Field>
            <div className="grid gap-3 sm:grid-cols-2"><Field label="Account name"><Input value={accountForm.accountName} onChange={(e)=>setAccountForm({...accountForm,accountName:e.target.value})}/></Field><Field label="Account number"><Input value={accountForm.accountNumber} onChange={(e)=>setAccountForm({...accountForm,accountNumber:e.target.value})}/></Field></div>
            <Button onClick={addAccount} disabled={saving || !accountForm.supplierId}>Add trade account</Button>
          </CardContent></Card>
        </div>
        <Card><CardContent className="p-0"><Table><TableHeader><TableRow><TableHead>Supplier</TableHead><TableHead>Trade account(s)</TableHead><TableHead>Pricing route</TableHead><TableHead>Status</TableHead></TableRow></TableHeader><TableBody>
          {data.suppliers.map((s)=><TableRow key={s.id}><TableCell className="font-medium">{s.name}{s.preferred && <Badge className="ml-2" variant="secondary">Preferred</Badge>}</TableCell><TableCell>{s.accounts.length ? s.accounts.map(a=><div key={a.id}>{a.accountNumber || a.accountName}{a.branch ? ` · ${a.branch}` : ""}</div>) : <span className="text-muted-foreground">No trade account yet</span>}</TableCell><TableCell>{s.accounts[0]?.pricingMethod || "manual"}</TableCell><TableCell className="capitalize">{s.status}</TableCell></TableRow>)}
          {!data.suppliers.length && <EmptyRow colSpan={4} text="Add your first wholesaler or supplier."/>}
        </TableBody></Table></CardContent></Card>
      </TabsContent>

      <TabsContent value="products" className="space-y-4">
        <div className="grid gap-4 xl:grid-cols-2">
          <Card><CardHeader><CardTitle className="text-base">Add canonical product</CardTitle></CardHeader><CardContent className="space-y-3">
            <Field label="Product"><Input value={productForm.name} onChange={(e)=>setProductForm({...productForm,name:e.target.value})} placeholder="e.g. 1.5mm² Twin & Earth 100m"/></Field>
            <div className="grid gap-3 sm:grid-cols-2"><Field label="Internal SKU"><Input value={productForm.sku} onChange={(e)=>setProductForm({...productForm,sku:e.target.value})}/></Field><Field label="Category"><Input value={productForm.category} onChange={(e)=>setProductForm({...productForm,category:e.target.value})} placeholder="Cable"/></Field></div>
            <Button onClick={addProduct} disabled={saving || !productForm.name.trim()}>Add product</Button>
          </CardContent></Card>
          <Card><CardHeader><CardTitle className="text-base">Record supplier/account price</CardTitle></CardHeader><CardContent className="space-y-3">
            <Field label="Product"><Select value={priceForm.productId} onValueChange={(v)=>setPriceForm({...priceForm,productId:v})}><SelectTrigger><SelectValue placeholder="Choose product"/></SelectTrigger><SelectContent>{data.products.map(p=><SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}</SelectContent></Select></Field>
            <div className="grid gap-3 sm:grid-cols-2"><Field label="Supplier"><SupplierSelect suppliers={data.suppliers} value={priceForm.supplierId} onValue={(v)=>setPriceForm({...priceForm,supplierId:v,supplierAccountId:""})}/></Field><Field label="Trade account"><Select value={priceForm.supplierAccountId || "none"} onValueChange={(v)=>setPriceForm({...priceForm,supplierAccountId:v==="none"?"":v})}><SelectTrigger><SelectValue placeholder="Optional"/></SelectTrigger><SelectContent><SelectItem value="none">No specific account</SelectItem>{selectedSupplier?.accounts.map(a=><SelectItem key={a.id} value={String(a.id)}>{a.accountNumber || a.accountName}</SelectItem>)}</SelectContent></Select></Field></div>
            <div className="grid gap-3 sm:grid-cols-3"><Field label="Supplier SKU"><Input value={priceForm.supplierSku} onChange={(e)=>setPriceForm({...priceForm,supplierSku:e.target.value})}/></Field><Field label="Unit cost (£)"><Input type="number" step="0.01" value={priceForm.unitCost} onChange={(e)=>setPriceForm({...priceForm,unitCost:e.target.value})}/></Field><Field label="Lead time (days)"><Input type="number" value={priceForm.leadTimeDays} onChange={(e)=>setPriceForm({...priceForm,leadTimeDays:e.target.value})}/></Field></div>
            <Button onClick={addPrice} disabled={saving || !priceForm.productId || !priceForm.supplierId || priceForm.unitCost===""}>Record real price</Button>
          </CardContent></Card>
        </div>
        <Card><CardContent className="p-0"><Table><TableHeader><TableRow><TableHead>Product</TableHead><TableHead>Best recorded price</TableHead><TableHead>Supplier</TableHead><TableHead>Other price records</TableHead></TableRow></TableHeader><TableBody>
          {data.products.map((p)=>{ const sorted=[...p.prices].sort((a,b)=>a.unitCost-b.unitCost); const best=sorted[0]; return <TableRow key={p.id}><TableCell><div className="font-medium">{p.name}</div><div className="text-xs text-muted-foreground">{p.category || "Uncategorised"} · {p.unit}</div></TableCell><TableCell className="font-semibold">{best ? gbp.format(best.unitCost) : "—"}</TableCell><TableCell>{best ? <><div>{best.supplierName}</div><div className="text-xs text-muted-foreground">{best.source}{best.leadTimeDays!=null?` · ${best.leadTimeDays}d lead`:""}</div></> : <span className="text-muted-foreground">No price recorded</span>}</TableCell><TableCell>{Math.max(0,p.prices.length-1)}</TableCell></TableRow>})}
          {!data.products.length && <EmptyRow colSpan={4} text="Build your product library, then attach each wholesaler's real trade price."/>}
        </TableBody></Table></CardContent></Card>
      </TabsContent>

      <TabsContent value="rfqs" className="space-y-4">
        <div className="grid gap-4 xl:grid-cols-2">
          <Card><CardHeader><CardTitle className="text-base">Create RFQ</CardTitle></CardHeader><CardContent className="space-y-3">
            <Field label="RFQ title"><Input value={rfqForm.title} onChange={(e)=>setRfqForm({...rfqForm,title:e.target.value})} placeholder="Smith Street lighting package"/></Field>
            <Field label="First item"><Input value={rfqForm.description} onChange={(e)=>setRfqForm({...rfqForm,description:e.target.value})} placeholder="60 × LED panels"/></Field>
            <div className="grid gap-3 sm:grid-cols-3"><Field label="Quantity"><Input type="number" value={rfqForm.quantity} onChange={(e)=>setRfqForm({...rfqForm,quantity:e.target.value})}/></Field><Field label="Unit"><Input value={rfqForm.unit} onChange={(e)=>setRfqForm({...rfqForm,unit:e.target.value})}/></Field><Field label="Reply due"><Input type="datetime-local" value={rfqForm.dueAt} onChange={(e)=>setRfqForm({...rfqForm,dueAt:e.target.value})}/></Field></div>
            <Button onClick={addRfq} disabled={saving || !rfqForm.title.trim() || !rfqForm.description.trim()}>Create RFQ</Button>
          </CardContent></Card>
          <Card><CardHeader><CardTitle className="text-base">Record supplier response</CardTitle></CardHeader><CardContent className="space-y-3">
            <Field label="RFQ"><Select value={rfqResponseForm.rfqId} onValueChange={(v)=>setRfqResponseForm({...rfqResponseForm,rfqId:v})}><SelectTrigger><SelectValue placeholder="Choose RFQ"/></SelectTrigger><SelectContent>{data.rfqs.map(r=><SelectItem key={r.id} value={String(r.id)}>{r.title}</SelectItem>)}</SelectContent></Select></Field>
            <Field label="Supplier"><SupplierSelect suppliers={data.suppliers} value={rfqResponseForm.supplierId} onValue={(v)=>setRfqResponseForm({...rfqResponseForm,supplierId:v})}/></Field>
            <div className="grid gap-3 sm:grid-cols-2"><Field label="Quoted total (£)"><Input type="number" step="0.01" value={rfqResponseForm.total} onChange={(e)=>setRfqResponseForm({...rfqResponseForm,total:e.target.value})}/></Field><Field label="Supplier reference"><Input value={rfqResponseForm.reference} onChange={(e)=>setRfqResponseForm({...rfqResponseForm,reference:e.target.value})}/></Field></div>
            <Button onClick={addRfqResponse} disabled={saving || !rfqResponseForm.rfqId || !rfqResponseForm.supplierId || !rfqResponseForm.total}>Record response</Button>
          </CardContent></Card>
        </div>
        <Card><CardContent className="p-0"><Table><TableHeader><TableRow><TableHead>RFQ</TableHead><TableHead>Items</TableHead><TableHead>Responses</TableHead><TableHead>Best total</TableHead><TableHead>Status</TableHead></TableRow></TableHeader><TableBody>
          {data.rfqs.map(r=>{const best=[...r.responses].sort((a,b)=>a.total-b.total)[0];return <TableRow key={r.id}><TableCell className="font-medium">{r.title}</TableCell><TableCell>{r.items.length}</TableCell><TableCell>{r.responses.length}</TableCell><TableCell>{best?`${gbp.format(best.total)} · ${best.supplierName}`:"—"}</TableCell><TableCell><Badge variant="outline" className="capitalize">{r.status.replaceAll("_"," ")}</Badge></TableCell></TableRow>})}
          {!data.rfqs.length && <EmptyRow colSpan={5} text="Use RFQs when account APIs aren't available: CREWON can still compare returned supplier quotes."/>}
        </TableBody></Table></CardContent></Card>
      </TabsContent>

      <TabsContent value="pos" className="space-y-4">
        <Card><CardHeader><CardTitle className="text-base">Create purchase order</CardTitle></CardHeader><CardContent className="space-y-3">
          <div className="grid gap-3 md:grid-cols-3"><Field label="Supplier"><SupplierSelect suppliers={data.suppliers} value={poForm.supplierId} onValue={(v)=>setPoForm({...poForm,supplierId:v,supplierAccountId:""})}/></Field><Field label="Trade account"><Select value={poForm.supplierAccountId || "none"} onValueChange={(v)=>setPoForm({...poForm,supplierAccountId:v==="none"?"":v})}><SelectTrigger><SelectValue placeholder="Optional"/></SelectTrigger><SelectContent><SelectItem value="none">No specific account</SelectItem>{poSupplier?.accounts.map(a=><SelectItem key={a.id} value={String(a.id)}>{a.accountNumber || a.accountName}</SelectItem>)}</SelectContent></Select></Field><Field label="Required by"><Input type="datetime-local" value={poForm.requiredBy} onChange={(e)=>setPoForm({...poForm,requiredBy:e.target.value})}/></Field></div>
          <Field label="Delivery address"><Input value={poForm.deliveryAddress} onChange={(e)=>setPoForm({...poForm,deliveryAddress:e.target.value})} placeholder="Site or branch delivery address"/></Field>
          <div className="grid gap-3 md:grid-cols-[2fr_120px_120px_160px]"><Field label="Item"><Input value={poForm.description} onChange={(e)=>setPoForm({...poForm,description:e.target.value})}/></Field><Field label="Qty"><Input type="number" value={poForm.quantity} onChange={(e)=>setPoForm({...poForm,quantity:e.target.value})}/></Field><Field label="Unit"><Input value={poForm.unit} onChange={(e)=>setPoForm({...poForm,unit:e.target.value})}/></Field><Field label="Unit cost (£)"><Input type="number" step="0.01" value={poForm.unitCost} onChange={(e)=>setPoForm({...poForm,unitCost:e.target.value})}/></Field></div>
          <div className="flex items-center justify-between gap-3"><div className="text-sm text-muted-foreground">V1 calculates 20% VAT. Approval thresholds will plug into CREWON Authority next.</div><Button onClick={addPo} disabled={saving || !poForm.supplierId || !poForm.description.trim() || poForm.unitCost===""}>Create draft PO</Button></div>
        </CardContent></Card>
        <Card><CardContent className="p-0"><Table><TableHeader><TableRow><TableHead>PO</TableHead><TableHead>Supplier</TableHead><TableHead>Total</TableHead><TableHead>Required</TableHead><TableHead>Status</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader><TableBody>
          {data.purchaseOrders.map(po=><TableRow key={po.id}><TableCell className="font-medium">{po.poNumber}<div className="text-xs text-muted-foreground">{po.items.length} item(s)</div></TableCell><TableCell>{po.supplierName}</TableCell><TableCell className="font-semibold">{gbp.format(po.total)}</TableCell><TableCell>{po.requiredBy?new Date(po.requiredBy).toLocaleDateString("en-GB"):"—"}</TableCell><TableCell><Badge variant={po.status==="received"?"default":"outline"} className="capitalize">{po.status.replaceAll("_"," ")}</Badge></TableCell><TableCell><div className="flex flex-wrap gap-1">{po.status==="draft"&&<Button size="sm" variant="outline" onClick={()=>void setPoStatus(po.id,"approved")}>Approve</Button>}{po.status==="approved"&&<Button size="sm" variant="outline" onClick={()=>void setPoStatus(po.id,"ordered")}>Mark ordered</Button>}{["ordered","part_received"].includes(po.status)&&<Button size="sm" variant="outline" onClick={()=>void setPoStatus(po.id,"received")}>Received</Button>}</div></TableCell></TableRow>)}
          {!data.purchaseOrders.length && <EmptyRow colSpan={6} text="Create a PO from known supplier/account pricing."/>}
        </TableBody></Table></CardContent></Card>
      </TabsContent>

      <TabsContent value="deliveries" className="space-y-4">
        <Card><CardHeader><CardTitle className="text-base">Schedule delivery</CardTitle></CardHeader><CardContent className="grid gap-3 md:grid-cols-4 md:items-end">
          <Field label="Purchase order"><Select value={deliveryForm.purchaseOrderId} onValueChange={(v)=>setDeliveryForm({...deliveryForm,purchaseOrderId:v})}><SelectTrigger><SelectValue placeholder="Choose PO"/></SelectTrigger><SelectContent>{data.purchaseOrders.filter(po=>po.status!=="cancelled").map(po=><SelectItem key={po.id} value={String(po.id)}>{po.poNumber} · {po.supplierName}</SelectItem>)}</SelectContent></Select></Field>
          <Field label="Expected"><Input type="datetime-local" value={deliveryForm.scheduledAt} onChange={(e)=>setDeliveryForm({...deliveryForm,scheduledAt:e.target.value})}/></Field>
          <Field label="Reference"><Input value={deliveryForm.reference} onChange={(e)=>setDeliveryForm({...deliveryForm,reference:e.target.value})} placeholder="Supplier delivery ref"/></Field>
          <Button onClick={addDelivery} disabled={saving || !deliveryForm.purchaseOrderId}><Truck className="mr-2 h-4 w-4"/>Schedule</Button>
        </CardContent></Card>
        <Card><CardContent className="p-0"><Table><TableHeader><TableRow><TableHead>Supplier</TableHead><TableHead>PO</TableHead><TableHead>Expected</TableHead><TableHead>Reference</TableHead><TableHead>Status</TableHead><TableHead></TableHead></TableRow></TableHeader><TableBody>
          {data.deliveries.map(d=><TableRow key={d.id}><TableCell className="font-medium">{d.supplierName||"—"}</TableCell><TableCell>{d.purchaseOrderId?`#${d.purchaseOrderId}`:"—"}</TableCell><TableCell>{d.scheduledAt?new Date(d.scheduledAt).toLocaleString("en-GB"):"—"}</TableCell><TableCell>{d.reference||"—"}</TableCell><TableCell><Badge variant={d.status==="received"?"default":"outline"} className="capitalize">{d.status.replaceAll("_"," ")}</Badge></TableCell><TableCell>{d.status!=="received"&&<Button size="sm" variant="outline" onClick={()=>void receiveDelivery(d.id)}><PackageCheck className="mr-1 h-4 w-4"/>Received</Button>}</TableCell></TableRow>)}
          {!data.deliveries.length && <EmptyRow colSpan={6} text="Scheduled site deliveries will appear here."/>}
        </TableBody></Table></CardContent></Card>
      </TabsContent>
    </Tabs>
  </div>;
}

function Metric({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: React.ReactNode }) {
  return <Card><CardContent className="p-4"><div className="flex items-center justify-between gap-2"><div><div className="text-xl font-semibold">{value}</div><div className="text-xs text-muted-foreground">{label}</div></div><Icon className="h-5 w-5 text-primary"/></div></CardContent></Card>;
}
function Field({ label, children }: { label: string; children: React.ReactNode }) { return <div><Label className="mb-1.5 block">{label}</Label>{children}</div>; }
function EmptyRow({ colSpan, text }: { colSpan: number; text: string }) { return <TableRow><TableCell colSpan={colSpan} className="py-8 text-center text-sm text-muted-foreground">{text}</TableCell></TableRow>; }
function SupplierSelect({ suppliers, value, onValue }: { suppliers: Supplier[]; value: string; onValue: (value: string) => void }) { return <Select value={value} onValueChange={onValue}><SelectTrigger><SelectValue placeholder="Choose supplier"/></SelectTrigger><SelectContent>{suppliers.map(s=><SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}</SelectContent></Select>; }
