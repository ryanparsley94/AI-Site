import type { Request, Response, NextFunction } from "express";
import { db, auditEventsTable } from "@workspace/db";
import { logger } from "../lib/logger";

const MUTATING_METHODS = new Set(["POST", "PUT", "PATCH", "DELETE"]);

function entityFromPath(path: string): { entityType: string | null; entityId: string | null } {
  const parts = path.split("?")[0]!.split("/").filter(Boolean);
  if (parts.length === 0) return { entityType: null, entityId: null };
  const entityType = parts[0] ?? null;
  const possibleId = parts[1];
  return {
    entityType,
    entityId: possibleId && /^\d+$/.test(possibleId) ? possibleId : null,
  };
}

/**
 * Best-effort immutable audit logging for protected business mutations.
 * Audit write failures never fail the user's original request.
 */
export function auditMutations(req: Request, res: Response, next: NextFunction): void {
  if (!MUTATING_METHODS.has(req.method)) {
    next();
    return;
  }

  const startedAt = Date.now();
  res.on("finish", () => {
    if (!req.companyId) return;
    const { entityType, entityId } = entityFromPath(req.path);
    const forwardedFor = req.headers["x-forwarded-for"];
    const ipAddress = Array.isArray(forwardedFor)
      ? forwardedFor[0]
      : forwardedFor?.split(",")[0]?.trim() ?? req.ip ?? null;

    void db.insert(auditEventsTable).values({
      companyId: req.companyId,
      userId: req.userId ?? null,
      actorType: req.actorType === "user" ? "user" : "system",
      actorLabel: req.actorType === "user" ? `user:${req.userId}` : "bootstrap-admin",
      action: `${req.method} ${req.path}`,
      entityType,
      entityId,
      metadata: {
        statusCode: res.statusCode,
        durationMs: Date.now() - startedAt,
      },
      ipAddress,
    }).catch((error) => {
      logger.warn({ error, path: req.path }, "Audit event write failed");
    });
  });

  next();
}
