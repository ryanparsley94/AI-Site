import type { Request, Response, NextFunction } from "express";

const PUBLIC_CROSS_ORIGIN_PREFIXES = [
  "/api/widget",
  "/api/support-questions",
];

function normaliseOrigin(value: string): string {
  return value.trim().replace(/\/$/, "").toLowerCase();
}

export function isPublicCrossOriginPath(path: string): boolean {
  return PUBLIC_CROSS_ORIGIN_PREFIXES.some((prefix) => path === prefix || path.startsWith(`${prefix}/`));
}

function configuredOrigins(): Set<string> {
  const raw = process.env.CREWON_APP_ORIGINS ?? process.env.CREWON_APP_ORIGIN ?? "";
  return new Set(raw.split(",").map(normaliseOrigin).filter(Boolean));
}

function requestOrigin(req: Request): string | null {
  const origin = req.get("origin");
  return origin ? normaliseOrigin(origin) : null;
}

function sameOriginForRequest(req: Request, origin: string): boolean {
  const forwardedProto = req.get("x-forwarded-proto")?.split(",")[0]?.trim();
  const proto = forwardedProto || req.protocol;
  const forwardedHost = req.get("x-forwarded-host")?.split(",")[0]?.trim();
  const host = forwardedHost || req.get("host");
  if (!host) return false;
  return normaliseOrigin(origin) === normaliseOrigin(`${proto}://${host}`);
}

export function isTrustedBrowserOrigin(req: Request, origin: string): boolean {
  if (sameOriginForRequest(req, origin)) return true;
  if (configuredOrigins().has(normaliseOrigin(origin))) return true;

  // Explicit local-development convenience only; never enabled in production.
  if (process.env.NODE_ENV !== "production") {
    try {
      const url = new URL(origin);
      return url.hostname === "localhost" || url.hostname === "127.0.0.1";
    } catch {
      return false;
    }
  }
  return false;
}

/**
 * Reject browser requests from untrusted origins before protected/auth actions
 * execute. This complements SameSite cookies and avoids relying on CORS alone
 * for CSRF protection (CORS can block reading a response but not necessarily
 * the request itself).
 *
 * Webhooks without an Origin header are allowed and authenticate separately.
 * The embeddable widget/support form are intentionally cross-origin public.
 */
export function rejectUntrustedBrowserOrigin(req: Request, res: Response, next: NextFunction): void {
  const origin = requestOrigin(req);
  if (!origin || isPublicCrossOriginPath(req.path)) {
    next();
    return;
  }

  if (!isTrustedBrowserOrigin(req, origin)) {
    res.status(403).json({ error: "Untrusted browser origin" });
    return;
  }

  next();
}
