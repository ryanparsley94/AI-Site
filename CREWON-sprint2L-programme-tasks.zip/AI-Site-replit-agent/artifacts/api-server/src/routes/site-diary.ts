import { Router } from "express";
import { and, desc, eq } from "drizzle-orm";
import {
  db, jobsTable, workforceProfilesTable, siteDiariesTable, siteEvidenceTable,
  siteProgressUpdatesTable, siteMaterialRequestsTable, siteIssuesTable, auditEventsTable
} from "@workspace/db";
import { openai } from "@workspace/integrations-openai-ai-server";
import { hasPermission } from "../lib/permissions";

const router=Router();
const positiveId=(v:unknown)=>{const n=Number(v);return Number.isInteger(n)&&n>0?n:null};
const text=(v:unknown)=>typeof v==="string"?v.trim():"";
const money=(v:unknown)=>Number(v??0);
async function currentWorker(companyId:number,userId?:number|null){
  if(!userId)return null;
  const [row]=await db.select().from(workforceProfilesTable).where(and(eq(workforceProfilesTable.companyId,companyId),eq(workforceProfilesTable.userId,userId))).limit(1);
  return row??null;
}
async function companyJob(companyId:number,jobId:number){
  const [row]=await db.select().from(jobsTable).where(and(eq(jobsTable.companyId,companyId),eq(jobsTable.id,jobId))).limit(1);
  return row??null;
}
function canWrite(req:any){return hasPermission(req,"workforce.approve")||hasPermission(req,"workforce.manage")||hasPermission(req,"jobs.update");}

router.post("/site-diary/analyse",async(req,res)=>{
  if(!canWrite(req))return res.status(403).json({error:"You do not have permission to submit a site diary"});
  const jobId=positiveId(req.body?.jobId),transcript=text(req.body?.transcript);
  if(!jobId||!transcript||!(await companyJob(req.companyId!,jobId)))return res.status(400).json({error:"Project and site diary transcript are required"});

  const prompt=`You are CREWON, a UK construction site operations assistant.
Analyse the supervisor's spoken/typed site diary strictly from the evidence given.
Do not invent quantities, client instructions, progress, costs or materials.

Site diary:
${transcript}

Return ONLY valid JSON:
{
  "summary":"short factual site summary",
  "progressPercent": number|null,
  "progressSummary":"progress statement or empty string",
  "blockers":"blockers/delays or empty string",
  "materialRequests":[
    {"description":"material","quantity":number|null,"unit":"each|m|m2|m3|sheet|bag|roll|length|other","urgency":"normal|urgent|critical","reason":"why needed"}
  ],
  "issues":[
    {"title":"short issue title","description":"factual description","issueType":"site|client_instruction|delay|quality|commercial|safety","severity":"low|medium|high|critical","potentialVariation":"no|review|yes","estimatedImpact":number|null}
  ],
  "potentialVariations":[
    {"title":"short title","reason":"why this may be extra scope","evidence":"words from diary supporting review"}
  ],
  "followUpQuestions":["only questions essential before an action can safely be committed"]
}
Rules:
- progressPercent must be null unless the supervisor explicitly states a percentage or an unambiguous overall percentage.
- material quantity must be null if not stated; never guess.
- potential variations are suggestions for commercial review, never approved variations.
- safety matters should be flagged but do not provide specialist safety certification or legal conclusions.
- use UK construction terminology and metric units.`;

  const completion=await openai.chat.completions.create({
    model:"gpt-5.6-luna",max_completion_tokens:1400,messages:[{role:"user",content:prompt}]
  });
  const content=completion.choices[0]?.message?.content??"{}";
  const match=content.match(/\{[\s\S]*\}/);
  if(!match)return res.status(502).json({error:"CREWON could not structure that diary"});
  try{
    const parsed=JSON.parse(match[0]);
    res.json(parsed);
  }catch{
    res.status(502).json({error:"CREWON returned an invalid diary analysis"});
  }
});

router.post("/site-diary",async(req,res)=>{
  if(!canWrite(req))return res.status(403).json({error:"You do not have permission to save a site diary"});
  const jobId=positiveId(req.body?.jobId),transcript=text(req.body?.transcript),structured=req.body?.structuredOutput??{};
  if(!jobId||!transcript||!(await companyJob(req.companyId!,jobId)))return res.status(400).json({error:"Project and transcript are required"});
  const worker=await currentWorker(req.companyId!,req.userId);
  const [diary]=await db.insert(siteDiariesTable).values({
    companyId:req.companyId!,jobId,workerId:worker?.id??null,submittedByUserId:req.userId??null,
    source:text(req.body?.source)||"voice_transcript",transcript,summary:text(structured?.summary)||null,
    progressPercent:Number.isFinite(Number(structured?.progressPercent))?String(Math.min(100,Math.max(0,Number(structured.progressPercent)))):null,
    structuredOutput:structured,status:"reviewed"
  }).returning();

  const evidence=Array.isArray(req.body?.evidence)?req.body.evidence:[];
  const cleanEvidence=evidence.slice(0,8).map((e:any)=>({
    companyId:req.companyId!,jobId,diaryId:diary.id,evidenceType:"photo",fileName:text(e.fileName)||null,
    mimeType:text(e.mimeType)||"image/jpeg",dataUrl:text(e.dataUrl),caption:text(e.caption)||null,metadata:{source:"mobile"}
  })).filter((e:any)=>e.dataUrl.startsWith("data:image/")&&e.dataUrl.length<=7_000_000);
  if(cleanEvidence.length)await db.insert(siteEvidenceTable).values(cleanEvidence);

  res.status(201).json({...diary,evidenceCount:cleanEvidence.length});
});

router.post("/site-diary/:id/commit",async(req,res)=>{
  if(!canWrite(req))return res.status(403).json({error:"You do not have permission to commit site diary actions"});
  const id=positiveId(req.params.id);if(!id)return res.status(400).json({error:"Invalid diary"});
  const [diary]=await db.select().from(siteDiariesTable).where(and(eq(siteDiariesTable.companyId,req.companyId!),eq(siteDiariesTable.id,id))).limit(1);
  if(!diary)return res.status(404).json({error:"Site diary not found"});
  if(diary.status==="committed")return res.status(409).json({error:"This site diary is already committed"});
  const structured=(diary.structuredOutput??{}) as any;
  const results:any={progress:false,materials:0,issues:0};

  if(Number.isFinite(Number(structured.progressPercent))&&text(structured.progressSummary)){
    await db.insert(siteProgressUpdatesTable).values({
      companyId:req.companyId!,jobId:diary.jobId,workerId:diary.workerId,
      progressPercent:String(Math.min(100,Math.max(0,Number(structured.progressPercent)))),
      summary:text(structured.progressSummary),blockers:text(structured.blockers)||null,submittedByUserId:req.userId??null
    });
    results.progress=true;
  }

  const materials=Array.isArray(structured.materialRequests)?structured.materialRequests:[];
  for(const m of materials){
    const quantity=Number(m.quantity);
    if(!text(m.description)||!Number.isFinite(quantity)||quantity<=0)continue; // ambiguous quantities stay in diary for human follow-up
    await db.insert(siteMaterialRequestsTable).values({
      companyId:req.companyId!,jobId:diary.jobId,requestedByWorkerId:diary.workerId,requestedByUserId:req.userId??null,
      description:text(m.description),quantity:String(quantity),unit:text(m.unit)||"each",
      urgency:["normal","urgent","critical"].includes(text(m.urgency))?text(m.urgency):"normal",
      reason:text(m.reason)||`From site diary #${diary.id}`,status:"requested"
    });
    results.materials++;
  }

  const issues=Array.isArray(structured.issues)?structured.issues:[];
  for(const i of issues){
    if(!text(i.title)||!text(i.description))continue;
    await db.insert(siteIssuesTable).values({
      companyId:req.companyId!,jobId:diary.jobId,reportedByWorkerId:diary.workerId,reportedByUserId:req.userId??null,
      issueType:text(i.issueType)||"site",title:text(i.title),description:text(i.description),
      severity:["low","medium","high","critical"].includes(text(i.severity))?text(i.severity):"medium",
      potentialVariation:["no","review","yes"].includes(text(i.potentialVariation))?text(i.potentialVariation):"review",
      estimatedImpact:String(Math.max(0,Number(i.estimatedImpact)||0)),metadata:{siteDiaryId:diary.id}
    });
    results.issues++;
  }

  const [updated]=await db.update(siteDiariesTable).set({status:"committed",committedAt:new Date()})
    .where(and(eq(siteDiariesTable.companyId,req.companyId!),eq(siteDiariesTable.id,id))).returning();

  await db.insert(auditEventsTable).values({
    companyId:req.companyId!,userId:req.userId??null,actorType:"user",action:"site.diary.committed",
    entityType:"site_diary",entityId:String(id),metadata:{jobId:diary.jobId,...results}
  });
  res.json({...updated,results});
});

router.get("/site-diary/jobs/:jobId",async(req,res)=>{
  const jobId=positiveId(req.params.jobId);if(!jobId)return res.status(400).json({error:"Invalid project"});
  if(!hasPermission(req,"workforce.read")&&!canWrite(req))return res.status(403).json({error:"You do not have permission to view site diaries"});
  const diaries=await db.select().from(siteDiariesTable).where(and(eq(siteDiariesTable.companyId,req.companyId!),eq(siteDiariesTable.jobId,jobId))).orderBy(desc(siteDiariesTable.createdAt));
  const evidence=await db.select().from(siteEvidenceTable).where(and(eq(siteEvidenceTable.companyId,req.companyId!),eq(siteEvidenceTable.jobId,jobId))).orderBy(desc(siteEvidenceTable.createdAt));
  res.json(diaries.map(d=>({...d,evidence:evidence.filter(e=>e.diaryId===d.id).map(e=>({id:e.id,fileName:e.fileName,mimeType:e.mimeType,dataUrl:e.dataUrl,caption:e.caption}))})));
});

export default router;
