import { Router } from "express";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import {
  db, jobsTable, quotesTable, purchaseOrdersTable, supplierInvoicesTable,
  projectCommercialSnapshotsTable, projectCostAdjustmentsTable,
  projectVariationsTable, marginProtectionAlertsTable, marginRecoveryActionsTable, procurementAuthorityTable, workforceTimeEntriesTable, workforceAllocationsTable, auditEventsTable,
} from "@workspace/db";
import { requirePermission } from "../lib/permissions";

const router = Router();
const money = (v: unknown) => Number(v ?? 0);
const positiveId = (v: unknown) => { const n=Number(v); return Number.isInteger(n)&&n>0?n:null; };
const text = (v: unknown) => typeof v === "string" ? v.trim() : "";

async function calculate(companyId:number, jobId:number, userId:number|null) {
  const [job] = await db.select().from(jobsTable).where(and(eq(jobsTable.id,jobId),eq(jobsTable.companyId,companyId))).limit(1);
  if (!job) return null;

  const [quote] = await db.select().from(quotesTable)
    .where(and(eq(quotesTable.companyId,companyId),eq(quotesTable.jobId,jobId)))
    .orderBy(desc(quotesTable.updatedAt)).limit(1);

  const contractValue = money(quote?.grandTotal || job.estimatedValue);
  const quotedMargin = money(quote?.marginAmount);
  const quotedMarginPct = money(quote?.marginPercent);
  // Prefer explicit quoted margin; fall back to margin percentage.
  const baselineMargin = quotedMargin > 0 ? quotedMargin : contractValue * quotedMarginPct / 100;
  const baselineCost = Math.max(0, contractValue - baselineMargin);
  const baselineMarginPercent = contractValue > 0 ? baselineMargin / contractValue * 100 : 0;

  const [poAgg] = await db.select({ total: sql<string>`coalesce(sum(${purchaseOrdersTable.subtotal}),0)` })
    .from(purchaseOrdersTable).where(and(eq(purchaseOrdersTable.companyId,companyId),eq(purchaseOrdersTable.jobId,jobId),
      inArray(purchaseOrdersTable.status,["approved","ordered","part_received","received"])));
  const committedProcurement = money(poAgg?.total);

  const [invoiceAgg] = await db.select({ total: sql<string>`coalesce(sum(${supplierInvoicesTable.subtotal}),0)` })
    .from(supplierInvoicesTable)
    .innerJoin(purchaseOrdersTable,eq(purchaseOrdersTable.id,supplierInvoicesTable.purchaseOrderId))
    .where(and(eq(supplierInvoicesTable.companyId,companyId),eq(purchaseOrdersTable.jobId,jobId),
      inArray(supplierInvoicesTable.status,["received","matched","variance","approved","exported"])));
  const invoicedProcurement = money(invoiceAgg?.total);
  const procurementVariance = Math.max(0, invoicedProcurement - committedProcurement);

  const adjustments = await db.select().from(projectCostAdjustmentsTable)
    .where(and(eq(projectCostAdjustmentsTable.companyId,companyId),eq(projectCostAdjustmentsTable.jobId,jobId)));
  const manualLabourActual = adjustments.filter(x=>x.type==="labour_actual").reduce((s,x)=>s+money(x.amount),0);
  const [approvedLabourAgg, plannedLabourAgg] = await Promise.all([
    db.select({ total: sql<string>`coalesce(sum(${workforceTimeEntriesTable.totalCost}),0)` })
      .from(workforceTimeEntriesTable)
      .where(and(eq(workforceTimeEntriesTable.companyId,companyId),eq(workforceTimeEntriesTable.jobId,jobId),eq(workforceTimeEntriesTable.status,"approved"))),
    db.select({ total: sql<string>`coalesce(sum(${workforceAllocationsTable.plannedCost}),0)` })
      .from(workforceAllocationsTable)
      .where(and(eq(workforceAllocationsTable.companyId,companyId),eq(workforceAllocationsTable.jobId,jobId),inArray(workforceAllocationsTable.status,["allocated","active","complete"]))),
  ]);
  const approvedTimesheetLabour = money(approvedLabourAgg[0]?.total);
  const plannedLabourCost = money(plannedLabourAgg[0]?.total);
  const labourActual = manualLabourActual + approvedTimesheetLabour;
  const labourPressure = plannedLabourCost > 0 ? Math.max(0, labourActual - plannedLabourCost) : labourActual;
  const otherActual = adjustments.filter(x=>x.type==="other_actual").reduce((s,x)=>s+money(x.amount),0);
  const forecastAdjustments = adjustments.filter(x=>x.type==="forecast_cost").reduce((s,x)=>s+money(x.amount),0);

  const variations = await db.select().from(projectVariationsTable)
    .where(and(eq(projectVariationsTable.companyId,companyId),eq(projectVariationsTable.jobId,jobId)));
  const approvedVariations = variations.filter(v=>v.status==="approved").reduce((s,v)=>s+money(v.value),0);
  const approvedVariationCost = variations.filter(v=>v.status==="approved").reduce((s,v)=>s+money(v.estimatedCost),0);
  const pendingVariations = variations.filter(v=>v.status==="pending").reduce((s,v)=>s+money(v.value),0);

  // Baseline cost already contains the estimated job cost. Replace the original procurement allowance
  // only when commitments/actuals are higher; add explicitly recorded cost pressure and approved variation cost.
  const materialPressure = Math.max(0, committedProcurement - Math.max(0, baselineCost * 0.35));
  const forecastFinalCost = Math.max(0, baselineCost + materialPressure + procurementVariance + labourPressure + otherActual + forecastAdjustments + approvedVariationCost);
  const forecastRevenue = contractValue + approvedVariations;
  const forecastMargin = forecastRevenue - forecastFinalCost;
  const forecastMarginPercent = forecastRevenue > 0 ? forecastMargin / forecastRevenue * 100 : 0;
  const marginMovement = forecastMargin - baselineMargin;
  const marginMovementPoints = forecastMarginPercent - baselineMarginPercent;

  const drivers:any[] = [];
  if (materialPressure > 0) drivers.push({category:"procurement",impact:-materialPressure,title:"Committed materials above baseline allowance"});
  if (procurementVariance > 0) drivers.push({category:"supplier_invoice",impact:-procurementVariance,title:"Supplier invoices above committed PO value"});
  if (labourPressure > 0) drivers.push({category:"labour",impact:-labourPressure,title:"Approved labour cost above planned allowance"});
  if (otherActual > 0) drivers.push({category:"other_cost",impact:-otherActual,title:"Other project cost pressure"});
  if (forecastAdjustments > 0) drivers.push({category:"forecast",impact:-forecastAdjustments,title:"Forecast cost adjustment"});
  if (approvedVariations > 0) drivers.push({category:"variation",impact:approvedVariations-approvedVariationCost,title:"Approved variations"});
  if (pendingVariations > 0) drivers.push({category:"variation_pending",impact:pendingVariations,title:"Pending variation value not yet included in revenue"});
  drivers.sort((a,b)=>Math.abs(b.impact)-Math.abs(a.impact));

  const riskLevel = forecastMarginPercent < 0 || marginMovementPoints <= -10 ? "critical"
    : marginMovementPoints <= -5 ? "high" : marginMovementPoints <= -2 ? "medium" : "low";

  const [snapshot] = await db.insert(projectCommercialSnapshotsTable).values({
    companyId,jobId,quoteId:quote?.id??null,contractValue:String(contractValue),baselineCost:String(baselineCost),
    baselineMargin:String(baselineMargin),baselineMarginPercent:String(baselineMarginPercent),
    committedProcurement:String(committedProcurement),invoicedProcurement:String(invoicedProcurement),
    procurementVariance:String(procurementVariance),approvedVariations:String(approvedVariations),
    pendingVariations:String(pendingVariations),labourActual:String(labourActual),otherActual:String(otherActual),
    forecastFinalCost:String(forecastFinalCost),forecastRevenue:String(forecastRevenue),forecastMargin:String(forecastMargin),
    forecastMarginPercent:String(forecastMarginPercent),marginMovement:String(marginMovement),
    marginMovementPoints:String(marginMovementPoints),riskLevel,drivers,
  }).returning();

  // Close previous generated alerts, then create only material current exceptions.
  await db.update(marginProtectionAlertsTable).set({status:"superseded"})
    .where(and(eq(marginProtectionAlertsTable.companyId,companyId),eq(marginProtectionAlertsTable.jobId,jobId),eq(marginProtectionAlertsTable.status,"open")));

  const alerts:any[]=[];
  if (marginMovementPoints <= -2) alerts.push({
    companyId,jobId,snapshotId:snapshot.id,severity:riskLevel==="critical"?"critical":riskLevel==="high"?"high":"medium",
    category:"margin",title:`Projected margin has moved ${Math.abs(marginMovementPoints).toFixed(1)} points`,
    explanation:`Baseline margin ${baselineMarginPercent.toFixed(1)}% is now forecast at ${forecastMarginPercent.toFixed(1)}%.`,
    recommendedAction:drivers[0]?.category==="procurement"?"Review committed material costs and supplier alternatives":
      drivers[0]?.category==="labour"?"Review labour productivity and remaining labour allowance":"Review the largest cost drivers and recover unapproved scope.",
    financialImpact:String(Math.abs(Math.min(0,marginMovement))),
  });
  if (pendingVariations > 0) alerts.push({
    companyId,jobId,snapshotId:snapshot.id,severity:"medium",category:"variation",
    title:`£${pendingVariations.toFixed(2)} of variations await approval`,
    explanation:"Pending variations are not included in forecast revenue until approved.",
    recommendedAction:"Secure written client approval before additional scope progresses.",financialImpact:String(pendingVariations),
  });
  if (procurementVariance > 0) alerts.push({
    companyId,jobId,snapshotId:snapshot.id,severity:"high",category:"supplier_invoice",
    title:"Supplier invoice cost exceeds committed procurement",
    explanation:`Current invoiced procurement is £${procurementVariance.toFixed(2)} above committed PO subtotal.`,
    recommendedAction:"Review three-way-match variances before approving supplier payment.",financialImpact:String(procurementVariance),
  });
  if (alerts.length) await db.insert(marginProtectionAlertsTable).values(alerts);

  await db.insert(auditEventsTable).values({
    companyId,userId,actorType:"system",actorLabel:"CREWON Margin Protection",
    action:"margin.snapshot.calculated",entityType:"job",entityId:String(jobId),
    metadata:{riskLevel,baselineMarginPercent,forecastMarginPercent,marginMovementPoints,approvedTimesheetLabour,plannedLabourCost,labourPressure}
  });
  return snapshot;
}

router.get("/margin-protection/portfolio",requirePermission("purchasing.read"),async(req,res)=>{
  const jobs=await db.select().from(jobsTable).where(eq(jobsTable.companyId,req.companyId!)).orderBy(desc(jobsTable.updatedAt));
  const rows=[];
  for(const job of jobs.slice(0,100)){
    const [latest]=await db.select().from(projectCommercialSnapshotsTable)
      .where(and(eq(projectCommercialSnapshotsTable.companyId,req.companyId!),eq(projectCommercialSnapshotsTable.jobId,job.id)))
      .orderBy(desc(projectCommercialSnapshotsTable.calculatedAt)).limit(1);
    rows.push({job,...latest});
  }
  res.json(rows);
});

router.get("/margin-protection/jobs/:jobId",requirePermission("purchasing.read"),async(req,res)=>{
  const jobId=positiveId(req.params.jobId); if(!jobId)return res.status(400).json({error:"Invalid project"});
  let [snapshot]=await db.select().from(projectCommercialSnapshotsTable)
    .where(and(eq(projectCommercialSnapshotsTable.companyId,req.companyId!),eq(projectCommercialSnapshotsTable.jobId,jobId)))
    .orderBy(desc(projectCommercialSnapshotsTable.calculatedAt)).limit(1);
  if(!snapshot)snapshot=await calculate(req.companyId!,jobId,req.userId??null) as any;
  if(!snapshot)return res.status(404).json({error:"Project not found"});
  const [alerts,variations,adjustments]=await Promise.all([
    db.select().from(marginProtectionAlertsTable).where(and(eq(marginProtectionAlertsTable.companyId,req.companyId!),eq(marginProtectionAlertsTable.jobId,jobId),eq(marginProtectionAlertsTable.status,"open"))).orderBy(desc(marginProtectionAlertsTable.createdAt)),
    db.select().from(projectVariationsTable).where(and(eq(projectVariationsTable.companyId,req.companyId!),eq(projectVariationsTable.jobId,jobId))).orderBy(desc(projectVariationsTable.createdAt)),
    db.select().from(projectCostAdjustmentsTable).where(and(eq(projectCostAdjustmentsTable.companyId,req.companyId!),eq(projectCostAdjustmentsTable.jobId,jobId))).orderBy(desc(projectCostAdjustmentsTable.occurredAt)),
  ]);
  res.json({snapshot,alerts,variations,adjustments});
});

router.post("/margin-protection/jobs/:jobId/recalculate",requirePermission("purchasing.manage"),async(req,res)=>{
  const jobId=positiveId(req.params.jobId); if(!jobId)return res.status(400).json({error:"Invalid project"});
  const snapshot=await calculate(req.companyId!,jobId,req.userId??null);
  if(!snapshot)return res.status(404).json({error:"Project not found"});
  res.status(201).json(snapshot);
});

router.post("/margin-protection/jobs/:jobId/costs",requirePermission("purchasing.manage"),async(req,res)=>{
  const jobId=positiveId(req.params.jobId), type=text(req.body?.type),description=text(req.body?.description),amount=Number(req.body?.amount);
  if(!jobId||!["labour_actual","other_actual","forecast_cost"].includes(type)||!description||!Number.isFinite(amount)||amount===0)
    return res.status(400).json({error:"Valid project, cost type, description and amount are required"});
  const [row]=await db.insert(projectCostAdjustmentsTable).values({companyId:req.companyId!,jobId,type,description,amount:String(amount),createdByUserId:req.userId??null}).returning();
  await calculate(req.companyId!,jobId,req.userId??null); res.status(201).json(row);
});

router.post("/margin-protection/jobs/:jobId/variations",requirePermission("purchasing.manage"),async(req,res)=>{
  const jobId=positiveId(req.params.jobId),description=text(req.body?.description),value=Number(req.body?.value),estimatedCost=Number(req.body?.estimatedCost??0);
  if(!jobId||!description||!Number.isFinite(value)||value===0)return res.status(400).json({error:"Project, description and variation value are required"});
  const [row]=await db.insert(projectVariationsTable).values({
    companyId:req.companyId!,jobId,reference:text(req.body?.reference)||null,description,value:String(value),
    estimatedCost:String(Number.isFinite(estimatedCost)?estimatedCost:0),status:"pending",createdByUserId:req.userId??null
  }).returning();
  await calculate(req.companyId!,jobId,req.userId??null); res.status(201).json(row);
});

router.patch("/margin-protection/variations/:id",requirePermission("purchasing.manage"),async(req,res)=>{
  const id=positiveId(req.params.id),status=text(req.body?.status);
  if(!id||!["pending","approved","rejected"].includes(status))return res.status(400).json({error:"Invalid variation status"});
  const [row]=await db.update(projectVariationsTable).set({
    status,clientApprovalReference:text(req.body?.clientApprovalReference)||null,approvedAt:status==="approved"?new Date():null
  }).where(and(eq(projectVariationsTable.id,id),eq(projectVariationsTable.companyId,req.companyId!))).returning();
  if(!row)return res.status(404).json({error:"Variation not found"});
  await calculate(req.companyId!,row.jobId,req.userId??null); res.json(row);
});

router.patch("/margin-protection/alerts/:id/acknowledge",requirePermission("purchasing.manage"),async(req,res)=>{
  const id=positiveId(req.params.id); if(!id)return res.status(400).json({error:"Invalid alert"});
  const [row]=await db.update(marginProtectionAlertsTable).set({status:"acknowledged",acknowledgedByUserId:req.userId??null,acknowledgedAt:new Date()})
    .where(and(eq(marginProtectionAlertsTable.id,id),eq(marginProtectionAlertsTable.companyId,req.companyId!))).returning();
  if(!row)return res.status(404).json({error:"Alert not found"}); res.json(row);
});


router.get("/margin-protection/director-summary",requirePermission("purchasing.read"),async(req,res)=>{
  const companyId=req.companyId!;
  const jobs=await db.select().from(jobsTable).where(eq(jobsTable.companyId,companyId));
  const latest:any[]=[];
  for(const job of jobs){
    const [s]=await db.select().from(projectCommercialSnapshotsTable)
      .where(and(eq(projectCommercialSnapshotsTable.companyId,companyId),eq(projectCommercialSnapshotsTable.jobId,job.id)))
      .orderBy(desc(projectCommercialSnapshotsTable.calculatedAt)).limit(1);
    if(s)latest.push({job,snapshot:s});
  }
  const forecastRevenue=latest.reduce((n,x)=>n+money(x.snapshot.forecastRevenue),0);
  const forecastMargin=latest.reduce((n,x)=>n+money(x.snapshot.forecastMargin),0);
  const baselineMargin=latest.reduce((n,x)=>n+money(x.snapshot.baselineMargin),0);
  const marginAtRisk=Math.max(0,baselineMargin-forecastMargin);
  const riskCounts={critical:0,high:0,medium:0,low:0} as Record<string,number>;
  latest.forEach(x=>riskCounts[x.snapshot.riskLevel]=(riskCounts[x.snapshot.riskLevel]||0)+1);
  const [alerts,recovery]=await Promise.all([
    db.select().from(marginProtectionAlertsTable).where(and(eq(marginProtectionAlertsTable.companyId,companyId),eq(marginProtectionAlertsTable.status,"open"))),
    db.select().from(marginRecoveryActionsTable).where(and(eq(marginRecoveryActionsTable.companyId,companyId),inArray(marginRecoveryActionsTable.status,["proposed","approved"])))
  ]);
  res.json({
    projects:latest.length,forecastRevenue,forecastMargin,
    forecastMarginPercent:forecastRevenue?forecastMargin/forecastRevenue*100:0,
    baselineMargin,marginAtRisk,riskCounts,openAlerts:alerts.length,
    proposedRecovery:recovery.reduce((n,x)=>n+money(x.estimatedRecovery),0),
    projectsByRisk:latest.sort((a,b)=>({critical:4,high:3,medium:2,low:1}[b.snapshot.riskLevel as "critical"]||0)-({critical:4,high:3,medium:2,low:1}[a.snapshot.riskLevel as "critical"]||0))
  });
});

router.post("/margin-protection/jobs/:jobId/recovery-actions/generate",requirePermission("purchasing.manage"),async(req,res)=>{
  const jobId=positiveId(req.params.jobId); if(!jobId)return res.status(400).json({error:"Invalid project"});
  const companyId=req.companyId!;
  const [snapshot]=await db.select().from(projectCommercialSnapshotsTable)
    .where(and(eq(projectCommercialSnapshotsTable.companyId,companyId),eq(projectCommercialSnapshotsTable.jobId,jobId)))
    .orderBy(desc(projectCommercialSnapshotsTable.calculatedAt)).limit(1);
  if(!snapshot)return res.status(404).json({error:"Calculate Margin Protection first"});
  const [authority]=await db.select().from(procurementAuthorityTable).where(eq(procurementAuthorityTable.companyId,companyId)).limit(1);
  const mode=authority?.mode||"assist";
  await db.update(marginRecoveryActionsTable).set({status:"dismissed"})
    .where(and(eq(marginRecoveryActionsTable.companyId,companyId),eq(marginRecoveryActionsTable.jobId,jobId),eq(marginRecoveryActionsTable.status,"proposed")));
  const drivers=(snapshot.drivers as any[])||[]; const actions:any[]=[];
  for(const d of drivers.slice(0,5)){
    const loss=Math.max(0,-money(d.impact)); if(!loss && d.category!=="variation_pending")continue;
    if(d.category==="procurement")actions.push({category:d.category,title:"Re-source remaining material commitments",action:"Compare uncommitted material requirements against current preferred-supplier landed cost and present lower-cost substitutions for approval.",estimatedRecovery:String(loss*.35)});
    else if(d.category==="supplier_invoice")actions.push({category:d.category,title:"Hold invoice variance for review",action:"Keep unmatched supplier invoice variance outside the approved-payment queue until PO / receipt / invoice discrepancy is resolved.",estimatedRecovery:String(loss)});
    else if(d.category==="labour")actions.push({category:d.category,title:"Labour productivity review",action:"Compare remaining labour allowance with progress and propose crew/programme changes before additional labour is committed.",estimatedRecovery:String(loss*.25)});
    else if(d.category==="variation_pending")actions.push({category:d.category,title:"Recover pending variation value",action:"Prepare the pending variation evidence pack and request written client approval before further out-of-scope work.",estimatedRecovery:String(Math.max(0,money(d.impact)))});
    else if(loss)actions.push({category:d.category,title:"Review commercial cost pressure",action:"Escalate the cost driver to the project commercial owner with evidence and a recovery decision.",estimatedRecovery:String(loss*.25)});
  }
  const values=actions.map(a=>({companyId,jobId,snapshotId:snapshot.id,...a,authorityMode:mode,
    status:"proposed",requiresHumanApproval:true,metadata:{generatedBy:"CREWON",riskLevel:snapshot.riskLevel}}));
  const rows=values.length?await db.insert(marginRecoveryActionsTable).values(values).returning():[];
  res.status(201).json(rows);
});

router.get("/margin-protection/jobs/:jobId/recovery-actions",requirePermission("purchasing.read"),async(req,res)=>{
  const jobId=positiveId(req.params.jobId);if(!jobId)return res.status(400).json({error:"Invalid project"});
  res.json(await db.select().from(marginRecoveryActionsTable)
    .where(and(eq(marginRecoveryActionsTable.companyId,req.companyId!),eq(marginRecoveryActionsTable.jobId,jobId)))
    .orderBy(desc(marginRecoveryActionsTable.createdAt)));
});

router.patch("/margin-protection/recovery-actions/:id",requirePermission("purchasing.manage"),async(req,res)=>{
  const id=positiveId(req.params.id),status=text(req.body?.status);
  if(!id||!["approved","actioned","dismissed"].includes(status))return res.status(400).json({error:"Invalid recovery action status"});
  const changes:any={status};
  if(status==="approved"){changes.approvedByUserId=req.userId??null;changes.approvedAt=new Date();}
  if(status==="actioned")changes.actionedAt=new Date();
  const [row]=await db.update(marginRecoveryActionsTable).set(changes)
    .where(and(eq(marginRecoveryActionsTable.companyId,req.companyId!),eq(marginRecoveryActionsTable.id,id))).returning();
  if(!row)return res.status(404).json({error:"Recovery action not found"});
  await db.insert(auditEventsTable).values({companyId:req.companyId!,userId:req.userId??null,actorType:"user",actorLabel:"CREWON user",
    action:`margin.recovery.${status}`,entityType:"margin_recovery_action",entityId:String(id),metadata:{jobId:row.jobId,estimatedRecovery:row.estimatedRecovery}});
  res.json(row);
});

export default router;
