import { Router } from "express";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import {
  db, jobsTable, quotesTable, workforceAllocationsTable, workforceProfilesTable, workforceTimeEntriesTable,
  siteProgressUpdatesTable, siteIssuesTable, siteMaterialRequestsTable, deliveriesTable, purchaseOrdersTable,
  suppliersTable, supplierInvoicesTable, projectVariationsTable, projectCommercialSnapshotsTable,
  marginProtectionAlertsTable, siteDiariesTable, siteEvidenceTable, projectTasksTable, projectMilestonesTable
} from "@workspace/db";
import { hasPermission } from "../lib/permissions";

const router=Router();
const positiveId=(v:unknown)=>{const n=Number(v);return Number.isInteger(n)&&n>0?n:null};
const money=(v:unknown)=>Number(v??0);
function canRead(req:any){
  return hasPermission(req,"jobs.read")||hasPermission(req,"jobs.update")||hasPermission(req,"jobs.manage")||
    hasPermission(req,"workforce.read")||hasPermission(req,"finance.read")||hasPermission(req,"finance.manage");
}

router.get("/projects/:jobId/command-centre",async(req,res)=>{
  if(!canRead(req))return res.status(403).json({error:"You do not have permission to view this project"});
  const jobId=positiveId(req.params.jobId);if(!jobId)return res.status(400).json({error:"Invalid project"});
  const companyId=req.companyId!;
  const [job]=await db.select().from(jobsTable).where(and(eq(jobsTable.companyId,companyId),eq(jobsTable.id,jobId))).limit(1);
  if(!job)return res.status(404).json({error:"Project not found"});

  const [quote,allocations,times,progress,issues,materials,deliveries,pos,invoices,variations,commercial,alerts,diaries,evidence,tasks,milestones]=await Promise.all([
    db.select().from(quotesTable).where(and(eq(quotesTable.companyId,companyId),eq(quotesTable.jobId,jobId))).orderBy(desc(quotesTable.updatedAt)).limit(1),
    db.select({
      id:workforceAllocationsTable.id,workerId:workforceProfilesTable.id,workerName:workforceProfilesTable.name,
      role:workforceAllocationsTable.role,plannedHours:workforceAllocationsTable.plannedHours,plannedCost:workforceAllocationsTable.plannedCost,
      status:workforceAllocationsTable.status
    }).from(workforceAllocationsTable).innerJoin(workforceProfilesTable,eq(workforceProfilesTable.id,workforceAllocationsTable.workerId))
      .where(and(eq(workforceAllocationsTable.companyId,companyId),eq(workforceAllocationsTable.jobId,jobId),inArray(workforceAllocationsTable.status,["allocated","active","complete"]))),
    db.select().from(workforceTimeEntriesTable).where(and(eq(workforceTimeEntriesTable.companyId,companyId),eq(workforceTimeEntriesTable.jobId,jobId))),
    db.select().from(siteProgressUpdatesTable).where(and(eq(siteProgressUpdatesTable.companyId,companyId),eq(siteProgressUpdatesTable.jobId,jobId))).orderBy(desc(siteProgressUpdatesTable.createdAt)).limit(1),
    db.select().from(siteIssuesTable).where(and(eq(siteIssuesTable.companyId,companyId),eq(siteIssuesTable.jobId,jobId))).orderBy(desc(siteIssuesTable.createdAt)),
    db.select().from(siteMaterialRequestsTable).where(and(eq(siteMaterialRequestsTable.companyId,companyId),eq(siteMaterialRequestsTable.jobId,jobId))).orderBy(desc(siteMaterialRequestsTable.createdAt)),
    db.select({
      id:deliveriesTable.id,status:deliveriesTable.status,reference:deliveriesTable.reference,scheduledAt:deliveriesTable.scheduledAt,
      receivedAt:deliveriesTable.receivedAt,supplierName:suppliersTable.name,poNumber:purchaseOrdersTable.poNumber
    }).from(deliveriesTable).leftJoin(suppliersTable,eq(suppliersTable.id,deliveriesTable.supplierId))
      .leftJoin(purchaseOrdersTable,eq(purchaseOrdersTable.id,deliveriesTable.purchaseOrderId))
      .where(and(eq(deliveriesTable.companyId,companyId),eq(deliveriesTable.jobId,jobId))).orderBy(desc(deliveriesTable.createdAt)),
    db.select().from(purchaseOrdersTable).where(and(eq(purchaseOrdersTable.companyId,companyId),eq(purchaseOrdersTable.jobId,jobId))).orderBy(desc(purchaseOrdersTable.createdAt)),
    db.select({
      id:supplierInvoicesTable.id,invoiceNumber:supplierInvoicesTable.invoiceNumber,total:supplierInvoicesTable.total,
      status:supplierInvoicesTable.status,matchSummary:supplierInvoicesTable.matchSummary,invoiceDate:supplierInvoicesTable.invoiceDate
    }).from(supplierInvoicesTable).innerJoin(purchaseOrdersTable,eq(purchaseOrdersTable.id,supplierInvoicesTable.purchaseOrderId))
      .where(and(eq(supplierInvoicesTable.companyId,companyId),eq(purchaseOrdersTable.jobId,jobId))).orderBy(desc(supplierInvoicesTable.invoiceDate)),
    db.select().from(projectVariationsTable).where(and(eq(projectVariationsTable.companyId,companyId),eq(projectVariationsTable.jobId,jobId))).orderBy(desc(projectVariationsTable.createdAt)),
    db.select().from(projectCommercialSnapshotsTable).where(and(eq(projectCommercialSnapshotsTable.companyId,companyId),eq(projectCommercialSnapshotsTable.jobId,jobId))).orderBy(desc(projectCommercialSnapshotsTable.calculatedAt)).limit(1),
    db.select().from(marginProtectionAlertsTable).where(and(eq(marginProtectionAlertsTable.companyId,companyId),eq(marginProtectionAlertsTable.jobId,jobId),eq(marginProtectionAlertsTable.status,"open"))).orderBy(desc(marginProtectionAlertsTable.createdAt)),
    db.select().from(siteDiariesTable).where(and(eq(siteDiariesTable.companyId,companyId),eq(siteDiariesTable.jobId,jobId))).orderBy(desc(siteDiariesTable.createdAt)).limit(10),
    db.select().from(siteEvidenceTable).where(and(eq(siteEvidenceTable.companyId,companyId),eq(siteEvidenceTable.jobId,jobId))).orderBy(desc(siteEvidenceTable.createdAt)),
    db.select().from(projectTasksTable).where(and(eq(projectTasksTable.companyId,companyId),eq(projectTasksTable.jobId,jobId))).orderBy(projectTasksTable.sortOrder,projectTasksTable.plannedStart),
    db.select().from(projectMilestonesTable).where(and(eq(projectMilestonesTable.companyId,companyId),eq(projectMilestonesTable.jobId,jobId))).orderBy(projectMilestonesTable.sortOrder,projectMilestonesTable.targetDate)
  ]);

  const q=quote[0]??null, c=commercial[0]??null, p=progress[0]??null;
  const approvedTimes=times.filter(t=>t.status==="approved");
  const plannedHours=allocations.reduce((s,x)=>s+money(x.plannedHours),0);
  const plannedLabour=allocations.reduce((s,x)=>s+money(x.plannedCost),0);
  const actualHours=approvedTimes.reduce((s,x)=>s+money(x.regularHours)+money(x.overtimeHours),0);
  const actualLabour=approvedTimes.reduce((s,x)=>s+money(x.totalCost),0);
  const committedProcurement=pos.filter(po=>["approved","ordered","part_received","received"].includes(po.status)).reduce((s,po)=>s+money(po.subtotal),0);
  const invoiceTotal=invoices.reduce((s,i)=>s+money(i.total),0);
  const openIssues=issues.filter(i=>["open","reviewing","escalated"].includes(i.status));
  const openMaterials=materials.filter(m=>["requested","approved","ordered"].includes(m.status));
  const pendingVariations=variations.filter(v=>v.status==="pending");
  const approvedVariations=variations.filter(v=>v.status==="approved");
  const now=Date.now();
  const lateTasks=tasks.filter(t=>t.status!=="complete"&&t.plannedFinish&&new Date(t.plannedFinish).getTime()<now);
  const blockedTasks=tasks.filter(t=>t.status==="blocked");
  const criticalLate=lateTasks.filter(t=>t.criticalPath);
  const taskHours=tasks.reduce((s,t)=>s+money(t.plannedHours),0);
  const programmeProgress=taskHours>0?tasks.reduce((s,t)=>s+money(t.plannedHours)*money(t.progressPercent)/100,0)/taskHours*100:(tasks.length?tasks.reduce((s,t)=>s+money(t.progressPercent),0)/tasks.length:0);
  const programmeRisk=criticalLate.length?"critical":lateTasks.length||blockedTasks.some(t=>t.criticalPath)?"high":blockedTasks.length?"medium":"low";

  const attention:any[]=[];
  for(const a of alerts.slice(0,5))attention.push({type:"commercial",severity:a.severity,title:a.title,detail:a.explanation,action:a.recommendedAction});
  for(const i of openIssues.filter(i=>["high","critical"].includes(i.severity)).slice(0,5))attention.push({type:"issue",severity:i.severity,title:i.title,detail:i.description,action:i.potentialVariation!=="no"?"Commercial variation review recommended":"Resolve / assign site issue"});
  for(const m of openMaterials.filter(m=>["urgent","critical"].includes(m.urgency)).slice(0,5))attention.push({type:"materials",severity:m.urgency==="critical"?"critical":"high",title:`${money(m.quantity)} ${m.unit} · ${m.description}`,detail:m.reason||"Urgent site material requirement",action:"Review in Procurement"});
  for(const i of invoices.filter(i=>i.status==="variance").slice(0,5))attention.push({type:"invoice",severity:"high",title:`Supplier invoice ${i.invoiceNumber} has variances`,detail:`${(i.matchSummary as any)?.issueCount??0} three-way match issue(s)`,action:"Review before supplier payment"});
  if(["high","critical"].includes(programmeRisk))attention.push({type:"programme",severity:programmeRisk,title:criticalLate.length?`${criticalLate.length} critical-path task(s) late`:"Project programme at risk",detail:`${lateTasks.length} late · ${blockedTasks.length} blocked · ${programmeProgress.toFixed(1)}% programme progress`,action:"Review programme dependencies and recovery sequencing"});
  attention.sort((a,b)=>({critical:4,high:3,medium:2,low:1}[b.severity as "critical"]||0)-({critical:4,high:3,medium:2,low:1}[a.severity as "critical"]||0));

  res.json({
    job,
    quote:q?{...q,grandTotal:money(q.grandTotal),marginPercent:money(q.marginPercent),marginAmount:money(q.marginAmount),totalIncVat:money(q.totalIncVat)}:null,
    progress:p?{...p,progressPercent:money(p.progressPercent)}:null,
    workforce:{
      crew:allocations.map(a=>({...a,plannedHours:money(a.plannedHours),plannedCost:money(a.plannedCost)})),
      plannedHours,plannedLabour,actualHours,actualLabour,
      pendingTimesheets:times.filter(t=>t.status==="submitted").length
    },
    procurement:{
      committed:committedProcurement,purchaseOrders:pos.length,openPurchaseOrders:pos.filter(po=>["draft","approval_required","approved","ordered","part_received"].includes(po.status)).length,
      supplierInvoices:invoices.length,invoiceTotal,invoiceVariances:invoices.filter(i=>i.status==="variance").length,
      deliveries:deliveries.map(d=>d),openDeliveries:deliveries.filter(d=>["scheduled","in_transit","part_received"].includes(d.status)).length,
      materialRequests:openMaterials.map(m=>({...m,quantity:money(m.quantity)}))
    },
    commercial:c?{
      forecastRevenue:money(c.forecastRevenue),forecastFinalCost:money(c.forecastFinalCost),baselineMargin:money(c.baselineMargin),
      baselineMarginPercent:money(c.baselineMarginPercent),forecastMargin:money(c.forecastMargin),forecastMarginPercent:money(c.forecastMarginPercent),
      marginMovement:money(c.marginMovement),marginMovementPoints:money(c.marginMovementPoints),riskLevel:c.riskLevel,drivers:c.drivers
    }:null,
    variations:{
      pending:pendingVariations.map(v=>({...v,value:money(v.value),estimatedCost:money(v.estimatedCost)})),
      approved:approvedVariations.map(v=>({...v,value:money(v.value),estimatedCost:money(v.estimatedCost)})),
      pendingValue:pendingVariations.reduce((s,v)=>s+money(v.value),0),
      approvedValue:approvedVariations.reduce((s,v)=>s+money(v.value),0)
    },
    programme:{
      progress:programmeProgress,risk:programmeRisk,lateCount:lateTasks.length,criticalLateCount:criticalLate.length,blockedCount:blockedTasks.length,
      tasks:tasks.map(t=>({...t,plannedHours:money(t.plannedHours),progressPercent:money(t.progressPercent)})),
      milestones
    },
    site:{
      openIssues:openIssues.map(i=>({...i,estimatedImpact:money(i.estimatedImpact)})),
      diaries:diaries.map(d=>({...d,progressPercent:d.progressPercent===null?null:money(d.progressPercent),evidenceCount:evidence.filter(e=>e.diaryId===d.id).length})),
      photoCount:evidence.length
    },
    attention:attention.slice(0,12)
  });
});

export default router;
