import { Router } from "express";
import { createHash } from "crypto";
import { and, eq, gt } from "drizzle-orm";
import { db, companyMembersTable, teamInvitationsTable, usersTable } from "@workspace/db";
import { hashPassword } from "../lib/password-auth";
import { issueUserSession } from "../lib/adminAuth";

const router = Router();

router.post("/auth/accept-invite", async (req, res) => {
  const token = typeof req.body?.token === "string" ? req.body.token : "";
  const name = typeof req.body?.name === "string" ? req.body.name.trim() : "";
  const password = typeof req.body?.password === "string" ? req.body.password : "";
  if (token.length < 32) return res.status(400).json({ error: "Invalid invitation token" });
  if (name.length < 2 || name.length > 150) return res.status(400).json({ error: "Your name is required" });
  if (password.length < 12 || password.length > 512) return res.status(400).json({ error: "Password must be at least 12 characters" });

  const tokenHash = createHash("sha256").update(token).digest("hex");
  const [invite] = await db.select().from(teamInvitationsTable).where(and(
    eq(teamInvitationsTable.tokenHash, tokenHash),
    eq(teamInvitationsTable.status, "pending"),
    gt(teamInvitationsTable.expiresAt, new Date()),
  )).limit(1);
  if (!invite) return res.status(410).json({ error: "This invitation is invalid or has expired" });

  const result = await db.transaction(async (tx) => {
    let [user] = await tx.select().from(usersTable).where(eq(usersTable.email, invite.email)).limit(1);
    if (!user) {
      [user] = await tx.insert(usersTable).values({
        email: invite.email,
        name,
        passwordHash: hashPassword(password),
        status: "active",
      }).returning();
    } else if (!user.passwordHash) {
      [user] = await tx.update(usersTable).set({ name, passwordHash: hashPassword(password), status: "active" })
        .where(eq(usersTable.id, user.id)).returning();
    }

    const [existing] = await tx.select().from(companyMembersTable).where(and(
      eq(companyMembersTable.companyId, invite.companyId),
      eq(companyMembersTable.userId, user.id),
    )).limit(1);
    if (!existing) {
      await tx.insert(companyMembersTable).values({
        companyId: invite.companyId,
        userId: user.id,
        role: invite.role,
        permissions: invite.permissions ?? {},
      });
    }
    await tx.update(teamInvitationsTable).set({ status: "accepted", acceptedAt: new Date() }).where(eq(teamInvitationsTable.id, invite.id));
    return user;
  });

  issueUserSession(result.id, invite.companyId, res);
  res.json({ ok: true, companyId: invite.companyId, role: invite.role });
});

export default router;
