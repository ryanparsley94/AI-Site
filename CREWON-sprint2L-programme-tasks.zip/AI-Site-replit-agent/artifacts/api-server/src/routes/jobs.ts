import { Router } from "express";
import { eq, gte, and, lte } from "drizzle-orm";
import { db, jobsTable, quotesTable, marketingDraftsTable } from "@workspace/db";
import {
  ListJobsResponse,
  CreateJobBody,
  CreateJobResponse,
  GetUpcomingJobsResponse,
  GetJobParams,
  GetJobResponse,
  UpdateJobParams,
  UpdateJobBody,
  UpdateJobResponse,
  DeleteJobParams,
} from "@workspace/api-zod";
import {
  createCalendarEvent,
  updateCalendarEvent,
  deleteCalendarEvent,
} from "../lib/google-calendar";
import { draftMessage, getCompanyName } from "./marketing";
import { hasValidSession } from "../lib/adminAuth";

const router = Router();

function mapJob(j: typeof jobsTable.$inferSelect) {
  return {
    ...j,
    estimatedValue: j.estimatedValue !== null ? Number(j.estimatedValue) : null,
    scheduledAt: j.scheduledAt.toISOString(),
    createdAt: j.createdAt.toISOString(),
  };
}

router.get("/jobs/upcoming", async (req, res): Promise<void> => {
  const now = new Date();
  const inSevenDays = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  const rows = await db
    .select()
    .from(jobsTable)
    .where(and(eq(jobsTable.companyId, req.companyId!), gte(jobsTable.scheduledAt, now), lte(jobsTable.scheduledAt, inSevenDays)))
    .orderBy(jobsTable.scheduledAt);
  res.json(GetUpcomingJobsResponse.parse(rows.map(mapJob)));
});

router.get("/jobs", async (req, res): Promise<void> => {
  let query = db.select().from(jobsTable).where(eq(jobsTable.companyId, req.companyId!)).orderBy(jobsTable.scheduledAt).$dynamic();
  if (req.query.status && req.query.status !== "all") {
    query = query.where(and(eq(jobsTable.companyId, req.companyId!), eq(jobsTable.status, req.query.status as string)));
  }
  const rows = await query;
  res.json(ListJobsResponse.parse(rows.map(mapJob)));
});

router.post("/jobs", async (req, res): Promise<void> => {
  const parsed = CreateJobBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { scheduledAt, estimatedValue, ...rest } = parsed.data;
  const [row] = await db
    .insert(jobsTable)
    .values({
      ...rest,
      companyId: req.companyId!,
      scheduledAt: scheduledAt ? new Date(scheduledAt) : new Date(),
      estimatedValue: estimatedValue !== undefined ? String(estimatedValue) : null,
    })
    .returning();

  // Sync to Google Calendar (fire-and-forget — don't fail the request if it fails)
  createCalendarEvent({
    title: row.title,
    contactName: row.contactName,
    address: row.address,
    serviceType: row.serviceType,
    scheduledAt: row.scheduledAt,
    estimatedDuration: row.estimatedDuration,
  }, req.companyId!).then(async (eventId) => {
    if (eventId) {
      await db.update(jobsTable).set({ googleEventId: eventId }).where(and(eq(jobsTable.id, row.id), eq(jobsTable.companyId, req.companyId!)));
    }
  }).catch(() => { /* non-fatal */ });

  res.status(201).json(CreateJobResponse.parse(mapJob(row)));
});

router.get("/jobs/:id", async (req, res): Promise<void> => {
  const params = GetJobParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [row] = await db.select().from(jobsTable).where(and(eq(jobsTable.id, params.data.id), eq(jobsTable.companyId, req.companyId!)));
  if (!row) { res.status(404).json({ error: "Not found" }); return; }
  res.json(GetJobResponse.parse(mapJob(row)));
});

router.patch("/jobs/:id", async (req, res): Promise<void> => {
  const params = UpdateJobParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateJobBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { scheduledAt, estimatedValue, quoteId, ...rest } = parsed.data;
  const updateData: Record<string, unknown> = { ...rest };
  if (scheduledAt !== undefined) updateData.scheduledAt = new Date(scheduledAt);
  if (estimatedValue !== undefined) updateData.estimatedValue = String(estimatedValue);

  // If linking a quote, auto-populate estimatedValue from quote.totalIncVat
  if (quoteId !== undefined && quoteId !== null) {
    const [quote] = await db.select().from(quotesTable).where(and(eq(quotesTable.id, quoteId), eq(quotesTable.companyId, req.companyId!)));
    if (quote?.totalIncVat !== null && quote?.totalIncVat !== undefined) {
      updateData.estimatedValue = quote.totalIncVat;
    }
  }

  const [row] = await db
    .update(jobsTable)
    .set(updateData)
    .where(and(eq(jobsTable.id, params.data.id), eq(jobsTable.companyId, req.companyId!)))
    .returning();
  if (!row) { res.status(404).json({ error: "Not found" }); return; }

  // Sync to Google Calendar if schedule changed
  if (row.googleEventId) {
    updateCalendarEvent(row.googleEventId, {
      title: row.title,
      contactName: row.contactName,
      address: row.address,
      serviceType: row.serviceType,
      scheduledAt: row.scheduledAt,
      estimatedDuration: row.estimatedDuration,
    }, req.companyId!).catch(() => { /* non-fatal */ });
  }

  // When a job is marked completed by an authenticated session, auto-generate
  // marketing drafts (review request + follow-up). The hasValidSession guard
  // prevents unauthenticated callers from triggering paid AI generation by
  // PATCHing job status — they can still update job status but won't burn credits.
  if (rest.status === "completed" && hasValidSession(req)) {
    (async () => {
      try {
        const companyName = await getCompanyName(req.companyId!);

        const types = ["review_request", "followup"] as const;
        for (const type of types) {
          let insertedId: number;
          try {
            const [inserted] = await db
              .insert(marketingDraftsTable)
              .values({
                companyId: req.companyId!,
                jobId: row.id,
                jobTitle: row.title,
                clientName: row.contactName,
                clientPhone: row.contactPhone || null,
                companyName,
                type,
                status: "pending",
                draftMessage: null,
                editedMessage: null,
              })
              .returning();
            insertedId = inserted.id;
          } catch (insertErr: unknown) {
            // Unique constraint — drafts already exist for this job, skip silently
            const code = (insertErr as { code?: string })?.code;
            if (code === "23505") continue;
            throw insertErr;
          }

          // Draft AI message asynchronously; write failure sentinel on error so
          // the UI exits the loading/polling state instead of spinning forever.
          draftMessage(type, row.title, row.contactName, companyName)
            .then((msg) =>
              db
                .update(marketingDraftsTable)
                .set({ draftMessage: msg })
                .where(and(eq(marketingDraftsTable.id, insertedId), eq(marketingDraftsTable.companyId, req.companyId!)))
            )
            .catch(async (err) => {
              console.error(`Failed to draft marketing message for job ${row.id} (${type}):`, err);
              await db
                .update(marketingDraftsTable)
                .set({ draftMessage: "__FAILED__" })
                .where(and(eq(marketingDraftsTable.id, insertedId), eq(marketingDraftsTable.companyId, req.companyId!)))
                .catch(() => { /* best-effort */ });
            });
        }
      } catch (err) {
        console.error("Failed to generate marketing drafts for completed job:", err);
      }
    })();
  }

  res.json(UpdateJobResponse.parse(mapJob(row)));
});

router.delete("/jobs/:id", async (req, res): Promise<void> => {
  const params = DeleteJobParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }

  // Fetch the job first so we can remove its calendar event
  const [job] = await db.select().from(jobsTable).where(and(eq(jobsTable.id, params.data.id), eq(jobsTable.companyId, req.companyId!)));
  await db.delete(jobsTable).where(and(eq(jobsTable.id, params.data.id), eq(jobsTable.companyId, req.companyId!)));

  if (job?.googleEventId) {
    deleteCalendarEvent(job.googleEventId, req.companyId!).catch(() => { /* non-fatal */ });
  }

  res.status(204).end();
});

export default router;
