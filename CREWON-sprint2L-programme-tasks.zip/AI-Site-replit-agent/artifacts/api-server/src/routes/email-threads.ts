/**
 * Protected email-thread CRUD routes (require admin session).
 * The public inbound webhook lives in email-threads-inbound.ts.
 */
import { Router } from "express";
import { and, eq, ne, notInArray, desc } from "drizzle-orm";
import { db, emailThreadsTable, companiesTable } from "@workspace/db";
import {
  ListEmailThreadsResponse,
  ListEmailThreadsQueryParams,
  GetEmailThreadResponse,
  UpdateEmailThreadBody,
  UpdateEmailThreadResponse,
  ApproveEmailThreadResponse,
  DismissEmailThreadResponse,
  DeleteEmailThreadParams,
  GetEmailThreadParams,
  UpdateEmailThreadParams,
  ApproveEmailThreadParams,
  DismissEmailThreadParams,
  GetEmailSettingsResponse,
  UpdateEmailSettingsBody,
  UpdateEmailSettingsResponse,
  CreateEmailThreadBody,
  CreateEmailThreadResponse,
} from "@workspace/api-zod";
import { sendEmailReply, draftAiReply } from "./email-threads-inbound";
import { getCompanyById } from "../lib/company-context";

const router = Router();

function mapThread(t: typeof emailThreadsTable.$inferSelect) {
  return {
    ...t,
    createdAt: t.createdAt.toISOString(),
  };
}


// ─── Settings ─────────────────────────────────────────────────────────────────

router.get("/email-threads/settings", async (req, res): Promise<void> => {
  const company = await getCompanyById(req.companyId!);
  if (!company) { res.status(404).json({ error: "Company not found" }); return; }
  const inboundUrl = process.env.REPLIT_DEV_DOMAIN
    ? `https://${process.env.REPLIT_DEV_DOMAIN}/api/email-threads/inbound`
    : `/api/email-threads/inbound`;

  res.json(
    GetEmailSettingsResponse.parse({
      autoSend: company.emailAutoSend,
      forwardingAddress: inboundUrl,
      resendConfigured: Boolean(process.env.RESEND_API_KEY),
    })
  );
});

router.patch("/email-threads/settings", async (req, res): Promise<void> => {
  const parsed = UpdateEmailSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const company = await getCompanyById(req.companyId!);
  if (!company) { res.status(404).json({ error: "Company not found" }); return; }
  if (parsed.data.autoSend !== undefined) {
    await db
      .update(companiesTable)
      .set({ emailAutoSend: parsed.data.autoSend })
      .where(eq(companiesTable.id, company.id));
  }
  const updated = await getCompanyById(req.companyId!);
  if (!updated) { res.status(404).json({ error: "Company not found" }); return; }
  const inboundUrl = process.env.REPLIT_DEV_DOMAIN
    ? `https://${process.env.REPLIT_DEV_DOMAIN}/api/email-threads/inbound`
    : `/api/email-threads/inbound`;

  res.json(
    UpdateEmailSettingsResponse.parse({
      autoSend: updated.emailAutoSend,
      forwardingAddress: inboundUrl,
      resendConfigured: Boolean(process.env.RESEND_API_KEY),
    })
  );
});

// ─── Create (manual log) ───────────────────────────────────────────────────────

router.post("/email-threads", async (req, res): Promise<void> => {
  const parsed = CreateEmailThreadBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { fromEmail, fromName = "", subject, bodyText } = parsed.data;

  // Insert the thread immediately as "pending" so it shows in the list
  // while the AI drafts the reply.
  const [row] = await db
    .insert(emailThreadsTable)
    .values({
      companyId: req.companyId!,
      fromEmail,
      fromName,
      subject,
      bodyText,
      status: "pending",
    })
    .returning();

  // Draft the AI reply asynchronously — fire-and-forget so the response is fast.
  // The UI will pick up the draft on next poll/refresh.
  (async () => {
    try {
      const aiReply = await draftAiReply(subject, bodyText, fromName, fromEmail, req.companyId!);
      await db
        .update(emailThreadsTable)
        .set({ aiReply })
        .where(and(eq(emailThreadsTable.id, row.id), eq(emailThreadsTable.companyId, req.companyId!)));
    } catch (err) {
      // Non-fatal: the thread exists without a draft; the contractor can still
      // write their own reply manually.
      console.error("Failed to draft AI reply for manual thread:", err);
    }
  })();

  res.status(201).json(CreateEmailThreadResponse.parse(mapThread(row)));
});

// ─── List ─────────────────────────────────────────────────────────────────────

router.get("/email-threads", async (req, res): Promise<void> => {
  const params = ListEmailThreadsQueryParams.safeParse({ status: req.query.status });
  let query = db
    .select()
    .from(emailThreadsTable)
    .where(eq(emailThreadsTable.companyId, req.companyId!))
    .orderBy(desc(emailThreadsTable.createdAt))
    .$dynamic();

  const status = (params.success ? params.data.status : undefined) ?? "all";
  if (status && status !== "all") {
    query = query.where(and(eq(emailThreadsTable.companyId, req.companyId!), eq(emailThreadsTable.status, status)));
  } else {
    // Never expose transient placeholder rows to the UI
    query = query.where(
      and(eq(emailThreadsTable.companyId, req.companyId!), notInArray(emailThreadsTable.status, ["processing", "sending"]))
    );
  }

  const rows = await query;
  res.json(ListEmailThreadsResponse.parse(rows.map(mapThread)));
});

// ─── Single thread ────────────────────────────────────────────────────────────

router.get("/email-threads/:id", async (req, res): Promise<void> => {
  const params = GetEmailThreadParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const [row] = await db
    .select()
    .from(emailThreadsTable)
    .where(and(eq(emailThreadsTable.id, params.data.id), eq(emailThreadsTable.companyId, req.companyId!)));
  if (!row) {
    res.status(404).json({ error: "Not found" });
    return;
  }
  res.json(GetEmailThreadResponse.parse(mapThread(row)));
});

router.patch("/email-threads/:id", async (req, res): Promise<void> => {
  const params = UpdateEmailThreadParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const parsed = UpdateEmailThreadBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [row] = await db
    .update(emailThreadsTable)
    .set(parsed.data)
    .where(and(eq(emailThreadsTable.id, params.data.id), eq(emailThreadsTable.companyId, req.companyId!)))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Not found" });
    return;
  }
  res.json(UpdateEmailThreadResponse.parse(mapThread(row)));
});

router.delete("/email-threads/:id", async (req, res): Promise<void> => {
  const params = DeleteEmailThreadParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  await db
    .delete(emailThreadsTable)
    .where(and(eq(emailThreadsTable.id, params.data.id), eq(emailThreadsTable.companyId, req.companyId!)));
  res.status(204).end();
});

// ─── Actions ──────────────────────────────────────────────────────────────────

router.post("/email-threads/:id/approve", async (req, res): Promise<void> => {
  const params = ApproveEmailThreadParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  // Atomically claim the thread by transitioning pending → sending.
  // Using an intermediate "sending" state prevents dismiss from racing the
  // in-flight provider call: dismiss only accepts "pending" rows, so it will
  // return 409 while the send is in flight.
  const [claimed] = await db
    .update(emailThreadsTable)
    .set({ status: "sending" })
    .where(
      and(
        eq(emailThreadsTable.id, params.data.id),
        eq(emailThreadsTable.companyId, req.companyId!),
        eq(emailThreadsTable.status, "pending")
      )
    )
    .returning();

  if (!claimed) {
    const [row] = await db
      .select()
      .from(emailThreadsTable)
      .where(and(eq(emailThreadsTable.id, params.data.id), eq(emailThreadsTable.companyId, req.companyId!)));
    if (!row) {
      res.status(404).json({ error: "Not found" });
    } else {
      res.status(409).json({ error: `Thread is already ${row.status}` });
    }
    return;
  }

  const replyBody = claimed.editedReply ?? claimed.aiReply ?? "";

  // Attempt provider delivery. On failure, roll back sending → pending so the
  // user can retry. On success, finalize sending → sent.
  const sent = await sendEmailReply(claimed.fromEmail, claimed.fromName, claimed.subject, replyBody, req.companyId!);
  if (!sent) {
    await db
      .update(emailThreadsTable)
      .set({ status: "pending" })
      .where(
        and(
          eq(emailThreadsTable.id, params.data.id),
          eq(emailThreadsTable.companyId, req.companyId!),
          eq(emailThreadsTable.status, "sending")
        )
      );
    res.status(503).json({
      error:
        "Email delivery unavailable. Configure RESEND_API_KEY and RESEND_FROM_EMAIL " +
        "to enable outbound sending. The reply draft has been preserved.",
    });
    return;
  }

  const [updated] = await db
    .update(emailThreadsTable)
    .set({ status: "sent" })
    .where(and(eq(emailThreadsTable.id, params.data.id), eq(emailThreadsTable.companyId, req.companyId!)))
    .returning();

  res.json(ApproveEmailThreadResponse.parse(mapThread(updated ?? claimed)));
});

router.post("/email-threads/:id/dismiss", async (req, res): Promise<void> => {
  const params = DismissEmailThreadParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  // Only allow dismissing a pending thread. "sending" is in-flight (race guard),
  // "sent" and "dismissed" are terminal states.
  const [updated] = await db
    .update(emailThreadsTable)
    .set({ status: "dismissed" })
    .where(
      and(
        eq(emailThreadsTable.id, params.data.id),
        eq(emailThreadsTable.companyId, req.companyId!),
        eq(emailThreadsTable.status, "pending")
      )
    )
    .returning();
  if (!updated) {
    const [row] = await db
      .select()
      .from(emailThreadsTable)
      .where(and(eq(emailThreadsTable.id, params.data.id), eq(emailThreadsTable.companyId, req.companyId!)));
    if (!row) {
      res.status(404).json({ error: "Not found" });
    } else {
      res.status(409).json({ error: `Thread is already ${row.status}` });
    }
    return;
  }
  res.json(DismissEmailThreadResponse.parse(mapThread(updated)));
});

export default router;
