import { Router } from "express";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import {
  db, jobsTable, workforceProfilesTable, workforceAllocationsTable, workforceTimeEntriesTable,
  deliveriesTable, purchaseOrdersTable, suppliersTable, siteProgressUpdatesTable,
  siteMaterialRequestsTable, siteIssuesTable, projectVariationsTable, auditEventsTable
} from "@workspace/db";
import { hasPermission, requirePermission } from "../lib/permissions";

const router = Router();
const money=(v:unknown)=>Number(v??0);
const positiveId=(v:unknown)=>{const n=Number(v);return Number.isInteger(n)&&n>0?n:null};
const text=(v:unknown)=>typeof v==="string"?v.trim():"";
const date=(v:unknown)=>{if(!v)return null;const d=new Date(String(v));return Number.isNaN(d.getTime())?null:d};

async function profile(companyId:number,userId?:number|null){
  if(!userId)return null;
  const [row]=await db.select().from(workforceProfilesTable)
    .where(and(eq(workforceProfilesTable.companyId,companyId),eq(workforceProfilesTable.userId,userId))).limit(1);
  return row??null;
}
async function job(companyId:number,id:number){
  const [row]=await db.select().from(jobsTable).where(and(eq(jobsTable.companyId,companyId),eq(jobsTable.id,id))).limit(1);
  return row??null;
}

router.get("/supervisor/today",requirePermission("workforce.read"),async(req,res)=>{
  const companyId=req.companyId!;
  const me=await profile(companyId,req.userId);
  const now=new Date(), start=new Date(now); start.setHours(0,0,0,0); const end=new Date(start); end.setDate(end.getDate()+1);
  const allocations=me?await db.select().from(workforceAllocationsTable)
    .where(and(eq(workforceAllocationsTable.companyId,companyId),eq(workforceAllocationsTable.workerId,me.id),inArray(workforceAllocationsTable.status,["allocated","active"]))):[];
  const allocatedJobIds=[...new Set(allocations.map(a=>a.jobId))];
  const todaysJobs=await db.select().from(jobsTable).where(
    allocatedJobIds.length
      ? and(eq(jobsTable.companyId,companyId),inArray(jobsTable.id,allocatedJobIds))
      : and(eq(jobsTable.companyId,companyId),sql`${jobsTable.scheduledAt} >= ${start}`,sql`${jobsTable.scheduledAt} < ${end}`)
  ).orderBy(jobsTable.scheduledAt);

  const jobIds=todaysJobs.map(j=>j.id);
  const crew=jobIds.length?await db.select({
    jobId:workforceAllocationsTable.jobId,workerId:workforceProfilesTable.id,workerName:workforceProfilesTable.name,
    role:workforceAllocationsTable.role,status:workforceAllocationsTable.status
  }).from(workforceAllocationsTable).innerJoin(workforceProfilesTable,eq(workforceProfilesTable.id,workforceAllocationsTable.workerId))
    .where(and(eq(workforceAllocationsTable.companyId,companyId),inArray(workforceAllocationsTable.jobId,jobIds),inArray(workforceAllocationsTable.status,["allocated","active"]))):[];

  const pendingTimesheets=jobIds.length?await db.select({
    id:workforceTimeEntriesTable.id,jobId:workforceTimeEntriesTable.jobId,workerName:workforceProfilesTable.name,
    regularHours:workforceTimeEntriesTable.regularHours,overtimeHours:workforceTimeEntriesTable.overtimeHours,totalCost:workforceTimeEntriesTable.totalCost,
    workDate:workforceTimeEntriesTable.workDate,notes:workforceTimeEntriesTable.notes
  }).from(workforceTimeEntriesTable).innerJoin(workforceProfilesTable,eq(workforceProfilesTable.id,workforceTimeEntriesTable.workerId))
    .where(and(eq(workforceTimeEntriesTable.companyId,companyId),inArray(workforceTimeEntriesTable.jobId,jobIds),eq(workforceTimeEntriesTable.status,"submitted")))
    .orderBy(desc(workforceTimeEntriesTable.workDate)):[];

  const deliveries=jobIds.length?await db.select({
    id:deliveriesTable.id,jobId:deliveriesTable.jobId,status:deliveriesTable.status,reference:deliveriesTable.reference,
    scheduledAt:deliveriesTable.scheduledAt,supplierName:suppliersTable.name,poNumber:purchaseOrdersTable.poNumber
  }).from(deliveriesTable).leftJoin(suppliersTable,eq(suppliersTable.id,deliveriesTable.supplierId))
    .leftJoin(purchaseOrdersTable,eq(purchaseOrdersTable.id,deliveriesTable.purchaseOrderId))
    .where(and(eq(deliveriesTable.companyId,companyId),inArray(deliveriesTable.jobId,jobIds),inArray(deliveriesTable.status,["scheduled","in_transit","part_received"]))):[];

  const materials=jobIds.length?await db.select().from(siteMaterialRequestsTable)
    .where(and(eq(siteMaterialRequestsTable.companyId,companyId),inArray(siteMaterialRequestsTable.jobId,jobIds),inArray(siteMaterialRequestsTable.status,["requested","approved","ordered"]))):[];
  const issues=jobIds.length?await db.select().from(siteIssuesTable)
    .where(and(eq(siteIssuesTable.companyId,companyId),inArray(siteIssuesTable.jobId,jobIds),inArray(siteIssuesTable.status,["open","reviewing","escalated"]))):[];

  const progress=jobIds.length?await db.select().from(siteProgressUpdatesTable)
    .where(and(eq(siteProgressUpdatesTable.companyId,companyId),inArray(siteProgressUpdatesTable.jobId,jobIds)))
    .orderBy(desc(siteProgressUpdatesTable.createdAt)):[];

  res.json({
    supervisor:me?{id:me.id,name:me.name}:null,
    jobs:todaysJobs.map(j=>({
      ...j,
      crew:crew.filter(c=>c.jobId===j.id),
      progress:progress.find(p=>p.jobId===j.id)??null,
      materialRequests:materials.filter(m=>m.jobId===j.id),
      issues:issues.filter(i=>i.jobId===j.id),
      deliveries:deliveries.filter(d=>d.jobId===j.id),
    })),
    pendingTimesheets:pendingTimesheets.map(x=>({...x,regularHours:money(x.regularHours),overtimeHours:money(x.overtimeHours),totalCost:money(x.totalCost)})),
    counts:{jobs:todaysJobs.length,pendingTimesheets:pendingTimesheets.length,materialRequests:materials.length,issues:issues.length,deliveries:deliveries.length}
  });
});

router.post("/supervisor/material-requests",async(req,res)=>{
  const allowed=hasPermission(req,"purchasing.request")||hasPermission(req,"purchasing.manage");
  if(!allowed)return res.status(403).json({error:"You do not have permission to request materials"});
  const jobId=positiveId(req.body?.jobId),description=text(req.body?.description),quantity=Number(req.body?.quantity),unit=text(req.body?.unit)||"each";
  if(!jobId||!description||!Number.isFinite(quantity)||quantity<=0||!(await job(req.companyId!,jobId)))return res.status(400).json({error:"Project, material and quantity are required"});
  const me=await profile(req.companyId!,req.userId);
  const urgency=text(req.body?.urgency)||"normal";
  if(!["low","normal","urgent","critical"].includes(urgency))return res.status(400).json({error:"Invalid urgency"});
  const [row]=await db.insert(siteMaterialRequestsTable).values({
    companyId:req.companyId!,jobId,requestedByWorkerId:me?.id??null,requestedByUserId:req.userId??null,
    productId:positiveId(req.body?.productId),description,quantity:String(quantity),unit,neededBy:date(req.body?.neededBy),
    urgency,reason:text(req.body?.reason)||null,notes:text(req.body?.notes)||null
  }).returning();
  await db.insert(auditEventsTable).values({companyId:req.companyId!,userId:req.userId??null,actorType:"user",
    action:"site.material.requested",entityType:"site_material_request",entityId:String(row.id),metadata:{jobId,description,quantity,urgency}});
  res.status(201).json({...row,quantity});
});

router.get("/supervisor/material-requests",requirePermission("purchasing.read"),async(req,res)=>{
  const rows=await db.select().from(siteMaterialRequestsTable).where(eq(siteMaterialRequestsTable.companyId,req.companyId!)).orderBy(desc(siteMaterialRequestsTable.createdAt));
  res.json(rows.map(x=>({...x,quantity:money(x.quantity)})));
});

router.patch("/supervisor/material-requests/:id",requirePermission("purchasing.manage"),async(req,res)=>{
  const id=positiveId(req.params.id),status=text(req.body?.status);
  if(!id||!["approved","ordered","delivered","declined","requested"].includes(status))return res.status(400).json({error:"Invalid material request status"});
  const [row]=await db.update(siteMaterialRequestsTable).set({status,procurementReference:text(req.body?.procurementReference)||null,notes:text(req.body?.notes)||null})
    .where(and(eq(siteMaterialRequestsTable.companyId,req.companyId!),eq(siteMaterialRequestsTable.id,id))).returning();
  if(!row)return res.status(404).json({error:"Material request not found"});res.json(row);
});

router.post("/supervisor/issues",async(req,res)=>{
  const allowed=hasPermission(req,"jobs.update")||hasPermission(req,"workforce.approve")||hasPermission(req,"workforce.manage");
  if(!allowed)return res.status(403).json({error:"You do not have permission to report site issues"});
  const jobId=positiveId(req.body?.jobId),title=text(req.body?.title),description=text(req.body?.description);
  if(!jobId||!title||!description||!(await job(req.companyId!,jobId)))return res.status(400).json({error:"Project, title and description are required"});
  const me=await profile(req.companyId!,req.userId);const severity=text(req.body?.severity)||"medium",issueType=text(req.body?.issueType)||"site";
  if(!["low","medium","high","critical"].includes(severity))return res.status(400).json({error:"Invalid severity"});
  const [row]=await db.insert(siteIssuesTable).values({
    companyId:req.companyId!,jobId,reportedByWorkerId:me?.id??null,reportedByUserId:req.userId??null,
    issueType,title,description,severity,potentialVariation:text(req.body?.potentialVariation)||"no",
    estimatedImpact:String(Math.max(0,Number(req.body?.estimatedImpact)||0))
  }).returning();
  res.status(201).json({...row,estimatedImpact:money(row.estimatedImpact)});
});

router.get("/supervisor/issues",requirePermission("workforce.read"),async(req,res)=>{
  const rows=await db.select().from(siteIssuesTable).where(eq(siteIssuesTable.companyId,req.companyId!)).orderBy(desc(siteIssuesTable.createdAt));
  res.json(rows.map(x=>({...x,estimatedImpact:money(x.estimatedImpact)})));
});

router.patch("/supervisor/issues/:id",async(req,res)=>{
  const allowed=hasPermission(req,"workforce.approve")||hasPermission(req,"workforce.manage");
  if(!allowed)return res.status(403).json({error:"You do not have permission to manage site issues"});
  const id=positiveId(req.params.id),status=text(req.body?.status);
  if(!id||!["open","reviewing","resolved","escalated"].includes(status))return res.status(400).json({error:"Invalid issue status"});
  const [row]=await db.update(siteIssuesTable).set({status,resolvedAt:status==="resolved"?new Date():null})
    .where(and(eq(siteIssuesTable.companyId,req.companyId!),eq(siteIssuesTable.id,id))).returning();
  if(!row)return res.status(404).json({error:"Site issue not found"});res.json(row);
});

router.post("/supervisor/issues/:id/create-variation",requirePermission("workforce.approve"),async(req,res)=>{
  const id=positiveId(req.params.id);if(!id)return res.status(400).json({error:"Invalid site issue"});
  const [issue]=await db.select().from(siteIssuesTable).where(and(eq(siteIssuesTable.companyId,req.companyId!),eq(siteIssuesTable.id,id))).limit(1);
  if(!issue)return res.status(404).json({error:"Site issue not found"});
  const value=Number(req.body?.value),estimatedCost=Number(req.body?.estimatedCost??issue.estimatedImpact??0);
  if(!Number.isFinite(value)||value<=0)return res.status(400).json({error:"Enter a client variation value"});
  const [variation]=await db.insert(projectVariationsTable).values({
    companyId:req.companyId!,jobId:issue.jobId,reference:text(req.body?.reference)||`SITE-${issue.id}`,
    description:text(req.body?.description)||`${issue.title}: ${issue.description}`,value:String(value),
    estimatedCost:String(Math.max(0,Number.isFinite(estimatedCost)?estimatedCost:0)),status:"pending",createdByUserId:req.userId??null
  }).returning();
  await db.update(siteIssuesTable).set({potentialVariation:"yes",status:"reviewing",metadata:{variationId:variation.id}})
    .where(and(eq(siteIssuesTable.companyId,req.companyId!),eq(siteIssuesTable.id,id)));
  res.status(201).json(variation);
});

export default router;
