import { Router } from "express";
import { eq, desc, and } from "drizzle-orm";
import { db, invoicesTable } from "@workspace/db";
import {
  ListInvoicesResponse,
  CreateInvoiceBody,
  CreateInvoiceResponse,
  GetInvoiceParams,
  GetInvoiceResponse,
  UpdateInvoiceParams,
  UpdateInvoiceBody,
  UpdateInvoiceResponse,
  DeleteInvoiceParams,
} from "@workspace/api-zod";

const router = Router();

function mapInvoice(inv: typeof invoicesTable.$inferSelect) {
  return {
    ...inv,
    subtotal: Number(inv.subtotal),
    vatPercent: Number(inv.vatPercent),
    vatAmount: Number(inv.vatAmount),
    total: Number(inv.total),
    lineItems: Array.isArray(inv.lineItems) ? inv.lineItems : [],
    createdAt: inv.createdAt.toISOString(),
  };
}

router.get("/invoices", async (req, res): Promise<void> => {
  let query = db.select().from(invoicesTable).where(eq(invoicesTable.companyId, req.companyId!)).orderBy(desc(invoicesTable.createdAt)).$dynamic();
  if (req.query.jobId) {
    query = query.where(and(eq(invoicesTable.companyId, req.companyId!), eq(invoicesTable.jobId, Number(req.query.jobId))));
  }
  const rows = await query;
  res.json(ListInvoicesResponse.parse(rows.map(mapInvoice)));
});

router.post("/invoices", async (req, res): Promise<void> => {
  const parsed = CreateInvoiceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { subtotal, vatPercent, vatAmount, total, lineItems, ...rest } = parsed.data;

  // Step 1: insert with a temporary placeholder invoice number
  const [draft] = await db
    .insert(invoicesTable)
    .values({
      ...rest,
      companyId: req.companyId!,
      invoiceNumber: "PENDING",
      lineItems: lineItems ?? [],
      subtotal: String(subtotal ?? 0),
      vatPercent: String(vatPercent ?? 20),
      vatAmount: String(vatAmount ?? 0),
      total: String(total ?? 0),
    })
    .returning();

  // Step 2: update with the final invoice number derived from the PK (race-free)
  const invoiceNumber = `INV-${String(draft.id).padStart(4, "0")}`;
  const [row] = await db
    .update(invoicesTable)
    .set({ invoiceNumber })
    .where(and(eq(invoicesTable.id, draft.id), eq(invoicesTable.companyId, req.companyId!)))
    .returning();

  res.status(201).json(CreateInvoiceResponse.parse(mapInvoice(row)));
});

router.get("/invoices/:id", async (req, res): Promise<void> => {
  const params = GetInvoiceParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [row] = await db.select().from(invoicesTable).where(and(eq(invoicesTable.id, params.data.id), eq(invoicesTable.companyId, req.companyId!)));
  if (!row) { res.status(404).json({ error: "Not found" }); return; }
  res.json(GetInvoiceResponse.parse(mapInvoice(row)));
});

router.patch("/invoices/:id", async (req, res): Promise<void> => {
  const params = UpdateInvoiceParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateInvoiceBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { subtotal, vatPercent, vatAmount, total, lineItems, ...rest } = parsed.data;
  const updateData: Record<string, unknown> = { ...rest };
  if (lineItems !== undefined) updateData.lineItems = lineItems;
  if (subtotal !== undefined) updateData.subtotal = String(subtotal);
  if (vatPercent !== undefined) updateData.vatPercent = String(vatPercent);
  if (vatAmount !== undefined) updateData.vatAmount = String(vatAmount);
  if (total !== undefined) updateData.total = String(total);
  const [row] = await db
    .update(invoicesTable)
    .set(updateData)
    .where(and(eq(invoicesTable.id, params.data.id), eq(invoicesTable.companyId, req.companyId!)))
    .returning();
  if (!row) { res.status(404).json({ error: "Not found" }); return; }
  res.json(UpdateInvoiceResponse.parse(mapInvoice(row)));
});

router.delete("/invoices/:id", async (req, res): Promise<void> => {
  const params = DeleteInvoiceParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(invoicesTable).where(and(eq(invoicesTable.id, params.data.id), eq(invoicesTable.companyId, req.companyId!)));
  res.status(204).end();
});

export default router;
