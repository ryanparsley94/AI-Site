import { Router } from "express";
import { and, desc, eq, inArray } from "drizzle-orm";
import {
  db, jobsTable, projectMilestonesTable, projectTasksTable, projectTaskDependenciesTable,
  projectTaskAssignmentsTable, workforceProfilesTable, workforceTimeEntriesTable,
  marginProtectionAlertsTable, auditEventsTable
} from "@workspace/db";
import { hasPermission, requirePermission } from "../lib/permissions";

const router=Router();
const id=(v:unknown)=>{const n=Number(v);return Number.isInteger(n)&&n>0?n:null};
const text=(v:unknown)=>typeof v==="string"?v.trim():"";
const num=(v:unknown)=>Number(v??0);
const date=(v:unknown)=>{if(!v)return null;const d=new Date(String(v));return Number.isNaN(d.getTime())?null:d};
const canRead=(req:any)=>hasPermission(req,"jobs.read")||hasPermission(req,"jobs.update")||hasPermission(req,"jobs.manage")||hasPermission(req,"workforce.read");
const canManage=(req:any)=>hasPermission(req,"jobs.manage")||hasPermission(req,"workforce.manage");

async function companyJob(companyId:number,jobId:number){
  const [j]=await db.select().from(jobsTable).where(and(eq(jobsTable.companyId,companyId),eq(jobsTable.id,jobId))).limit(1);
  return j??null;
}
async function riskSummary(companyId:number,jobId:number){
  const [tasks,deps,assignments,times]=await Promise.all([
    db.select().from(projectTasksTable).where(and(eq(projectTasksTable.companyId,companyId),eq(projectTasksTable.jobId,jobId))),
    db.select().from(projectTaskDependenciesTable).where(and(eq(projectTaskDependenciesTable.companyId,companyId),eq(projectTaskDependenciesTable.jobId,jobId))),
    db.select().from(projectTaskAssignmentsTable).where(and(eq(projectTaskAssignmentsTable.companyId,companyId),eq(projectTaskAssignmentsTable.jobId,jobId))),
    db.select().from(workforceTimeEntriesTable).where(and(eq(workforceTimeEntriesTable.companyId,companyId),eq(workforceTimeEntriesTable.jobId,jobId),eq(workforceTimeEntriesTable.status,"approved")))
  ]);
  const now=Date.now();
  const completed=new Set(tasks.filter(t=>t.status==="complete").map(t=>t.id));
  const byTask=new Map<number,any>(tasks.map(t=>[t.id,t]));
  const blockedByDependency=new Set<number>();
  for(const d of deps) if(!completed.has(d.dependsOnTaskId)) blockedByDependency.add(d.taskId);
  const late=tasks.filter(t=>t.status!=="complete"&&t.plannedFinish&&new Date(t.plannedFinish).getTime()<now);
  const criticalLate=late.filter(t=>t.criticalPath);
  const blocked=tasks.filter(t=>t.status==="blocked"||blockedByDependency.has(t.id));
  const plannedHours=tasks.reduce((s,t)=>s+num(t.plannedHours),0);
  const actualHours=times.reduce((s,t)=>s+num(t.regularHours)+num(t.overtimeHours),0);
  const weightedPlan=tasks.reduce((s,t)=>s+num(t.plannedHours)*num(t.progressPercent)/100,0);
  const programmeProgress=plannedHours>0?weightedPlan/plannedHours*100:(tasks.length?tasks.reduce((s,t)=>s+num(t.progressPercent),0)/tasks.length:0);
  const risk=criticalLate.length?"critical":late.length||blocked.filter(t=>t.criticalPath).length?"high":blocked.length?"medium":"low";
  return {tasks,dependencies:deps,assignments,plannedHours,actualHours,programmeProgress,lateCount:late.length,criticalLateCount:criticalLate.length,blockedCount:blocked.length,risk};
}

router.get("/programme/jobs/:jobId",async(req,res)=>{
  if(!canRead(req))return res.status(403).json({error:"You do not have permission to view the programme"});
  const jobId=id(req.params.jobId);if(!jobId||!(await companyJob(req.companyId!,jobId)))return res.status(404).json({error:"Project not found"});
  const [milestones,taskRows,deps,assignments]=await Promise.all([
    db.select().from(projectMilestonesTable).where(and(eq(projectMilestonesTable.companyId,req.companyId!),eq(projectMilestonesTable.jobId,jobId))).orderBy(projectMilestonesTable.sortOrder,projectMilestonesTable.targetDate),
    db.select().from(projectTasksTable).where(and(eq(projectTasksTable.companyId,req.companyId!),eq(projectTasksTable.jobId,jobId))).orderBy(projectTasksTable.sortOrder,projectTasksTable.plannedStart),
    db.select().from(projectTaskDependenciesTable).where(and(eq(projectTaskDependenciesTable.companyId,req.companyId!),eq(projectTaskDependenciesTable.jobId,jobId))),
    db.select({
      id:projectTaskAssignmentsTable.id,taskId:projectTaskAssignmentsTable.taskId,workerId:projectTaskAssignmentsTable.workerId,
      workerName:workforceProfilesTable.name,plannedHours:projectTaskAssignmentsTable.plannedHours
    }).from(projectTaskAssignmentsTable).innerJoin(workforceProfilesTable,eq(workforceProfilesTable.id,projectTaskAssignmentsTable.workerId))
      .where(and(eq(projectTaskAssignmentsTable.companyId,req.companyId!),eq(projectTaskAssignmentsTable.jobId,jobId)))
  ]);
  const risk=await riskSummary(req.companyId!,jobId);
  res.json({
    milestones,
    tasks:taskRows.map(t=>({...t,plannedHours:num(t.plannedHours),progressPercent:num(t.progressPercent),
      dependencies:deps.filter(d=>d.taskId===t.id),
      assignments:assignments.filter(a=>a.taskId===t.id).map(a=>({...a,plannedHours:num(a.plannedHours)}))
    })),
    summary:{plannedHours:risk.plannedHours,actualHours:risk.actualHours,programmeProgress:risk.programmeProgress,lateCount:risk.lateCount,criticalLateCount:risk.criticalLateCount,blockedCount:risk.blockedCount,risk:risk.risk}
  });
});

router.post("/programme/jobs/:jobId/milestones",requirePermission("jobs.manage"),async(req,res)=>{
  const jobId=id(req.params.jobId),name=text(req.body?.name);
  if(!jobId||!name||!(await companyJob(req.companyId!,jobId)))return res.status(400).json({error:"Project and milestone name are required"});
  const [row]=await db.insert(projectMilestonesTable).values({
    companyId:req.companyId!,jobId,name,description:text(req.body?.description)||null,targetDate:date(req.body?.targetDate),
    sortOrder:Number(req.body?.sortOrder)||0,createdByUserId:req.userId??null
  }).returning();
  res.status(201).json(row);
});

router.post("/programme/jobs/:jobId/tasks",requirePermission("jobs.manage"),async(req,res)=>{
  const jobId=id(req.params.jobId),title=text(req.body?.title);
  if(!jobId||!title||!(await companyJob(req.companyId!,jobId)))return res.status(400).json({error:"Project and task title are required"});
  const plannedHours=Math.max(0,Number(req.body?.plannedHours)||0);
  const [row]=await db.insert(projectTasksTable).values({
    companyId:req.companyId!,jobId,milestoneId:id(req.body?.milestoneId),parentTaskId:id(req.body?.parentTaskId),
    title,description:text(req.body?.description)||null,trade:text(req.body?.trade)||null,
    plannedStart:date(req.body?.plannedStart),plannedFinish:date(req.body?.plannedFinish),
    plannedHours:String(plannedHours),criticalPath:req.body?.criticalPath===true,sortOrder:Number(req.body?.sortOrder)||0,
    createdByUserId:req.userId??null
  }).returning();
  res.status(201).json({...row,plannedHours});
});

router.patch("/programme/tasks/:taskId",async(req,res)=>{
  const allowed=canManage(req)||hasPermission(req,"jobs.update");
  if(!allowed)return res.status(403).json({error:"You do not have permission to update programme tasks"});
  const taskId=id(req.params.taskId);if(!taskId)return res.status(400).json({error:"Invalid task"});
  const [existing]=await db.select().from(projectTasksTable).where(and(eq(projectTasksTable.companyId,req.companyId!),eq(projectTasksTable.id,taskId))).limit(1);
  if(!existing)return res.status(404).json({error:"Task not found"});
  const changes:any={};
  if("status" in (req.body||{})){
    const status=text(req.body.status);if(!["not_started","ready","in_progress","blocked","complete"].includes(status))return res.status(400).json({error:"Invalid task status"});
    changes.status=status;
    if(status==="in_progress"&&!existing.actualStart)changes.actualStart=new Date();
    if(status==="complete"){changes.actualFinish=new Date();changes.progressPercent="100";changes.blockerReason=null;}
  }
  if("progressPercent" in (req.body||{}))changes.progressPercent=String(Math.min(100,Math.max(0,Number(req.body.progressPercent)||0)));
  if("blockerReason" in (req.body||{}))changes.blockerReason=text(req.body.blockerReason)||null;
  if("plannedStart" in (req.body||{}))changes.plannedStart=date(req.body.plannedStart);
  if("plannedFinish" in (req.body||{}))changes.plannedFinish=date(req.body.plannedFinish);
  if("plannedHours" in (req.body||{}))changes.plannedHours=String(Math.max(0,Number(req.body.plannedHours)||0));
  if("criticalPath" in (req.body||{}))changes.criticalPath=req.body.criticalPath===true;
  const [row]=await db.update(projectTasksTable).set(changes).where(and(eq(projectTasksTable.companyId,req.companyId!),eq(projectTasksTable.id,taskId))).returning();
  await db.insert(auditEventsTable).values({companyId:req.companyId!,userId:req.userId??null,actorType:"user",action:"programme.task.updated",entityType:"project_task",entityId:String(taskId),metadata:{jobId:row.jobId,status:row.status,progressPercent:row.progressPercent}});
  res.json({...row,plannedHours:num(row.plannedHours),progressPercent:num(row.progressPercent)});
});

router.post("/programme/tasks/:taskId/dependencies",requirePermission("jobs.manage"),async(req,res)=>{
  const taskId=id(req.params.taskId),dependsOn=id(req.body?.dependsOnTaskId);
  if(!taskId||!dependsOn||taskId===dependsOn)return res.status(400).json({error:"Choose a different predecessor task"});
  const [task,pre]=await Promise.all([
    db.select().from(projectTasksTable).where(and(eq(projectTasksTable.companyId,req.companyId!),eq(projectTasksTable.id,taskId))).limit(1),
    db.select().from(projectTasksTable).where(and(eq(projectTasksTable.companyId,req.companyId!),eq(projectTasksTable.id,dependsOn))).limit(1)
  ]);
  if(!task[0]||!pre[0]||task[0].jobId!==pre[0].jobId)return res.status(400).json({error:"Tasks must belong to the same project"});
  const [row]=await db.insert(projectTaskDependenciesTable).values({
    companyId:req.companyId!,jobId:task[0].jobId,taskId,dependsOnTaskId:dependsOn,dependencyType:"finish_to_start",lagDays:Number(req.body?.lagDays)||0
  }).returning();
  res.status(201).json(row);
});

router.post("/programme/tasks/:taskId/assignments",requirePermission("jobs.manage"),async(req,res)=>{
  const taskId=id(req.params.taskId),workerId=id(req.body?.workerId);
  if(!taskId||!workerId)return res.status(400).json({error:"Task and worker are required"});
  const [task,worker]=await Promise.all([
    db.select().from(projectTasksTable).where(and(eq(projectTasksTable.companyId,req.companyId!),eq(projectTasksTable.id,taskId))).limit(1),
    db.select().from(workforceProfilesTable).where(and(eq(workforceProfilesTable.companyId,req.companyId!),eq(workforceProfilesTable.id,workerId))).limit(1)
  ]);
  if(!task[0]||!worker[0])return res.status(404).json({error:"Task or worker not found"});
  const [row]=await db.insert(projectTaskAssignmentsTable).values({
    companyId:req.companyId!,jobId:task[0].jobId,taskId,workerId,plannedHours:String(Math.max(0,Number(req.body?.plannedHours)||0))
  }).returning();
  res.status(201).json(row);
});

router.post("/programme/jobs/:jobId/recalculate-risk",requirePermission("jobs.manage"),async(req,res)=>{
  const jobId=id(req.params.jobId);if(!jobId||!(await companyJob(req.companyId!,jobId)))return res.status(404).json({error:"Project not found"});
  const r=await riskSummary(req.companyId!,jobId);
  await db.update(marginProtectionAlertsTable).set({status:"superseded"})
    .where(and(eq(marginProtectionAlertsTable.companyId,req.companyId!),eq(marginProtectionAlertsTable.jobId,jobId),eq(marginProtectionAlertsTable.category,"programme"),eq(marginProtectionAlertsTable.status,"open")));
  if(["high","critical"].includes(r.risk)){
    await db.insert(marginProtectionAlertsTable).values({
      companyId:req.companyId!,jobId,severity:r.risk,category:"programme",
      title:r.criticalLateCount?`${r.criticalLateCount} critical-path task(s) are late`:`Project programme is at risk`,
      explanation:`${r.lateCount} task(s) are late and ${r.blockedCount} task(s) are blocked. Programme progress is ${r.programmeProgress.toFixed(1)}%.`,
      recommendedAction:"Review critical dependencies, crew allocation and recovery sequencing in the Project Command Centre.",
      financialImpact:"0"
    });
  }
  res.json({plannedHours:r.plannedHours,actualHours:r.actualHours,programmeProgress:r.programmeProgress,lateCount:r.lateCount,criticalLateCount:r.criticalLateCount,blockedCount:r.blockedCount,risk:r.risk});
});

export default router;
