import { Router } from "express";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import {
  db, jobsTable, usersTable, companyMembersTable,
  workforceProfilesTable, workforceAllocationsTable, workforceTimeEntriesTable,
  siteProgressUpdatesTable, auditEventsTable
} from "@workspace/db";
import { hasPermission, requirePermission } from "../lib/permissions";

const router=Router();
const money=(v:unknown)=>Number(v??0);
const positiveId=(v:unknown)=>{const n=Number(v);return Number.isInteger(n)&&n>0?n:null};
const text=(v:unknown)=>typeof v==="string"?v.trim():"";
const date=(v:unknown)=>{const d=new Date(String(v||""));return Number.isNaN(d.getTime())?null:d};

async function profileForUser(companyId:number,userId:number|null|undefined){
  if(!userId)return null;
  const [p]=await db.select().from(workforceProfilesTable)
    .where(and(eq(workforceProfilesTable.companyId,companyId),eq(workforceProfilesTable.userId,userId))).limit(1);
  return p??null;
}
async function ensureJob(companyId:number,jobId:number){
  const [job]=await db.select().from(jobsTable).where(and(eq(jobsTable.companyId,companyId),eq(jobsTable.id,jobId))).limit(1);
  return job??null;
}

router.get("/workforce/summary",requirePermission("workforce.read"),async(req,res)=>{
  const c=req.companyId!;
  const [workers,allocated,submitted,approvedCost]=await Promise.all([
    db.select({count:sql<number>`count(*)::int`}).from(workforceProfilesTable).where(and(eq(workforceProfilesTable.companyId,c),eq(workforceProfilesTable.active,true))),
    db.select({count:sql<number>`count(*)::int`}).from(workforceAllocationsTable).where(and(eq(workforceAllocationsTable.companyId,c),inArray(workforceAllocationsTable.status,["allocated","active"]))),
    db.select({count:sql<number>`count(*)::int`}).from(workforceTimeEntriesTable).where(and(eq(workforceTimeEntriesTable.companyId,c),eq(workforceTimeEntriesTable.status,"submitted"))),
    db.select({total:sql<string>`coalesce(sum(${workforceTimeEntriesTable.totalCost}),0)`}).from(workforceTimeEntriesTable).where(and(eq(workforceTimeEntriesTable.companyId,c),eq(workforceTimeEntriesTable.status,"approved"))),
  ]);
  res.json({activeWorkers:workers[0]?.count??0,activeAllocations:allocated[0]?.count??0,pendingTimesheets:submitted[0]?.count??0,approvedLabourCost:money(approvedCost[0]?.total)});
});

router.post("/workforce/sync-team",requirePermission("workforce.manage"),async(req,res)=>{
  const c=req.companyId!;
  const team=await db.select({userId:usersTable.id,name:usersTable.name,email:usersTable.email,role:companyMembersTable.role})
    .from(companyMembersTable).innerJoin(usersTable,eq(usersTable.id,companyMembersTable.userId))
    .where(eq(companyMembersTable.companyId,c));
  const existing=await db.select().from(workforceProfilesTable).where(eq(workforceProfilesTable.companyId,c));
  const byUser=new Map(existing.filter(x=>x.userId).map(x=>[x.userId!,x]));
  const created=[];
  for(const m of team){
    if(byUser.has(m.userId))continue;
    const [row]=await db.insert(workforceProfilesTable).values({
      companyId:c,userId:m.userId,name:m.name||m.email,workerType:"employee",email:m.email,
      trade:["operative","supervisor"].includes(m.role)?m.role:null,costRate:"0",chargeRate:"0"
    }).returning(); created.push(row);
  }
  res.json({created,teamCount:team.length});
});

router.get("/workforce/profiles",requirePermission("workforce.read"),async(req,res)=>{
  const rows=await db.select().from(workforceProfilesTable).where(eq(workforceProfilesTable.companyId,req.companyId!)).orderBy(desc(workforceProfilesTable.active),workforceProfilesTable.name);
  res.json(rows.map(x=>({...x,costRate:money(x.costRate),chargeRate:money(x.chargeRate),overtimeMultiplier:money(x.overtimeMultiplier)})));
});

router.post("/workforce/profiles",requirePermission("workforce.manage"),async(req,res)=>{
  const name=text(req.body?.name),workerType=text(req.body?.workerType)||"employee";
  if(!name||!["employee","subcontractor"].includes(workerType))return res.status(400).json({error:"Name and valid worker type are required"});
  const costRate=Math.max(0,Number(req.body?.costRate)||0),chargeRate=Math.max(0,Number(req.body?.chargeRate)||0);
  const [row]=await db.insert(workforceProfilesTable).values({
    companyId:req.companyId!,userId:positiveId(req.body?.userId),name,workerType,trade:text(req.body?.trade)||null,
    phone:text(req.body?.phone)||null,email:text(req.body?.email)||null,costRate:String(costRate),chargeRate:String(chargeRate),
    overtimeMultiplier:String(Math.max(1,Number(req.body?.overtimeMultiplier)||1.5))
  }).returning();
  res.status(201).json(row);
});

router.patch("/workforce/profiles/:id",requirePermission("workforce.manage"),async(req,res)=>{
  const id=positiveId(req.params.id);if(!id)return res.status(400).json({error:"Invalid worker"});
  const changes:any={};
  for(const k of ["name","trade","phone","email","workerType"] as const)if(k in (req.body||{}))changes[k]=text(req.body[k])||null;
  for(const k of ["costRate","chargeRate","overtimeMultiplier"] as const)if(k in (req.body||{}))changes[k]=String(Math.max(0,Number(req.body[k])||0));
  if(typeof req.body?.active==="boolean")changes.active=req.body.active;
  const [row]=await db.update(workforceProfilesTable).set(changes).where(and(eq(workforceProfilesTable.companyId,req.companyId!),eq(workforceProfilesTable.id,id))).returning();
  if(!row)return res.status(404).json({error:"Worker not found"});res.json(row);
});

router.get("/workforce/allocations",requirePermission("workforce.read"),async(req,res)=>{
  const jobId=positiveId(req.query.jobId);
  const rows=await db.select({
    id:workforceAllocationsTable.id,jobId:workforceAllocationsTable.jobId,jobTitle:jobsTable.title,
    workerId:workforceAllocationsTable.workerId,workerName:workforceProfilesTable.name,role:workforceAllocationsTable.role,
    plannedHours:workforceAllocationsTable.plannedHours,plannedCost:workforceAllocationsTable.plannedCost,
    startDate:workforceAllocationsTable.startDate,endDate:workforceAllocationsTable.endDate,status:workforceAllocationsTable.status,notes:workforceAllocationsTable.notes
  }).from(workforceAllocationsTable)
    .innerJoin(jobsTable,eq(jobsTable.id,workforceAllocationsTable.jobId))
    .innerJoin(workforceProfilesTable,eq(workforceProfilesTable.id,workforceAllocationsTable.workerId))
    .where(jobId?and(eq(workforceAllocationsTable.companyId,req.companyId!),eq(workforceAllocationsTable.jobId,jobId)):eq(workforceAllocationsTable.companyId,req.companyId!))
    .orderBy(desc(workforceAllocationsTable.startDate),desc(workforceAllocationsTable.id));
  res.json(rows.map(x=>({...x,plannedHours:money(x.plannedHours),plannedCost:money(x.plannedCost)})));
});

router.post("/workforce/allocations",requirePermission("workforce.manage"),async(req,res)=>{
  const jobId=positiveId(req.body?.jobId),workerId=positiveId(req.body?.workerId),plannedHours=Math.max(0,Number(req.body?.plannedHours)||0);
  if(!jobId||!workerId||!(await ensureJob(req.companyId!,jobId)))return res.status(400).json({error:"Valid project and worker are required"});
  const [worker]=await db.select().from(workforceProfilesTable).where(and(eq(workforceProfilesTable.companyId,req.companyId!),eq(workforceProfilesTable.id,workerId))).limit(1);
  if(!worker)return res.status(404).json({error:"Worker not found"});
  const plannedCost=Math.round(plannedHours*money(worker.costRate)*100)/100;
  const [row]=await db.insert(workforceAllocationsTable).values({
    companyId:req.companyId!,jobId,workerId,role:text(req.body?.role)||worker.trade,plannedHours:String(plannedHours),plannedCost:String(plannedCost),
    startDate:date(req.body?.startDate),endDate:date(req.body?.endDate),notes:text(req.body?.notes)||null,createdByUserId:req.userId??null
  }).returning();
  res.status(201).json({...row,plannedHours,plannedCost});
});

router.patch("/workforce/allocations/:id",requirePermission("workforce.manage"),async(req,res)=>{
  const id=positiveId(req.params.id),status=text(req.body?.status);
  if(!id||!["allocated","active","complete","cancelled"].includes(status))return res.status(400).json({error:"Invalid allocation"});
  const [row]=await db.update(workforceAllocationsTable).set({status}).where(and(eq(workforceAllocationsTable.companyId,req.companyId!),eq(workforceAllocationsTable.id,id))).returning();
  if(!row)return res.status(404).json({error:"Allocation not found"});res.json(row);
});

router.get("/workforce/time-entries",requirePermission("workforce.read"),async(req,res)=>{
  const jobId=positiveId(req.query.jobId),status=text(req.query.status);
  const filters=[eq(workforceTimeEntriesTable.companyId,req.companyId!)];
  if(jobId)filters.push(eq(workforceTimeEntriesTable.jobId,jobId));
  if(status)filters.push(eq(workforceTimeEntriesTable.status,status));
  const rows=await db.select({
    id:workforceTimeEntriesTable.id,jobId:workforceTimeEntriesTable.jobId,jobTitle:jobsTable.title,
    workerId:workforceTimeEntriesTable.workerId,workerName:workforceProfilesTable.name,workDate:workforceTimeEntriesTable.workDate,
    regularHours:workforceTimeEntriesTable.regularHours,overtimeHours:workforceTimeEntriesTable.overtimeHours,costRate:workforceTimeEntriesTable.costRate,
    totalCost:workforceTimeEntriesTable.totalCost,notes:workforceTimeEntriesTable.notes,status:workforceTimeEntriesTable.status,
    approvedAt:workforceTimeEntriesTable.approvedAt,createdAt:workforceTimeEntriesTable.createdAt
  }).from(workforceTimeEntriesTable)
    .innerJoin(jobsTable,eq(jobsTable.id,workforceTimeEntriesTable.jobId))
    .innerJoin(workforceProfilesTable,eq(workforceProfilesTable.id,workforceTimeEntriesTable.workerId))
    .where(and(...filters)).orderBy(desc(workforceTimeEntriesTable.workDate),desc(workforceTimeEntriesTable.id));
  res.json(rows.map(x=>({...x,regularHours:money(x.regularHours),overtimeHours:money(x.overtimeHours),costRate:money(x.costRate),totalCost:money(x.totalCost)})));
});

router.post("/workforce/time-entries",async(req,res)=>{
  const manage=hasPermission(req,"workforce.manage"),own=hasPermission(req,"workforce.submit_own");
  if(!manage&&!own)return res.status(403).json({error:"You do not have permission to submit time"});
  const jobId=positiveId(req.body?.jobId);let workerId=positiveId(req.body?.workerId);
  if(own&&!manage){const profile=await profileForUser(req.companyId!,req.userId);workerId=profile?.id??null;}
  if(!jobId||!workerId||!(await ensureJob(req.companyId!,jobId)))return res.status(400).json({error:"Valid project and worker are required"});
  const [worker]=await db.select().from(workforceProfilesTable).where(and(eq(workforceProfilesTable.companyId,req.companyId!),eq(workforceProfilesTable.id,workerId))).limit(1);
  if(!worker)return res.status(404).json({error:"Worker not found"});
  const regular=Math.max(0,Number(req.body?.regularHours)||0),overtime=Math.max(0,Number(req.body?.overtimeHours)||0);
  if(regular+overtime<=0)return res.status(400).json({error:"Enter hours worked"});
  const costRate=money(worker.costRate),otMult=money(worker.overtimeMultiplier)||1.5;
  const totalCost=Math.round((regular*costRate+overtime*costRate*otMult)*100)/100;
  const [row]=await db.insert(workforceTimeEntriesTable).values({
    companyId:req.companyId!,jobId,workerId,allocationId:positiveId(req.body?.allocationId),workDate:date(req.body?.workDate)??new Date(),
    regularHours:String(regular),overtimeHours:String(overtime),costRate:String(costRate),overtimeMultiplier:String(otMult),totalCost:String(totalCost),
    notes:text(req.body?.notes)||null,status:manage&&req.body?.approve===true?"approved":"submitted",submittedByUserId:req.userId??null,
    approvedByUserId:manage&&req.body?.approve===true?req.userId??null:null,approvedAt:manage&&req.body?.approve===true?new Date():null
  }).returning();
  res.status(201).json({...row,totalCost});
});

router.patch("/workforce/time-entries/:id/status",async(req,res)=>{
  const allowed=hasPermission(req,"workforce.approve")||hasPermission(req,"workforce.manage");
  if(!allowed)return res.status(403).json({error:"You do not have permission to approve timesheets"});
  const id=positiveId(req.params.id),status=text(req.body?.status);
  if(!id||!["approved","rejected","submitted"].includes(status))return res.status(400).json({error:"Invalid timesheet status"});
  const [row]=await db.update(workforceTimeEntriesTable).set({
    status,approvedByUserId:status==="approved"?req.userId??null:null,approvedAt:status==="approved"?new Date():null
  }).where(and(eq(workforceTimeEntriesTable.companyId,req.companyId!),eq(workforceTimeEntriesTable.id,id))).returning();
  if(!row)return res.status(404).json({error:"Time entry not found"});
  await db.insert(auditEventsTable).values({companyId:req.companyId!,userId:req.userId??null,actorType:"user",
    action:`workforce.timesheet.${status}`,entityType:"workforce_time_entry",entityId:String(id),metadata:{jobId:row.jobId,workerId:row.workerId,totalCost:row.totalCost}});
  res.json({...row,totalCost:money(row.totalCost)});
});

router.get("/workforce/jobs/:jobId/labour",requirePermission("workforce.read"),async(req,res)=>{
  const jobId=positiveId(req.params.jobId);if(!jobId)return res.status(400).json({error:"Invalid project"});
  const allocations=await db.select().from(workforceAllocationsTable).where(and(eq(workforceAllocationsTable.companyId,req.companyId!),eq(workforceAllocationsTable.jobId,jobId),inArray(workforceAllocationsTable.status,["allocated","active","complete"])));
  const approved=await db.select().from(workforceTimeEntriesTable).where(and(eq(workforceTimeEntriesTable.companyId,req.companyId!),eq(workforceTimeEntriesTable.jobId,jobId),eq(workforceTimeEntriesTable.status,"approved")));
  const plannedHours=allocations.reduce((s,x)=>s+money(x.plannedHours),0),plannedCost=allocations.reduce((s,x)=>s+money(x.plannedCost),0);
  const actualHours=approved.reduce((s,x)=>s+money(x.regularHours)+money(x.overtimeHours),0),actualCost=approved.reduce((s,x)=>s+money(x.totalCost),0);
  const progress=await db.select().from(siteProgressUpdatesTable).where(and(eq(siteProgressUpdatesTable.companyId,req.companyId!),eq(siteProgressUpdatesTable.jobId,jobId))).orderBy(desc(siteProgressUpdatesTable.createdAt)).limit(1);
  const progressPercent=money(progress[0]?.progressPercent);
  const expectedHoursAtProgress=plannedHours*progressPercent/100;
  const productivityVarianceHours=actualHours-expectedHoursAtProgress;
  res.json({plannedHours,plannedCost,actualHours,actualCost,varianceCost:actualCost-plannedCost,progressPercent,expectedHoursAtProgress,productivityVarianceHours});
});

router.post("/workforce/jobs/:jobId/progress",async(req,res)=>{
  const allowed=hasPermission(req,"workforce.approve")||hasPermission(req,"workforce.manage")||hasPermission(req,"jobs.update");
  if(!allowed)return res.status(403).json({error:"You do not have permission to update site progress"});
  const jobId=positiveId(req.params.jobId),progress=Math.min(100,Math.max(0,Number(req.body?.progressPercent)||0)),summary=text(req.body?.summary);
  if(!jobId||!summary||!(await ensureJob(req.companyId!,jobId)))return res.status(400).json({error:"Project and progress summary are required"});
  const profile=await profileForUser(req.companyId!,req.userId);
  const [row]=await db.insert(siteProgressUpdatesTable).values({
    companyId:req.companyId!,jobId,workerId:profile?.id??null,progressPercent:String(progress),summary,blockers:text(req.body?.blockers)||null,submittedByUserId:req.userId??null
  }).returning();
  res.status(201).json(row);
});

export default router;
