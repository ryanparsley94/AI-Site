import { Router, type Request } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, companyMembersTable } from "@workspace/db";
import {
  issueSessionIfValid,
  issueUserSession,
  isAdminPasswordValid,
  hasValidSession,
  getSessionPrincipal,
  adminOnly,
  COOKIE_NAME,
} from "../lib/adminAuth";
import { getOrCreateDefaultCompany, requireCompanyContext } from "../lib/company-context";
import { hashPassword, verifyPassword } from "../lib/password-auth";

const router = Router();

// Lightweight single-instance protection for the transitional bootstrap login.
// Commercial authentication should move this to a shared store (e.g. Redis)
// when CREWON is deployed across multiple API instances.
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_MAX_FAILURES = 8;
const attempts = new Map<string, { failures: number; resetAt: number }>();

function clientKey(req: Request): string {
  const forwarded = req.headers["x-forwarded-for"];
  const first = Array.isArray(forwarded) ? forwarded[0] : forwarded?.split(",")[0]?.trim();
  return first || req.ip || "unknown";
}

function getAttempt(key: string) {
  const now = Date.now();
  const current = attempts.get(key);
  if (!current || current.resetAt <= now) {
    const fresh = { failures: 0, resetAt: now + LOGIN_WINDOW_MS };
    attempts.set(key, fresh);
    return fresh;
  }
  return current;
}

function rateLimited(req: Request): { limited: boolean; retryAfterSeconds: number } {
  const attempt = getAttempt(clientKey(req));
  return {
    limited: attempt.failures >= LOGIN_MAX_FAILURES,
    retryAfterSeconds: Math.max(1, Math.ceil((attempt.resetAt - Date.now()) / 1000)),
  };
}

function recordFailure(req: Request): void {
  const key = clientKey(req);
  const attempt = getAttempt(key);
  attempt.failures += 1;
  attempts.set(key, attempt);
}

function clearFailures(req: Request): void {
  attempts.delete(clientKey(req));
}

/**
 * POST /auth/login
 * Transitional bootstrap login retained while existing Replit deployments are
 * migrated to real CREWON user accounts.
 */
router.post("/auth/login", async (req, res): Promise<void> => {
  const { password } = req.body as { password?: string };

  if (!process.env.SESSION_SECRET) {
    res.status(503).json({ error: "Admin authentication is not configured on this server." });
    return;
  }

  if (!password || typeof password !== "string") {
    res.status(400).json({ error: "password is required" });
    return;
  }

  const limit = rateLimited(req);
  if (limit.limited) {
    res.setHeader("Retry-After", String(limit.retryAfterSeconds));
    res.status(429).json({ error: "Too many login attempts. Please try again later." });
    return;
  }

  // Validate before touching tenant data so a bad password cannot bootstrap a company.
  if (!isAdminPasswordValid(password)) {
    recordFailure(req);
    res.status(401).json({ error: "Incorrect password" });
    return;
  }

  const company = await getOrCreateDefaultCompany();
  const ok = issueSessionIfValid(password, req, res, company.id);
  if (!ok) {
    recordFailure(req);
    res.status(401).json({ error: "Incorrect password" });
    return;
  }

  clearFailures(req);
  res.json({ ok: true, mode: "bootstrap" });
});

/**
 * POST /auth/user-login
 * Body: { email, password }
 * First commercial user-login path. Multi-company account switching can be
 * added later; for now the user's first company membership is selected.
 */
router.post("/auth/user-login", async (req, res): Promise<void> => {
  const { email, password } = req.body as { email?: string; password?: string };
  if (typeof email !== "string" || !email.includes("@") || email.length > 320) {
    res.status(400).json({ error: "A valid email is required" });
    return;
  }
  if (typeof password !== "string" || password.length === 0 || password.length > 512) {
    res.status(400).json({ error: "password is required" });
    return;
  }

  const limit = rateLimited(req);
  if (limit.limited) {
    res.setHeader("Retry-After", String(limit.retryAfterSeconds));
    res.status(429).json({ error: "Too many login attempts. Please try again later." });
    return;
  }

  const normalisedEmail = email.trim().toLowerCase();
  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, normalisedEmail)).limit(1);
  if (!user || user.status !== "active" || !verifyPassword(password, user.passwordHash)) {
    recordFailure(req);
    res.status(401).json({ error: "Invalid email or password" });
    return;
  }

  const [membership] = await db
    .select()
    .from(companyMembersTable)
    .where(eq(companyMembersTable.userId, user.id))
    .orderBy(companyMembersTable.id)
    .limit(1);

  if (!membership) {
    recordFailure(req);
    res.status(403).json({ error: "This user is not assigned to a CREWON company" });
    return;
  }

  if (!issueUserSession(user.id, membership.companyId, res)) {
    res.status(503).json({ error: "Authentication is not configured on this server" });
    return;
  }

  clearFailures(req);
  res.json({
    ok: true,
    mode: "user",
    user: { id: user.id, name: user.name, email: user.email },
    companyId: membership.companyId,
    role: membership.role,
  });
});

/**
 * POST /auth/bootstrap-owner
 * Converts the existing protected bootstrap deployment into its first real
 * owner account. Only available while the company has no members.
 */
router.post("/auth/bootstrap-owner", adminOnly, requireCompanyContext, async (req, res): Promise<void> => {
  const { email, name, password } = req.body as { email?: string; name?: string; password?: string };
  if (typeof email !== "string" || !email.includes("@") || email.length > 320) {
    res.status(400).json({ error: "A valid email is required" });
    return;
  }
  if (typeof name !== "string" || name.trim().length < 2 || name.length > 150) {
    res.status(400).json({ error: "A name is required" });
    return;
  }
  if (typeof password !== "string" || password.length < 12 || password.length > 512) {
    res.status(400).json({ error: "Password must be at least 12 characters" });
    return;
  }

  const companyId = req.companyId!;
  const [existingMember] = await db
    .select({ id: companyMembersTable.id })
    .from(companyMembersTable)
    .where(eq(companyMembersTable.companyId, companyId))
    .limit(1);
  if (existingMember) {
    res.status(409).json({ error: "This company already has a user account" });
    return;
  }

  const normalisedEmail = email.trim().toLowerCase();
  const [existingUser] = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.email, normalisedEmail)).limit(1);
  if (existingUser) {
    res.status(409).json({ error: "A user with this email already exists" });
    return;
  }

  const result = await db.transaction(async (tx) => {
    const [user] = await tx
      .insert(usersTable)
      .values({ email: normalisedEmail, name: name.trim(), passwordHash: hashPassword(password), status: "active" })
      .returning();
    const [membership] = await tx
      .insert(companyMembersTable)
      .values({ companyId, userId: user.id, role: "owner", permissions: {} })
      .returning();
    return { user, membership };
  });

  issueUserSession(result.user.id, companyId, res);
  res.status(201).json({
    ok: true,
    user: { id: result.user.id, email: result.user.email, name: result.user.name },
    role: result.membership.role,
  });
});

/** GET /auth/check — silent dashboard session check. */
router.get("/auth/check", (req, res): void => {
  const principal = getSessionPrincipal(req);
  res.json({
    authenticated: principal !== null,
    mode: principal?.actorType === "user" ? "user" : principal ? "bootstrap" : null,
  });
});

/** POST /auth/logout — clear session. */
router.post("/auth/logout", (req, res): void => {
  res.clearCookie(COOKIE_NAME, { path: "/api" });
  res.json({ ok: true });
});

export default router;
