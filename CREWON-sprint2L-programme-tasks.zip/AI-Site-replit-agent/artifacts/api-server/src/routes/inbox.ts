import { Router } from "express";
import { desc, eq } from "drizzle-orm";
import { db, callsTable, emailThreadsTable } from "@workspace/db";
import { requirePermission } from "../lib/permissions";

const router = Router();

type InboxItem = {
  id: string;
  channel: "phone" | "email";
  title: string;
  subtitle: string;
  preview: string;
  status: string;
  contactId: number | null;
  createdAt: Date;
  sourceId: number;
};

router.get("/inbox", requirePermission("inbox.read"), async (req, res) => {
  const companyId = req.companyId!;
  const [calls, emails] = await Promise.all([
    db.select().from(callsTable).where(eq(callsTable.companyId, companyId)).orderBy(desc(callsTable.createdAt)).limit(100),
    db.select().from(emailThreadsTable).where(eq(emailThreadsTable.companyId, companyId)).orderBy(desc(emailThreadsTable.createdAt)).limit(100),
  ]);

  const items: InboxItem[] = [
    ...calls.map((call) => ({
      id: `phone:${call.id}`,
      channel: "phone" as const,
      title: call.callerName || call.callerPhone || "Unknown caller",
      subtitle: call.callerPhone,
      preview: call.outcome || call.notes || "Phone call",
      status: call.reviewed ? "reviewed" : call.status || "unresolved",
      contactId: call.contactId ?? null,
      createdAt: call.createdAt,
      sourceId: call.id,
    })),
    ...emails.map((email) => ({
      id: `email:${email.id}`,
      channel: "email" as const,
      title: email.fromName || email.fromEmail,
      subtitle: email.subject,
      preview: email.bodyText.slice(0, 240),
      status: email.status,
      contactId: email.contactId ?? null,
      createdAt: email.createdAt,
      sourceId: email.id,
    })),
  ].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const channel = typeof req.query.channel === "string" ? req.query.channel : "all";
  const status = typeof req.query.status === "string" ? req.query.status : "all";
  const search = typeof req.query.search === "string" ? req.query.search.trim().toLowerCase() : "";

  const filtered = items.filter((item) => {
    if (channel !== "all" && item.channel !== channel) return false;
    if (status !== "all" && item.status !== status) return false;
    if (search && !`${item.title} ${item.subtitle} ${item.preview}`.toLowerCase().includes(search)) return false;
    return true;
  });

  res.json({
    items: filtered.slice(0, 100),
    counts: {
      all: items.length,
      phone: items.filter((i) => i.channel === "phone").length,
      email: items.filter((i) => i.channel === "email").length,
      attention: items.filter((i) => ["pending", "unresolved"].includes(i.status)).length,
    },
  });
});

export default router;
