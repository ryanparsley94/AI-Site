import { Router } from "express";
import { eq } from "drizzle-orm";
import { randomBytes } from "crypto";
import { db, companiesTable } from "@workspace/db";
import {
  GetCompanyResponse,
  UpdateCompanyBody,
  UpdateCompanyResponse,
  GetWidgetKeyResponse,
  RegenerateWidgetKeyResponse,
  UpdateWidgetSettingsBody,
  UpdateWidgetSettingsResponse,
} from "@workspace/api-zod";
// adminOnly is applied at the router level in routes/index.ts

const router = Router();

async function getCompanyForRequest(companyId: number) {
  const [company] = await db.select().from(companiesTable).where(eq(companiesTable.id, companyId));
  if (!company) throw new Error(`Company ${companyId} not found`);
  return company;
}

function mapWidgetKey(company: typeof companiesTable.$inferSelect) {
  return {
    widgetKey: company.widgetKey ?? null,
    color: company.widgetColor ?? "#1687ff",
    greeting: company.widgetGreeting ?? "Hi! How can I help you today?",
    widgetLeadNotify: company.widgetLeadNotify,
  };
}

router.get("/company", async (req, res): Promise<void> => {
  const company = await getCompanyForRequest(req.companyId!);
  res.json(GetCompanyResponse.parse({
    ...company,
    createdAt: company.createdAt.toISOString(),
  }));
});

router.patch("/company", async (req, res): Promise<void> => {
  const parsed = UpdateCompanyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const company = await getCompanyForRequest(req.companyId!);
  const [updated] = await db
    .update(companiesTable)
    .set(parsed.data)
    .where(eq(companiesTable.id, company.id))
    .returning();
  res.json(UpdateCompanyResponse.parse({
    ...updated,
    createdAt: updated.createdAt.toISOString(),
  }));
});

// ─── Widget key management ────────────────────────────────────────────────────

router.get("/company/widget-key", async (req, res): Promise<void> => {
  const company = await getCompanyForRequest(req.companyId!);
  res.json(GetWidgetKeyResponse.parse(mapWidgetKey(company)));
});

router.post("/company/widget-key", async (req, res): Promise<void> => {
  const company = await getCompanyForRequest(req.companyId!);
  const newKey = randomBytes(24).toString("hex");
  const [updated] = await db
    .update(companiesTable)
    .set({ widgetKey: newKey })
    .where(eq(companiesTable.id, company.id))
    .returning();
  res.json(RegenerateWidgetKeyResponse.parse(mapWidgetKey(updated)));
});

router.patch("/company/widget-settings", async (req, res): Promise<void> => {
  const parsed = UpdateWidgetSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const company = await getCompanyForRequest(req.companyId!);
  const updateData: Partial<typeof companiesTable.$inferInsert> = {};
  if (parsed.data.color !== undefined) updateData.widgetColor = parsed.data.color;
  if (parsed.data.greeting !== undefined) updateData.widgetGreeting = parsed.data.greeting;
  if (parsed.data.widgetLeadNotify !== undefined) updateData.widgetLeadNotify = parsed.data.widgetLeadNotify;
  const [updated] = await db
    .update(companiesTable)
    .set(updateData)
    .where(eq(companiesTable.id, company.id))
    .returning();
  res.json(UpdateWidgetSettingsResponse.parse(mapWidgetKey(updated)));
});

export default router;
