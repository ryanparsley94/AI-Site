import { Router } from "express";
import { createHash, randomBytes } from "crypto";
import { and, eq } from "drizzle-orm";
import { db, companyMembersTable, teamInvitationsTable, usersTable } from "@workspace/db";
import { requirePermission, ROLE_PERMISSIONS } from "../lib/permissions";

const router = Router();
const INVITE_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const ROLES = Object.keys(ROLE_PERMISSIONS);

router.get("/team", requirePermission("team.manage"), async (req, res) => {
  const companyId = req.companyId!;
  const members = await db.select({
    membershipId: companyMembersTable.id,
    userId: usersTable.id,
    name: usersTable.name,
    email: usersTable.email,
    status: usersTable.status,
    role: companyMembersTable.role,
    permissions: companyMembersTable.permissions,
    createdAt: companyMembersTable.createdAt,
  }).from(companyMembersTable)
    .innerJoin(usersTable, eq(usersTable.id, companyMembersTable.userId))
    .where(eq(companyMembersTable.companyId, companyId))
    .orderBy(companyMembersTable.id);

  const invites = await db.select({
    id: teamInvitationsTable.id,
    email: teamInvitationsTable.email,
    role: teamInvitationsTable.role,
    status: teamInvitationsTable.status,
    expiresAt: teamInvitationsTable.expiresAt,
    createdAt: teamInvitationsTable.createdAt,
  }).from(teamInvitationsTable)
    .where(and(eq(teamInvitationsTable.companyId, companyId), eq(teamInvitationsTable.status, "pending")))
    .orderBy(teamInvitationsTable.id);

  res.json({ members, invites, roles: ROLES });
});

router.post("/team/invitations", requirePermission("team.manage"), async (req, res) => {
  const companyId = req.companyId!;
  const email = typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";
  const role = typeof req.body?.role === "string" ? req.body.role : "operative";
  if (!email.includes("@") || email.length > 320) return res.status(400).json({ error: "A valid email is required" });
  if (!ROLES.includes(role) || role === "owner") return res.status(400).json({ error: "Choose a valid non-owner role" });

  const [existingUser] = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.email, email)).limit(1);
  if (existingUser) {
    const [membership] = await db.select({ id: companyMembersTable.id }).from(companyMembersTable)
      .where(and(eq(companyMembersTable.companyId, companyId), eq(companyMembersTable.userId, existingUser.id))).limit(1);
    if (membership) return res.status(409).json({ error: "That person is already on this CREWON team" });
  }

  await db.update(teamInvitationsTable).set({ status: "revoked" })
    .where(and(eq(teamInvitationsTable.companyId, companyId), eq(teamInvitationsTable.email, email), eq(teamInvitationsTable.status, "pending")));

  const token = randomBytes(32).toString("hex");
  const tokenHash = createHash("sha256").update(token).digest("hex");
  const [invite] = await db.insert(teamInvitationsTable).values({
    companyId,
    email,
    role,
    permissions: {},
    tokenHash,
    invitedByUserId: req.userId ?? null,
    expiresAt: new Date(Date.now() + INVITE_TTL_MS),
  }).returning();

  // Until transactional email is wired per tenant, return a copyable invite URL.
  const base = process.env.CREWON_PUBLIC_APP_URL?.replace(/\/$/, "") || "";
  res.status(201).json({
    invite: { id: invite.id, email: invite.email, role: invite.role, expiresAt: invite.expiresAt },
    inviteUrl: `${base}/accept-invite?token=${token}`,
  });
});

router.patch("/team/members/:membershipId", requirePermission("team.manage"), async (req, res) => {
  const companyId = req.companyId!;
  const membershipId = Number(req.params.membershipId);
  const role = typeof req.body?.role === "string" ? req.body.role : undefined;
  if (!Number.isInteger(membershipId) || membershipId <= 0) return res.status(400).json({ error: "Invalid membership" });
  if (!role || !ROLES.includes(role)) return res.status(400).json({ error: "Invalid role" });

  const [target] = await db.select().from(companyMembersTable)
    .where(and(eq(companyMembersTable.id, membershipId), eq(companyMembersTable.companyId, companyId))).limit(1);
  if (!target) return res.status(404).json({ error: "Team member not found" });
  if ((target.role === "owner" || role === "owner") && req.userRole !== "owner" && req.actorType !== "bootstrap-admin") {
    return res.status(403).json({ error: "Only a CREWON owner can grant or change owner access" });
  }
  if (target.role === "owner" && role !== "owner") {
    const owners = await db.select({ id: companyMembersTable.id }).from(companyMembersTable)
      .where(and(eq(companyMembersTable.companyId, companyId), eq(companyMembersTable.role, "owner")));
    if (owners.length <= 1) return res.status(409).json({ error: "CREWON must always have at least one owner" });
  }

  const [updated] = await db.update(companyMembersTable).set({ role }).where(eq(companyMembersTable.id, membershipId)).returning();
  res.json(updated);
});

router.delete("/team/members/:membershipId", requirePermission("team.manage"), async (req, res) => {
  const companyId = req.companyId!;
  const membershipId = Number(req.params.membershipId);
  const [target] = await db.select().from(companyMembersTable)
    .where(and(eq(companyMembersTable.id, membershipId), eq(companyMembersTable.companyId, companyId))).limit(1);
  if (!target) return res.status(404).json({ error: "Team member not found" });
  if (target.role === "owner") return res.status(409).json({ error: "Transfer or add another owner before removing this owner" });
  await db.delete(companyMembersTable).where(eq(companyMembersTable.id, membershipId));
  res.status(204).end();
});

router.delete("/team/invitations/:id", requirePermission("team.manage"), async (req, res) => {
  const id = Number(req.params.id);
  await db.update(teamInvitationsTable).set({ status: "revoked" })
    .where(and(eq(teamInvitationsTable.id, id), eq(teamInvitationsTable.companyId, req.companyId!)));
  res.status(204).end();
});

export default router;
