import { Router } from "express";
import { eq, desc, and } from "drizzle-orm";
import { db, quotesTable, jobsTable } from "@workspace/db";
import { openai } from "@workspace/integrations-openai-ai-server";
import {
  ListQuotesResponse,
  CreateQuoteBody,
  CreateQuoteResponse,
  GetQuoteParams,
  GetQuoteResponse,
  UpdateQuoteParams,
  UpdateQuoteBody,
  UpdateQuoteResponse,
  DeleteQuoteParams,
  SearchMaterialPricesBody,
  SearchMaterialPricesResponse,
} from "@workspace/api-zod";

const router = Router();

function mapQuote(q: typeof quotesTable.$inferSelect) {
  return {
    ...q,
    grandTotal: Number(q.grandTotal),
    marginPercent: q.marginPercent !== null ? Number(q.marginPercent) : null,
    vatPercent: q.vatPercent !== null ? Number(q.vatPercent) : null,
    marginAmount: q.marginAmount !== null ? Number(q.marginAmount) : null,
    vatAmount: q.vatAmount !== null ? Number(q.vatAmount) : null,
    totalIncVat: q.totalIncVat !== null ? Number(q.totalIncVat) : null,
    materials: Array.isArray(q.materials) ? q.materials : [],
    createdAt: q.createdAt.toISOString(),
  };
}

// Auto-sync job.estimatedValue when a quote with totalIncVat is linked to a job
async function syncJobEstimatedValue(jobId: number, totalIncVat: number | null, companyId: number) {
  if (totalIncVat !== null && !isNaN(totalIncVat)) {
    await db
      .update(jobsTable)
      .set({ estimatedValue: String(totalIncVat) })
      .where(and(eq(jobsTable.id, jobId), eq(jobsTable.companyId, companyId)));
  }
}

router.get("/quotes", async (req, res): Promise<void> => {
  let query = db.select().from(quotesTable).where(eq(quotesTable.companyId, req.companyId!)).orderBy(desc(quotesTable.createdAt)).$dynamic();
  if (req.query.jobId) {
    query = query.where(and(eq(quotesTable.companyId, req.companyId!), eq(quotesTable.jobId, Number(req.query.jobId))));
  }
  const rows = await query;
  res.json(ListQuotesResponse.parse(rows.map(mapQuote)));
});

router.post("/quotes/price-search", async (req, res): Promise<void> => {
  const parsed = SearchMaterialPricesBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { materials } = parsed.data;

  const prompt = `You are a UK construction materials cost-estimating assistant. This endpoint does NOT have live supplier account access. For each material, identify its trade category and provide a cautious benchmark estimate using general UK market knowledge. Do not claim that any price was fetched live or is the contractor's negotiated price. Suggested retailers below are context only:

ELECTRICAL items (cables, consumer units, sockets, switches, fittings, conduit, MCBs, RCDs, LED drivers, lighting, trunking):
→ Primary: Screwfix (screwfix.com), TLC Direct (tlc-direct.co.uk)
→ Also use: CEF (cef.co.uk), Toolstation (toolstation.com), RS Components (rs-online.com)

PLUMBING & HEATING items (pipes, fittings, valves, radiators, boiler parts, cylinders, taps, waste fittings):
→ Primary: Screwfix (screwfix.com), City Plumbing (cityplumbing.co.uk)
→ Also use: Toolstation (toolstation.com), Wolseley (wolseley.co.uk), Plumbfix (plumbfix.com)

ROOFING items (tiles, slates, battens, felt, flashing, guttering, fascia, soffits, ridge, hip):
→ Primary: Roofbase (roofbase.com), Travis Perkins (travisperkins.co.uk)
→ Also use: Jewson (jewson.co.uk), Eurocell (eurocell.co.uk), National Roofing Supplies

TILES & FLOORING items (ceramic, porcelain, natural stone, adhesive, grout, backer board):
→ Primary: Topps Tiles (toppstiles.co.uk), Tile Giant (tilegiant.co.uk)
→ Also use: CTD Tiles (ctdtiles.co.uk), Screwfix (screwfix.com), Tile Mountain (tilemountain.co.uk)

TIMBER & SHEET MATERIALS (timber, OSB, plywood, MDF, plasterboard, insulation, lintels):
→ Primary: Travis Perkins (travisperkins.co.uk), Jewson (jewson.co.uk)
→ Also use: Buildbase (buildbase.co.uk), B&Q Trade (diy.com), Wickes (wickes.co.uk)

DECORATING items (paint, filler, primer, masking tape, brushes, rollers, wallpaper):
→ Primary: Brewers Decorator Centres (brewers.co.uk), Screwfix (screwfix.com)
→ Also use: Toolstation (toolstation.com), Dulux Decorator Centre (duluxdecoratorcentre.co.uk)

GENERAL BUILDING items (bricks, blocks, sand, cement, aggregates, concrete, DPC, cavity wall ties):
→ Primary: Jewson (jewson.co.uk), Travis Perkins (travisperkins.co.uk)
→ Also use: Buildbase (buildbase.co.uk), Aggregate Industries, Hanson Building Materials

Return ONLY valid JSON matching this exact structure:
{
  "materials": [
    {
      "name": "material name",
      "quantity": number,
      "unit": "unit",
      "unitPrice": number (GBP per unit, ex-VAT),
      "source": "Benchmark estimate",
      "sourceUrl": "",
      "total": number (unitPrice * quantity),
      "confidence": "high" | "medium" | "low"
    }
  ],
  "grandTotal": number,
  "disclaimer": "string"
}

Materials to price:
${materials.map((m: { name: string; quantity: number; unit: string }) => `- ${m.quantity} ${m.unit} of ${m.name}`).join("\n")}

Use conservative benchmark UK trade/retail estimates in GBP (ex-VAT). Leave sourceUrl blank because no live catalogue lookup is being performed. Set confidence to "medium" or "low" unless the item is exceptionally standard. The disclaimer MUST state that these are AI benchmark estimates, not live supplier or negotiated-account prices, exclude VAT at 20%, and must be replaced or confirmed with live supplier pricing before quoting or purchasing.`;

  const completion = await openai.chat.completions.create({
    model: "gpt-5.6-luna",
    max_completion_tokens: 2048,
    messages: [
      {
        role: "user",
        content: prompt,
      },
    ],
  });

  const content = completion.choices[0]?.message?.content ?? "{}";

  // Extract JSON from response
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    res.status(500).json({ error: "AI returned invalid response" });
    return;
  }

  const parsed2 = JSON.parse(jsonMatch[0]);
  res.json(SearchMaterialPricesResponse.parse(parsed2));
});

router.post("/quotes", async (req, res): Promise<void> => {
  const parsed = CreateQuoteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { grandTotal, materials, marginPercent, vatPercent, marginAmount, vatAmount, totalIncVat, ...rest } = parsed.data;
  const [row] = await db
    .insert(quotesTable)
    .values({
      ...rest,
      companyId: req.companyId!,
      materials: materials ?? [],
      grandTotal: String(grandTotal ?? 0),
      marginPercent: marginPercent !== undefined ? String(marginPercent) : null,
      vatPercent: vatPercent !== undefined ? String(vatPercent) : null,
      marginAmount: marginAmount !== undefined ? String(marginAmount) : null,
      vatAmount: vatAmount !== undefined ? String(vatAmount) : null,
      totalIncVat: totalIncVat !== undefined ? String(totalIncVat) : null,
    })
    .returning();

  // Auto-sync job estimatedValue
  if (row.jobId && row.totalIncVat !== null) {
    await syncJobEstimatedValue(row.jobId, Number(row.totalIncVat), req.companyId!);
  }

  res.status(201).json(CreateQuoteResponse.parse(mapQuote(row)));
});

router.get("/quotes/:id", async (req, res): Promise<void> => {
  const params = GetQuoteParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [row] = await db.select().from(quotesTable).where(and(eq(quotesTable.id, params.data.id), eq(quotesTable.companyId, req.companyId!)));
  if (!row) { res.status(404).json({ error: "Not found" }); return; }
  res.json(GetQuoteResponse.parse(mapQuote(row)));
});

router.patch("/quotes/:id", async (req, res): Promise<void> => {
  const params = UpdateQuoteParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateQuoteBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { grandTotal, materials, marginPercent, vatPercent, marginAmount, vatAmount, totalIncVat, ...rest } = parsed.data;
  const updateData: Record<string, unknown> = { ...rest };
  if (materials !== undefined) updateData.materials = materials;
  if (grandTotal !== undefined) updateData.grandTotal = String(grandTotal);
  if (marginPercent !== undefined) updateData.marginPercent = marginPercent !== null ? String(marginPercent) : null;
  if (vatPercent !== undefined) updateData.vatPercent = vatPercent !== null ? String(vatPercent) : null;
  if (marginAmount !== undefined) updateData.marginAmount = marginAmount !== null ? String(marginAmount) : null;
  if (vatAmount !== undefined) updateData.vatAmount = vatAmount !== null ? String(vatAmount) : null;
  if (totalIncVat !== undefined) updateData.totalIncVat = totalIncVat !== null ? String(totalIncVat) : null;
  const [row] = await db
    .update(quotesTable)
    .set(updateData)
    .where(and(eq(quotesTable.id, params.data.id), eq(quotesTable.companyId, req.companyId!)))
    .returning();
  if (!row) { res.status(404).json({ error: "Not found" }); return; }

  // Auto-sync job estimatedValue when quote is linked to a job
  if (row.jobId && row.totalIncVat !== null) {
    await syncJobEstimatedValue(row.jobId, Number(row.totalIncVat), req.companyId!);
  }

  res.json(UpdateQuoteResponse.parse(mapQuote(row)));
});

router.delete("/quotes/:id", async (req, res): Promise<void> => {
  const params = DeleteQuoteParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(quotesTable).where(and(eq(quotesTable.id, params.data.id), eq(quotesTable.companyId, req.companyId!)));
  res.status(204).end();
});

export default router;
