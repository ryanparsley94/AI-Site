import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import companyRouter from "./company";
import assistantsRouter from "./assistants";
import contactsRouter from "./contacts";
import jobsRouter from "./jobs";
import callsRouter from "./calls";
import quotesRouter from "./quotes";
import invoicesRouter from "./invoices";
import certificatesRouter from "./certificates";
import dashboardRouter from "./dashboard";
import widgetRouter from "./widget";
import emailInboundRouter from "./email-threads-inbound";
import emailThreadsRouter from "./email-threads";
import integrationsRouter from "./integrations";
import tasksRouter from "./tasks";
import marketingRouter from "./marketing";
import supportQuestionsRouter from "./support-questions";
import teamInvitePublicRouter from "./team-invite-public";
import teamRouter from "./team";
import inboxRouter from "./inbox";
import procurementRouter from "./procurement";
import marginProtectionRouter from "./margin-protection";
import workforceRouter from "./workforce";
import supervisorRouter from "./supervisor";
import siteDiaryRouter from "./site-diary";
import projectTimelineRouter from "./project-timeline";
import projectCommandCentreRouter from "./project-command-centre";
import programmeRouter from "./programme";
import { adminOnly } from "../lib/adminAuth";
import { requireCompanyContext } from "../lib/company-context";
import { auditMutations } from "../middlewares/audit";

const router: IRouter = Router();

// ── Public routes (no session required) ──────────────────────────────────────
// Health check and auth endpoints are always accessible.
// Widget endpoints (widget.js, widget/config, widget/chat) are public by design
// so they can be loaded from any third-party website.
// Email inbound webhook (/email-threads/inbound) is public so Resend can POST to it;
// it is protected by svix webhook signature verification instead of the session cookie.
// Support questions (/support-questions) is public so landing-page visitors can submit.
router.use(healthRouter);
router.use(authRouter);
router.use(widgetRouter);
router.use(emailInboundRouter);
router.use(supportQuestionsRouter);
router.use(teamInvitePublicRouter);

// ── Dashboard routes ──────────────────────────────────────────────────────────
// Every management endpoint below this line requires a valid signed admin session.
// Keep public webhooks/widgets/support routes above this middleware.
router.use(adminOnly);
router.use(requireCompanyContext);
router.use(auditMutations);

router.use(companyRouter);
router.use(assistantsRouter);
router.use(contactsRouter);
router.use(jobsRouter);
router.use(callsRouter);
router.use(quotesRouter);
router.use(invoicesRouter);
router.use(certificatesRouter);
router.use(dashboardRouter);
router.use(emailThreadsRouter);
router.use(integrationsRouter);
router.use(marketingRouter);
router.use(tasksRouter);
router.use(teamRouter);
router.use(inboxRouter);
router.use(procurementRouter);
router.use(marginProtectionRouter);
router.use(workforceRouter);
router.use(supervisorRouter);
router.use(siteDiaryRouter);
router.use(projectTimelineRouter);
router.use(projectCommandCentreRouter);
router.use(programmeRouter);

export default router;
