import { Router } from "express";
import { and, desc, eq, ilike, inArray, sql } from "drizzle-orm";
import {
  db,
  deliveriesTable,
  jobsTable,
  procurementProductsTable,
  purchaseOrderItemsTable,
  purchaseOrdersTable,
  rfqItemsTable,
  rfqResponsesTable,
  rfqsTable,
  supplierAccountsTable,
  supplierPricesTable,
  suppliersTable,
  quotesTable,
  materialRequirementsTable,
  procurementAuthorityTable,
  procurementPlansTable,
  auditEventsTable,
  goodsReceiptsTable,
  goodsReceiptItemsTable,
  supplierInvoicesTable,
  supplierInvoiceItemsTable,
} from "@workspace/db";
import { requirePermission } from "../lib/permissions";

const router = Router();

const money = (value: unknown) => Number(value ?? 0);
const positiveId = (value: unknown) => {
  const id = Number(value);
  return Number.isInteger(id) && id > 0 ? id : null;
};
const optionalText = (value: unknown) => typeof value === "string" && value.trim() ? value.trim() : null;
const requiredText = (value: unknown) => typeof value === "string" && value.trim() ? value.trim() : "";
const optionalDate = (value: unknown) => {
  if (!value) return null;
  const date = new Date(String(value));
  return Number.isNaN(date.getTime()) ? null : date;
};


const normText = (value: unknown) => String(value ?? "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
const tokenSet = (value: unknown) => new Set(normText(value).split(/\s+/).filter(Boolean));
const similarityScore = (query: unknown, candidate: unknown) => {
  const a = tokenSet(query); const b = tokenSet(candidate);
  if (!a.size || !b.size) return 0;
  let overlap = 0;
  for (const token of a) if (b.has(token)) overlap++;
  const jaccard = overlap / new Set([...a, ...b]).size;
  const q = normText(query), c = normText(candidate);
  const contains = q && c && (q.includes(c) || c.includes(q)) ? 0.25 : 0;
  return Math.min(1, jaccard + contains);
};
const knownPriceSource = (source: unknown) => !["ai", "benchmark", "estimated", "web_estimate", "unknown"].includes(normText(source).replace(/\s+/g, "_"));
const accountDeliveryCost = (account: any, subtotal: number) => {
  const minimum = money(account?.minimumOrder);
  const freeThreshold = money(account?.freeDeliveryThreshold);
  const delivery = money(account?.deliveryCharge);
  if (minimum > 0 && subtotal < minimum) return { valid: false, fee: 0, minimumOrder: minimum };
  return { valid: true, fee: freeThreshold > 0 && subtotal >= freeThreshold ? 0 : delivery, minimumOrder: minimum };
};

async function companySupplier(companyId: number, supplierId: number) {
  const [row] = await db.select().from(suppliersTable)
    .where(and(eq(suppliersTable.companyId, companyId), eq(suppliersTable.id, supplierId))).limit(1);
  return row;
}

async function companyProduct(companyId: number, productId: number) {
  const [row] = await db.select().from(procurementProductsTable)
    .where(and(eq(procurementProductsTable.companyId, companyId), eq(procurementProductsTable.id, productId))).limit(1);
  return row;
}

// ── Overview ────────────────────────────────────────────────────────────────
router.get("/procurement/summary", requirePermission("purchasing.read"), async (req, res) => {
  const companyId = req.companyId!;
  const [supplierCount, productCount, openPoCount, pendingDeliveryCount, openRfqs, poTotals] = await Promise.all([
    db.select({ count: sql<number>`count(*)::int` }).from(suppliersTable).where(and(eq(suppliersTable.companyId, companyId), eq(suppliersTable.status, "active"))),
    db.select({ count: sql<number>`count(*)::int` }).from(procurementProductsTable).where(and(eq(procurementProductsTable.companyId, companyId), eq(procurementProductsTable.status, "active"))),
    db.select({ count: sql<number>`count(*)::int` }).from(purchaseOrdersTable).where(and(eq(purchaseOrdersTable.companyId, companyId), inArray(purchaseOrdersTable.status, ["draft", "approval_required", "approved", "ordered", "part_received"]))),
    db.select({ count: sql<number>`count(*)::int` }).from(deliveriesTable).where(and(eq(deliveriesTable.companyId, companyId), inArray(deliveriesTable.status, ["scheduled", "in_transit", "part_received"]))),
    db.select({ count: sql<number>`count(*)::int` }).from(rfqsTable).where(and(eq(rfqsTable.companyId, companyId), inArray(rfqsTable.status, ["draft", "sent", "responses_received"]))),
    db.select({ total: sql<string>`coalesce(sum(${purchaseOrdersTable.total}), 0)` }).from(purchaseOrdersTable).where(and(eq(purchaseOrdersTable.companyId, companyId), inArray(purchaseOrdersTable.status, ["approved", "ordered", "part_received"]))),
  ]);

  res.json({
    suppliers: supplierCount[0]?.count ?? 0,
    products: productCount[0]?.count ?? 0,
    openPurchaseOrders: openPoCount[0]?.count ?? 0,
    pendingDeliveries: pendingDeliveryCount[0]?.count ?? 0,
    openRfqs: openRfqs[0]?.count ?? 0,
    committedSpend: money(poTotals[0]?.total),
  });
});

// ── Suppliers & trade accounts ─────────────────────────────────────────────
router.get("/procurement/suppliers", requirePermission("purchasing.read"), async (req, res) => {
  const rows = await db.select().from(suppliersTable)
    .where(eq(suppliersTable.companyId, req.companyId!)).orderBy(desc(suppliersTable.preferred), suppliersTable.name);
  const ids = rows.map((row) => row.id);
  const accounts = ids.length
    ? await db.select().from(supplierAccountsTable).where(and(eq(supplierAccountsTable.companyId, req.companyId!), inArray(supplierAccountsTable.supplierId, ids))).orderBy(desc(supplierAccountsTable.isDefault), supplierAccountsTable.id)
    : [];
  res.json(rows.map((supplier) => ({ ...supplier, accounts: accounts.filter((account) => account.supplierId === supplier.id) })));
});

router.post("/procurement/suppliers", requirePermission("purchasing.manage"), async (req, res) => {
  const name = requiredText(req.body?.name);
  if (!name) return res.status(400).json({ error: "Supplier name is required" });
  const [row] = await db.insert(suppliersTable).values({
    companyId: req.companyId!,
    name,
    phone: optionalText(req.body?.phone),
    email: optionalText(req.body?.email),
    website: optionalText(req.body?.website),
    address: optionalText(req.body?.address),
    preferred: req.body?.preferred === true,
    notes: optionalText(req.body?.notes),
  }).returning();
  res.status(201).json(row);
});

router.patch("/procurement/suppliers/:id", requirePermission("purchasing.manage"), async (req, res) => {
  const id = positiveId(req.params.id);
  if (!id) return res.status(400).json({ error: "Invalid supplier" });
  const changes: Record<string, unknown> = {};
  for (const field of ["name", "phone", "email", "website", "address", "notes", "status"] as const) {
    if (field in (req.body ?? {})) changes[field] = field === "name" ? requiredText(req.body[field]) : optionalText(req.body[field]);
  }
  if (typeof req.body?.preferred === "boolean") changes.preferred = req.body.preferred;
  const [row] = await db.update(suppliersTable).set(changes)
    .where(and(eq(suppliersTable.companyId, req.companyId!), eq(suppliersTable.id, id))).returning();
  if (!row) return res.status(404).json({ error: "Supplier not found" });
  res.json(row);
});

router.post("/procurement/suppliers/:id/accounts", requirePermission("purchasing.manage"), async (req, res) => {
  const supplierId = positiveId(req.params.id);
  if (!supplierId || !(await companySupplier(req.companyId!, supplierId))) return res.status(404).json({ error: "Supplier not found" });
  const accountName = requiredText(req.body?.accountName) || "Trade account";
  if (req.body?.isDefault === true) {
    await db.update(supplierAccountsTable).set({ isDefault: false })
      .where(and(eq(supplierAccountsTable.companyId, req.companyId!), eq(supplierAccountsTable.supplierId, supplierId)));
  }
  const [row] = await db.insert(supplierAccountsTable).values({
    companyId: req.companyId!, supplierId, accountName,
    accountNumber: optionalText(req.body?.accountNumber), branch: optionalText(req.body?.branch),
    pricingMethod: requiredText(req.body?.pricingMethod) || "manual",
    deliveryTerms: optionalText(req.body?.deliveryTerms),
    minimumOrder: String(Math.max(0, Number(req.body?.minimumOrder) || 0)),
    deliveryCharge: String(Math.max(0, Number(req.body?.deliveryCharge) || 0)),
    freeDeliveryThreshold: String(Math.max(0, Number(req.body?.freeDeliveryThreshold) || 0)),
    deliveryLeadTimeDays: Number.isFinite(Number(req.body?.deliveryLeadTimeDays)) ? Number(req.body.deliveryLeadTimeDays) : null,
    isDefault: req.body?.isDefault === true,
  }).returning();
  res.status(201).json(row);
});


router.patch("/procurement/supplier-accounts/:id", requirePermission("purchasing.manage"), async (req, res) => {
  const id = positiveId(req.params.id);
  if (!id) return res.status(400).json({ error: "Invalid supplier account" });
  const [existing] = await db.select().from(supplierAccountsTable)
    .where(and(eq(supplierAccountsTable.id, id), eq(supplierAccountsTable.companyId, req.companyId!))).limit(1);
  if (!existing) return res.status(404).json({ error: "Supplier account not found" });
  const changes: Record<string, unknown> = {};
  for (const key of ["accountName", "accountNumber", "branch", "pricingMethod", "deliveryTerms"] as const) {
    if (key in (req.body ?? {})) changes[key] = key === "accountName" ? requiredText(req.body[key]) : optionalText(req.body[key]);
  }
  for (const key of ["minimumOrder", "deliveryCharge", "freeDeliveryThreshold"] as const) {
    if (key in (req.body ?? {})) changes[key] = String(Math.max(0, Number(req.body[key]) || 0));
  }
  if ("deliveryLeadTimeDays" in (req.body ?? {})) changes.deliveryLeadTimeDays = Number.isFinite(Number(req.body.deliveryLeadTimeDays)) ? Number(req.body.deliveryLeadTimeDays) : null;
  if (typeof req.body?.isDefault === "boolean") changes.isDefault = req.body.isDefault;
  const [row] = await db.update(supplierAccountsTable).set(changes)
    .where(and(eq(supplierAccountsTable.id, id), eq(supplierAccountsTable.companyId, req.companyId!))).returning();
  res.json({
    ...row, minimumOrder: money(row.minimumOrder), deliveryCharge: money(row.deliveryCharge),
    freeDeliveryThreshold: money(row.freeDeliveryThreshold),
  });
});

// ── Product catalogue & supplier-specific price history ─────────────────────
router.get("/procurement/products", requirePermission("purchasing.read"), async (req, res) => {
  const search = optionalText(req.query.search);
  const where = search
    ? and(eq(procurementProductsTable.companyId, req.companyId!), ilike(procurementProductsTable.name, `%${search}%`))
    : eq(procurementProductsTable.companyId, req.companyId!);
  const products = await db.select().from(procurementProductsTable).where(where).orderBy(procurementProductsTable.name);
  const ids = products.map((p) => p.id);
  const prices = ids.length
    ? await db.select({
        id: supplierPricesTable.id, productId: supplierPricesTable.productId, supplierId: supplierPricesTable.supplierId,
        supplierAccountId: supplierPricesTable.supplierAccountId, supplierName: suppliersTable.name,
        supplierSku: supplierPricesTable.supplierSku, unitCost: supplierPricesTable.unitCost,
        availability: supplierPricesTable.availability, leadTimeDays: supplierPricesTable.leadTimeDays,
        source: supplierPricesTable.source, validFrom: supplierPricesTable.validFrom,
      }).from(supplierPricesTable)
        .innerJoin(suppliersTable, eq(suppliersTable.id, supplierPricesTable.supplierId))
        .where(and(eq(supplierPricesTable.companyId, req.companyId!), inArray(supplierPricesTable.productId, ids)))
        .orderBy(desc(supplierPricesTable.validFrom))
    : [];
  res.json(products.map((product) => ({
    ...product,
    defaultWastePercent: money(product.defaultWastePercent),
    prices: prices.filter((price) => price.productId === product.id).map((price) => ({ ...price, unitCost: money(price.unitCost) })),
  })));
});

router.post("/procurement/products", requirePermission("purchasing.manage"), async (req, res) => {
  const name = requiredText(req.body?.name);
  if (!name) return res.status(400).json({ error: "Product name is required" });
  const [row] = await db.insert(procurementProductsTable).values({
    companyId: req.companyId!, name,
    sku: optionalText(req.body?.sku), description: optionalText(req.body?.description), category: optionalText(req.body?.category),
    manufacturer: optionalText(req.body?.manufacturer), manufacturerPartNumber: optionalText(req.body?.manufacturerPartNumber),
    unit: requiredText(req.body?.unit) || "each", defaultWastePercent: String(Number(req.body?.defaultWastePercent ?? 0) || 0),
  }).returning();
  res.status(201).json({ ...row, defaultWastePercent: money(row.defaultWastePercent) });
});

router.post("/procurement/products/:id/prices", requirePermission("purchasing.manage"), async (req, res) => {
  const productId = positiveId(req.params.id);
  const supplierId = positiveId(req.body?.supplierId);
  const unitCost = Number(req.body?.unitCost);
  if (!productId || !(await companyProduct(req.companyId!, productId))) return res.status(404).json({ error: "Product not found" });
  if (!supplierId || !(await companySupplier(req.companyId!, supplierId))) return res.status(400).json({ error: "Choose a valid supplier" });
  if (!Number.isFinite(unitCost) || unitCost < 0) return res.status(400).json({ error: "Valid unit cost is required" });
  const supplierAccountId = positiveId(req.body?.supplierAccountId);
  if (supplierAccountId) {
    const [account] = await db.select().from(supplierAccountsTable).where(and(eq(supplierAccountsTable.id, supplierAccountId), eq(supplierAccountsTable.companyId, req.companyId!), eq(supplierAccountsTable.supplierId, supplierId))).limit(1);
    if (!account) return res.status(400).json({ error: "Supplier account does not belong to this supplier" });
  }
  const [row] = await db.insert(supplierPricesTable).values({
    companyId: req.companyId!, productId, supplierId, supplierAccountId,
    supplierSku: optionalText(req.body?.supplierSku), supplierDescription: optionalText(req.body?.supplierDescription),
    unitCost: String(unitCost), quantityBreak: String(Number(req.body?.quantityBreak ?? 1) || 1),
    availability: optionalText(req.body?.availability), leadTimeDays: Number.isFinite(Number(req.body?.leadTimeDays)) ? Number(req.body.leadTimeDays) : null,
    source: requiredText(req.body?.source) || "manual",
  }).returning();
  res.status(201).json({ ...row, unitCost: money(row.unitCost), quantityBreak: money(row.quantityBreak) });
});


router.post("/procurement/prices/import", requirePermission("purchasing.manage"), async (req, res) => {
  const records = Array.isArray(req.body?.records) ? req.body.records : [];
  if (!records.length || records.length > 5000) return res.status(400).json({ error: "Provide between 1 and 5000 price records" });
  const supplierIds = [...new Set(records.map((r: any) => positiveId(r.supplierId)).filter(Boolean))] as number[];
  const productIds = [...new Set(records.map((r: any) => positiveId(r.productId)).filter(Boolean))] as number[];
  const [validSuppliers, validProducts] = await Promise.all([
    supplierIds.length ? db.select({ id: suppliersTable.id }).from(suppliersTable).where(and(eq(suppliersTable.companyId, req.companyId!), inArray(suppliersTable.id, supplierIds))) : [],
    productIds.length ? db.select({ id: procurementProductsTable.id }).from(procurementProductsTable).where(and(eq(procurementProductsTable.companyId, req.companyId!), inArray(procurementProductsTable.id, productIds))) : [],
  ]);
  const supplierSet = new Set(validSuppliers.map((r) => r.id));
  const productSet = new Set(validProducts.map((r) => r.id));
  const values = records.map((record: any) => {
    const productId = positiveId(record.productId);
    const supplierId = positiveId(record.supplierId);
    const unitCost = Number(record.unitCost);
    if (!productId || !productSet.has(productId) || !supplierId || !supplierSet.has(supplierId) || !Number.isFinite(unitCost) || unitCost < 0) return null;
    return {
      companyId: req.companyId!, productId, supplierId, supplierAccountId: positiveId(record.supplierAccountId),
      supplierSku: optionalText(record.supplierSku), supplierDescription: optionalText(record.supplierDescription),
      unitCost: String(unitCost), quantityBreak: String(Number(record.quantityBreak ?? 1) || 1),
      availability: optionalText(record.availability), leadTimeDays: Number.isFinite(Number(record.leadTimeDays)) ? Number(record.leadTimeDays) : null,
      source: requiredText(record.source) || "import",
    };
  }).filter(Boolean) as any[];
  if (!values.length) return res.status(400).json({ error: "No valid company-scoped price records were supplied" });
  const inserted = await db.insert(supplierPricesTable).values(values).returning({ id: supplierPricesTable.id });
  res.status(201).json({ imported: inserted.length, rejected: records.length - inserted.length });
});

router.post("/procurement/compare", requirePermission("purchasing.read"), async (req, res) => {
  const requested = (Array.isArray(req.body?.items) ? req.body.items : []).map((item: any) => ({ productId: positiveId(item.productId), quantity: Number(item.quantity) }))
    .filter((item: any) => item.productId && Number.isFinite(item.quantity) && item.quantity > 0) as Array<{ productId: number; quantity: number }>;
  if (!requested.length) return res.status(400).json({ error: "Add at least one product and quantity" });
  const productIds = [...new Set(requested.map((item) => item.productId))];
  const products = await db.select({ id: procurementProductsTable.id, name: procurementProductsTable.name, unit: procurementProductsTable.unit })
    .from(procurementProductsTable).where(and(eq(procurementProductsTable.companyId, req.companyId!), inArray(procurementProductsTable.id, productIds)));
  const productSet = new Set(products.map((p) => p.id));
  if (productSet.size !== productIds.length) return res.status(400).json({ error: "One or more products do not belong to this CREWON company" });

  const priceRows = await db.select({
    id: supplierPricesTable.id, productId: supplierPricesTable.productId, supplierId: supplierPricesTable.supplierId,
    supplierName: suppliersTable.name, supplierSku: supplierPricesTable.supplierSku, unitCost: supplierPricesTable.unitCost,
    quantityBreak: supplierPricesTable.quantityBreak, availability: supplierPricesTable.availability,
    leadTimeDays: supplierPricesTable.leadTimeDays, source: supplierPricesTable.source, validFrom: supplierPricesTable.validFrom,
  }).from(supplierPricesTable).innerJoin(suppliersTable, eq(suppliersTable.id, supplierPricesTable.supplierId))
    .where(and(eq(supplierPricesTable.companyId, req.companyId!), inArray(supplierPricesTable.productId, productIds)))
    .orderBy(desc(supplierPricesTable.validFrom));

  const lines = requested.map((request) => {
    const product = products.find((p) => p.id === request.productId)!;
    // Price history is newest-first. Keep the newest applicable quantity break per supplier.
    const latestBySupplier = new Map<number, typeof priceRows[number]>();
    for (const price of priceRows) {
      if (price.productId !== request.productId || latestBySupplier.has(price.supplierId)) continue;
      if (money(price.quantityBreak) <= request.quantity) latestBySupplier.set(price.supplierId, price);
    }
    const alternatives = [...latestBySupplier.values()].map((price) => ({
      supplierId: price.supplierId, supplierName: price.supplierName, supplierSku: price.supplierSku,
      unitCost: money(price.unitCost), lineTotal: Math.round(money(price.unitCost) * request.quantity * 100) / 100,
      availability: price.availability, leadTimeDays: price.leadTimeDays, source: price.source, validFrom: price.validFrom,
    })).sort((a, b) => a.lineTotal - b.lineTotal);
    return { productId: product.id, productName: product.name, unit: product.unit, quantity: request.quantity, alternatives, best: alternatives[0] ?? null };
  });
  const splitBasketTotal = Math.round(lines.reduce((sum, line) => sum + (line.best?.lineTotal ?? 0), 0) * 100) / 100;
  const supplierIdsWithPrices = [...new Set(lines.flatMap((line) => line.alternatives.map((a) => a.supplierId)))];
  const singleSupplierOptions = supplierIdsWithPrices.map((supplierId) => {
    const chosen = lines.map((line) => line.alternatives.find((a) => a.supplierId === supplierId)).filter(Boolean) as Array<{ supplierName: string; lineTotal: number }>;
    if (chosen.length !== lines.length) return null;
    return { supplierId, supplierName: chosen[0].supplierName, total: Math.round(chosen.reduce((sum, item) => sum + item.lineTotal, 0) * 100) / 100 };
  }).filter(Boolean).sort((a: any, b: any) => a.total - b.total);
  res.json({ lines, splitBasketTotal, singleSupplierOptions, missingProducts: lines.filter((line) => !line.best).map((line) => line.productId) });
});

// ── RFQs ────────────────────────────────────────────────────────────────────
router.get("/procurement/rfqs", requirePermission("purchasing.read"), async (req, res) => {
  const rows = await db.select().from(rfqsTable).where(eq(rfqsTable.companyId, req.companyId!)).orderBy(desc(rfqsTable.createdAt));
  const ids = rows.map((r) => r.id);
  const [items, responses] = ids.length ? await Promise.all([
    db.select().from(rfqItemsTable).where(and(eq(rfqItemsTable.companyId, req.companyId!), inArray(rfqItemsTable.rfqId, ids))),
    db.select({ id: rfqResponsesTable.id, rfqId: rfqResponsesTable.rfqId, supplierId: rfqResponsesTable.supplierId, supplierName: suppliersTable.name, status: rfqResponsesTable.status, reference: rfqResponsesTable.reference, subtotal: rfqResponsesTable.subtotal, vat: rfqResponsesTable.vat, total: rfqResponsesTable.total, receivedAt: rfqResponsesTable.receivedAt })
      .from(rfqResponsesTable).innerJoin(suppliersTable, eq(suppliersTable.id, rfqResponsesTable.supplierId))
      .where(and(eq(rfqResponsesTable.companyId, req.companyId!), inArray(rfqResponsesTable.rfqId, ids))),
  ]) : [[], []];
  res.json(rows.map((row) => ({
    ...row,
    items: items.filter((item) => item.rfqId === row.id).map((item) => ({ ...item, quantity: money(item.quantity) })),
    responses: responses.filter((response) => response.rfqId === row.id).map((response) => ({ ...response, subtotal: money(response.subtotal), vat: money(response.vat), total: money(response.total) })),
  })));
});

router.post("/procurement/rfqs", requirePermission("purchasing.manage"), async (req, res) => {
  const title = requiredText(req.body?.title);
  const items = Array.isArray(req.body?.items) ? req.body.items : [];
  if (!title) return res.status(400).json({ error: "RFQ title is required" });
  if (!items.length) return res.status(400).json({ error: "Add at least one RFQ item" });
  const [rfq] = await db.insert(rfqsTable).values({
    companyId: req.companyId!, title, status: requiredText(req.body?.status) || "draft",
    jobId: positiveId(req.body?.jobId), quoteId: positiveId(req.body?.quoteId), dueAt: optionalDate(req.body?.dueAt),
    notes: optionalText(req.body?.notes), createdByUserId: req.userId ?? null,
  }).returning();
  const values = items.map((item: any) => ({
    companyId: req.companyId!, rfqId: rfq.id, productId: positiveId(item.productId),
    description: requiredText(item.description), quantity: String(Number(item.quantity) || 0), unit: requiredText(item.unit) || "each",
  })).filter((item: any) => item.description && Number(item.quantity) > 0);
  if (!values.length) {
    await db.delete(rfqsTable).where(eq(rfqsTable.id, rfq.id));
    return res.status(400).json({ error: "RFQ items need a description and quantity" });
  }
  const createdItems = await db.insert(rfqItemsTable).values(values).returning();
  res.status(201).json({ ...rfq, items: createdItems.map((item) => ({ ...item, quantity: money(item.quantity) })), responses: [] });
});

router.post("/procurement/rfqs/:id/responses", requirePermission("purchasing.manage"), async (req, res) => {
  const rfqId = positiveId(req.params.id);
  const supplierId = positiveId(req.body?.supplierId);
  if (!rfqId) return res.status(400).json({ error: "Invalid RFQ" });
  const [rfq] = await db.select().from(rfqsTable).where(and(eq(rfqsTable.id, rfqId), eq(rfqsTable.companyId, req.companyId!))).limit(1);
  if (!rfq) return res.status(404).json({ error: "RFQ not found" });
  if (!supplierId || !(await companySupplier(req.companyId!, supplierId))) return res.status(400).json({ error: "Choose a valid supplier" });
  const [row] = await db.insert(rfqResponsesTable).values({
    companyId: req.companyId!, rfqId, supplierId, supplierAccountId: positiveId(req.body?.supplierAccountId),
    status: requiredText(req.body?.status) || "received", reference: optionalText(req.body?.reference),
    subtotal: req.body?.subtotal == null ? null : String(Number(req.body.subtotal) || 0),
    vat: req.body?.vat == null ? null : String(Number(req.body.vat) || 0), total: req.body?.total == null ? null : String(Number(req.body.total) || 0),
    notes: optionalText(req.body?.notes),
  }).returning();
  await db.update(rfqsTable).set({ status: "responses_received" }).where(and(eq(rfqsTable.id, rfqId), eq(rfqsTable.companyId, req.companyId!)));
  res.status(201).json({ ...row, subtotal: money(row.subtotal), vat: money(row.vat), total: money(row.total) });
});

// ── Purchase orders ─────────────────────────────────────────────────────────
router.get("/procurement/purchase-orders", requirePermission("purchasing.read"), async (req, res) => {
  const rows = await db.select({
    id: purchaseOrdersTable.id, poNumber: purchaseOrdersTable.poNumber, supplierId: purchaseOrdersTable.supplierId,
    supplierName: suppliersTable.name, supplierAccountId: purchaseOrdersTable.supplierAccountId, jobId: purchaseOrdersTable.jobId,
    status: purchaseOrdersTable.status, deliveryAddress: purchaseOrdersTable.deliveryAddress, requiredBy: purchaseOrdersTable.requiredBy,
    subtotal: purchaseOrdersTable.subtotal, vat: purchaseOrdersTable.vat, total: purchaseOrdersTable.total,
    notes: purchaseOrdersTable.notes, approvedAt: purchaseOrdersTable.approvedAt, orderedAt: purchaseOrdersTable.orderedAt,
    createdAt: purchaseOrdersTable.createdAt, updatedAt: purchaseOrdersTable.updatedAt,
  }).from(purchaseOrdersTable).innerJoin(suppliersTable, eq(suppliersTable.id, purchaseOrdersTable.supplierId))
    .where(eq(purchaseOrdersTable.companyId, req.companyId!)).orderBy(desc(purchaseOrdersTable.createdAt));
  const ids = rows.map((r) => r.id);
  const items = ids.length ? await db.select().from(purchaseOrderItemsTable).where(and(eq(purchaseOrderItemsTable.companyId, req.companyId!), inArray(purchaseOrderItemsTable.purchaseOrderId, ids))) : [];
  res.json(rows.map((row) => ({ ...row, subtotal: money(row.subtotal), vat: money(row.vat), total: money(row.total), items: items.filter((item) => item.purchaseOrderId === row.id).map((item) => ({ ...item, quantity: money(item.quantity), unitCost: money(item.unitCost), lineTotal: money(item.lineTotal) })) })));
});

router.post("/procurement/purchase-orders", requirePermission("purchasing.manage"), async (req, res) => {
  const supplierId = positiveId(req.body?.supplierId);
  const items = Array.isArray(req.body?.items) ? req.body.items : [];
  if (!supplierId || !(await companySupplier(req.companyId!, supplierId))) return res.status(400).json({ error: "Choose a valid supplier" });
  if (!items.length) return res.status(400).json({ error: "Add at least one purchase-order item" });
  const cleanItems = items.map((item: any) => {
    const quantity = Number(item.quantity);
    const unitCost = Number(item.unitCost);
    return { productId: positiveId(item.productId), description: requiredText(item.description), supplierSku: optionalText(item.supplierSku), quantity, unit: requiredText(item.unit) || "each", unitCost, lineTotal: Math.round(quantity * unitCost * 100) / 100 };
  }).filter((item: any) => item.description && Number.isFinite(item.quantity) && item.quantity > 0 && Number.isFinite(item.unitCost) && item.unitCost >= 0);
  if (!cleanItems.length) return res.status(400).json({ error: "Purchase-order items need description, quantity and cost" });

  const subtotal = Math.round(cleanItems.reduce((sum: number, item: any) => sum + item.lineTotal, 0) * 100) / 100;
  const vatRate = Number.isFinite(Number(req.body?.vatRate)) ? Number(req.body.vatRate) : 20;
  const vat = Math.round(subtotal * (vatRate / 100) * 100) / 100;
  const total = subtotal + vat;
  const next = await db.select({ maxId: sql<number>`coalesce(max(${purchaseOrdersTable.id}), 0)::int` }).from(purchaseOrdersTable).where(eq(purchaseOrdersTable.companyId, req.companyId!));
  const poNumber = requiredText(req.body?.poNumber) || `PO-${String((next[0]?.maxId ?? 0) + 1).padStart(5, "0")}`;
  const requestedStatus = requiredText(req.body?.status) || "draft";

  const [po] = await db.insert(purchaseOrdersTable).values({
    companyId: req.companyId!, poNumber, supplierId, supplierAccountId: positiveId(req.body?.supplierAccountId),
    jobId: positiveId(req.body?.jobId), quoteId: positiveId(req.body?.quoteId), status: requestedStatus,
    deliveryAddress: optionalText(req.body?.deliveryAddress), requiredBy: optionalDate(req.body?.requiredBy),
    subtotal: String(subtotal), vat: String(vat), total: String(total), notes: optionalText(req.body?.notes), createdByUserId: req.userId ?? null,
  }).returning();
  const createdItems = await db.insert(purchaseOrderItemsTable).values(cleanItems.map((item: any) => ({
    companyId: req.companyId!, purchaseOrderId: po.id, productId: item.productId, description: item.description, supplierSku: item.supplierSku,
    quantity: String(item.quantity), unit: item.unit, unitCost: String(item.unitCost), lineTotal: String(item.lineTotal),
  }))).returning();
  res.status(201).json({ ...po, subtotal, vat, total, items: createdItems.map((item) => ({ ...item, quantity: money(item.quantity), unitCost: money(item.unitCost), lineTotal: money(item.lineTotal) })) });
});

router.patch("/procurement/purchase-orders/:id/status", requirePermission("purchasing.manage"), async (req, res) => {
  const id = positiveId(req.params.id);
  const status = requiredText(req.body?.status);
  const allowed = ["draft", "approval_required", "approved", "ordered", "part_received", "received", "cancelled"];
  if (!id || !allowed.includes(status)) return res.status(400).json({ error: "Invalid purchase-order status" });
  const changes: Record<string, unknown> = { status };
  if (status === "approved") { changes.approvedAt = new Date(); changes.approvedByUserId = req.userId ?? null; }
  if (status === "ordered") changes.orderedAt = new Date();
  const [row] = await db.update(purchaseOrdersTable).set(changes)
    .where(and(eq(purchaseOrdersTable.id, id), eq(purchaseOrdersTable.companyId, req.companyId!))).returning();
  if (!row) return res.status(404).json({ error: "Purchase order not found" });
  res.json({ ...row, subtotal: money(row.subtotal), vat: money(row.vat), total: money(row.total) });
});

// ── Deliveries ──────────────────────────────────────────────────────────────
router.get("/procurement/deliveries", requirePermission("purchasing.read"), async (req, res) => {
  const rows = await db.select({
    id: deliveriesTable.id, purchaseOrderId: deliveriesTable.purchaseOrderId, supplierId: deliveriesTable.supplierId,
    supplierName: suppliersTable.name, jobId: deliveriesTable.jobId, status: deliveriesTable.status, reference: deliveriesTable.reference,
    scheduledAt: deliveriesTable.scheduledAt, receivedAt: deliveriesTable.receivedAt, deliveryAddress: deliveriesTable.deliveryAddress,
    notes: deliveriesTable.notes, createdAt: deliveriesTable.createdAt,
  }).from(deliveriesTable).leftJoin(suppliersTable, eq(suppliersTable.id, deliveriesTable.supplierId))
    .where(eq(deliveriesTable.companyId, req.companyId!)).orderBy(desc(deliveriesTable.scheduledAt), desc(deliveriesTable.createdAt));
  res.json(rows);
});

router.post("/procurement/deliveries", requirePermission("purchasing.manage"), async (req, res) => {
  const purchaseOrderId = positiveId(req.body?.purchaseOrderId);
  let supplierId = positiveId(req.body?.supplierId);
  let jobId = positiveId(req.body?.jobId);
  if (purchaseOrderId) {
    const [po] = await db.select().from(purchaseOrdersTable).where(and(eq(purchaseOrdersTable.id, purchaseOrderId), eq(purchaseOrdersTable.companyId, req.companyId!))).limit(1);
    if (!po) return res.status(404).json({ error: "Purchase order not found" });
    supplierId = supplierId ?? po.supplierId;
    jobId = jobId ?? po.jobId;
  }
  const [row] = await db.insert(deliveriesTable).values({
    companyId: req.companyId!, purchaseOrderId, supplierId, jobId, status: requiredText(req.body?.status) || "scheduled",
    reference: optionalText(req.body?.reference), scheduledAt: optionalDate(req.body?.scheduledAt), deliveryAddress: optionalText(req.body?.deliveryAddress), notes: optionalText(req.body?.notes),
  }).returning();
  res.status(201).json(row);
});

router.patch("/procurement/deliveries/:id", requirePermission("purchasing.manage"), async (req, res) => {
  const id = positiveId(req.params.id);
  if (!id) return res.status(400).json({ error: "Invalid delivery" });
  const changes: Record<string, unknown> = {};
  if (typeof req.body?.status === "string") { changes.status = req.body.status; if (req.body.status === "received") changes.receivedAt = new Date(); }
  if ("scheduledAt" in (req.body ?? {})) changes.scheduledAt = optionalDate(req.body.scheduledAt);
  if ("reference" in (req.body ?? {})) changes.reference = optionalText(req.body.reference);
  if ("notes" in (req.body ?? {})) changes.notes = optionalText(req.body.notes);
  const [row] = await db.update(deliveriesTable).set(changes)
    .where(and(eq(deliveriesTable.id, id), eq(deliveriesTable.companyId, req.companyId!))).returning();
  if (!row) return res.status(404).json({ error: "Delivery not found" });
  res.json(row);
});


// ── Goods received & supplier invoice control ───────────────────────────────
router.get("/procurement/goods-receipts", requirePermission("purchasing.read"), async (req, res) => {
  const receipts = await db.select().from(goodsReceiptsTable)
    .where(eq(goodsReceiptsTable.companyId, req.companyId!)).orderBy(desc(goodsReceiptsTable.receivedAt));
  const ids = receipts.map((r) => r.id);
  const items = ids.length ? await db.select().from(goodsReceiptItemsTable)
    .where(and(eq(goodsReceiptItemsTable.companyId, req.companyId!), inArray(goodsReceiptItemsTable.goodsReceiptId, ids))) : [];
  res.json(receipts.map((r) => ({
    ...r, items: items.filter((i) => i.goodsReceiptId === r.id).map((i) => ({ ...i, quantityReceived: money(i.quantityReceived) }))
  })));
});

router.post("/procurement/goods-receipts", requirePermission("purchasing.manage"), async (req, res) => {
  const purchaseOrderId = positiveId(req.body?.purchaseOrderId);
  const deliveryId = positiveId(req.body?.deliveryId);
  const incoming = Array.isArray(req.body?.items) ? req.body.items : [];
  if (!purchaseOrderId || !incoming.length) return res.status(400).json({ error: "Purchase order and received items are required" });

  const [po] = await db.select().from(purchaseOrdersTable)
    .where(and(eq(purchaseOrdersTable.id, purchaseOrderId), eq(purchaseOrdersTable.companyId, req.companyId!))).limit(1);
  if (!po) return res.status(404).json({ error: "Purchase order not found" });

  const poItems = await db.select().from(purchaseOrderItemsTable)
    .where(and(eq(purchaseOrderItemsTable.companyId, req.companyId!), eq(purchaseOrderItemsTable.purchaseOrderId, purchaseOrderId)));
  const poMap = new Map(poItems.map((i) => [i.id, i]));
  const existing = poItems.length ? await db.select({
    purchaseOrderItemId: goodsReceiptItemsTable.purchaseOrderItemId,
    received: sql<string>`coalesce(sum(case when ${goodsReceiptItemsTable.condition} = 'accepted' then ${goodsReceiptItemsTable.quantityReceived} else 0 end),0)`
  }).from(goodsReceiptItemsTable)
    .innerJoin(goodsReceiptsTable, eq(goodsReceiptsTable.id, goodsReceiptItemsTable.goodsReceiptId))
    .where(and(eq(goodsReceiptItemsTable.companyId, req.companyId!), eq(goodsReceiptsTable.purchaseOrderId, purchaseOrderId)))
    .groupBy(goodsReceiptItemsTable.purchaseOrderItemId) : [];
  const receivedMap = new Map(existing.map((r) => [r.purchaseOrderItemId, money(r.received)]));

  const clean = incoming.map((item: any) => {
    const purchaseOrderItemId = positiveId(item.purchaseOrderItemId);
    const quantityReceived = Number(item.quantityReceived);
    const condition = requiredText(item.condition) || "accepted";
    return { purchaseOrderItemId, quantityReceived, condition, notes: optionalText(item.notes) };
  }).filter((i: any) => i.purchaseOrderItemId && Number.isFinite(i.quantityReceived) && i.quantityReceived > 0);

  if (!clean.length) return res.status(400).json({ error: "Add at least one valid received quantity" });
  for (const item of clean) {
    const poItem = poMap.get(item.purchaseOrderItemId!);
    if (!poItem) return res.status(400).json({ error: "A received line does not belong to this purchase order" });
    if (!["accepted", "damaged", "rejected"].includes(item.condition)) return res.status(400).json({ error: "Invalid goods condition" });
    if (item.condition === "accepted") {
      const cumulative = money(receivedMap.get(poItem.id)) + item.quantityReceived;
      if (cumulative > money(poItem.quantity) + 0.001) {
        return res.status(409).json({ error: `${poItem.description}: received quantity would exceed ordered quantity` });
      }
    }
  }

  if (deliveryId) {
    const [delivery] = await db.select().from(deliveriesTable).where(and(
      eq(deliveriesTable.id, deliveryId), eq(deliveriesTable.companyId, req.companyId!),
      eq(deliveriesTable.purchaseOrderId, purchaseOrderId)
    )).limit(1);
    if (!delivery) return res.status(400).json({ error: "Delivery does not belong to this purchase order" });
  }

  const [receipt] = await db.insert(goodsReceiptsTable).values({
    companyId: req.companyId!, purchaseOrderId, deliveryId, reference: optionalText(req.body?.reference),
    receivedAt: optionalDate(req.body?.receivedAt) ?? new Date(), receivedByUserId: req.userId ?? null,
    notes: optionalText(req.body?.notes),
  }).returning();

  const createdItems = await db.insert(goodsReceiptItemsTable).values(clean.map((item) => ({
    companyId: req.companyId!, goodsReceiptId: receipt.id, purchaseOrderItemId: item.purchaseOrderItemId!,
    quantityReceived: String(item.quantityReceived), condition: item.condition, notes: item.notes,
  }))).returning();

  const totals = await db.select({
    purchaseOrderItemId: goodsReceiptItemsTable.purchaseOrderItemId,
    received: sql<string>`coalesce(sum(case when ${goodsReceiptItemsTable.condition} = 'accepted' then ${goodsReceiptItemsTable.quantityReceived} else 0 end),0)`
  }).from(goodsReceiptItemsTable)
    .innerJoin(goodsReceiptsTable, eq(goodsReceiptsTable.id, goodsReceiptItemsTable.goodsReceiptId))
    .where(and(eq(goodsReceiptItemsTable.companyId, req.companyId!), eq(goodsReceiptsTable.purchaseOrderId, purchaseOrderId)))
    .groupBy(goodsReceiptItemsTable.purchaseOrderItemId);
  const totalsMap = new Map(totals.map((r) => [r.purchaseOrderItemId, money(r.received)]));
  const physical = poItems.filter((i) => i.unit !== "delivery");
  const allReceived = physical.length > 0 && physical.every((i) => money(totalsMap.get(i.id)) + 0.001 >= money(i.quantity));
  const anyReceived = totals.some((r) => money(r.received) > 0);
  await db.update(purchaseOrdersTable).set({ status: allReceived ? "received" : anyReceived ? "part_received" : po.status })
    .where(and(eq(purchaseOrdersTable.id, purchaseOrderId), eq(purchaseOrdersTable.companyId, req.companyId!)));
  if (deliveryId && allReceived) await db.update(deliveriesTable).set({ status: "received", receivedAt: receipt.receivedAt })
    .where(and(eq(deliveriesTable.id, deliveryId), eq(deliveriesTable.companyId, req.companyId!)));

  await db.insert(auditEventsTable).values({
    companyId: req.companyId!, userId: req.userId ?? null, actorType: "user",
    action: "procurement.goods_received", entityType: "goods_receipt", entityId: String(receipt.id),
    metadata: { purchaseOrderId, lines: clean.length, poStatus: allReceived ? "received" : "part_received" },
  });
  res.status(201).json({ ...receipt, items: createdItems.map((i) => ({ ...i, quantityReceived: money(i.quantityReceived) })) });
});

router.get("/procurement/supplier-invoices", requirePermission("purchasing.read"), async (req, res) => {
  const rows = await db.select({
    id: supplierInvoicesTable.id, supplierId: supplierInvoicesTable.supplierId, supplierName: suppliersTable.name,
    supplierAccountId: supplierInvoicesTable.supplierAccountId, purchaseOrderId: supplierInvoicesTable.purchaseOrderId,
    invoiceNumber: supplierInvoicesTable.invoiceNumber, invoiceDate: supplierInvoicesTable.invoiceDate, dueDate: supplierInvoicesTable.dueDate,
    subtotal: supplierInvoicesTable.subtotal, vat: supplierInvoicesTable.vat, total: supplierInvoicesTable.total,
    status: supplierInvoicesTable.status, matchSummary: supplierInvoicesTable.matchSummary, notes: supplierInvoicesTable.notes,
    createdAt: supplierInvoicesTable.createdAt,
  }).from(supplierInvoicesTable).innerJoin(suppliersTable, eq(suppliersTable.id, supplierInvoicesTable.supplierId))
    .where(eq(supplierInvoicesTable.companyId, req.companyId!)).orderBy(desc(supplierInvoicesTable.invoiceDate), desc(supplierInvoicesTable.id));
  const ids = rows.map((r) => r.id);
  const items = ids.length ? await db.select().from(supplierInvoiceItemsTable)
    .where(and(eq(supplierInvoiceItemsTable.companyId, req.companyId!), inArray(supplierInvoiceItemsTable.supplierInvoiceId, ids))) : [];
  res.json(rows.map((r) => ({
    ...r, subtotal: money(r.subtotal), vat: money(r.vat), total: money(r.total),
    items: items.filter((i) => i.supplierInvoiceId === r.id).map((i) => ({
      ...i, quantity: money(i.quantity), unitCost: money(i.unitCost), lineTotal: money(i.lineTotal)
    }))
  })));
});

router.post("/procurement/supplier-invoices", requirePermission("purchasing.manage"), async (req, res) => {
  const supplierId = positiveId(req.body?.supplierId);
  const purchaseOrderId = positiveId(req.body?.purchaseOrderId);
  const invoiceNumber = requiredText(req.body?.invoiceNumber);
  const invoiceDate = optionalDate(req.body?.invoiceDate) ?? new Date();
  if (!supplierId || !invoiceNumber) return res.status(400).json({ error: "Supplier and invoice number are required" });
  if (!(await companySupplier(req.companyId!, supplierId))) return res.status(404).json({ error: "Supplier not found" });

  let poItems: any[] = [];
  if (purchaseOrderId) {
    const [po] = await db.select().from(purchaseOrdersTable).where(and(
      eq(purchaseOrdersTable.id, purchaseOrderId), eq(purchaseOrdersTable.companyId, req.companyId!)
    )).limit(1);
    if (!po || po.supplierId !== supplierId) return res.status(400).json({ error: "Purchase order does not belong to this supplier" });
    poItems = await db.select().from(purchaseOrderItemsTable).where(and(
      eq(purchaseOrderItemsTable.companyId, req.companyId!), eq(purchaseOrderItemsTable.purchaseOrderId, purchaseOrderId)
    ));
  }

  const rawItems = Array.isArray(req.body?.items) && req.body.items.length ? req.body.items : poItems.map((i) => ({
    purchaseOrderItemId: i.id, description: i.description, quantity: money(i.quantity),
    unitCost: money(i.unitCost), lineTotal: money(i.lineTotal)
  }));
  const items = rawItems.map((item: any) => {
    const quantity = Number(item.quantity), unitCost = Number(item.unitCost);
    return {
      purchaseOrderItemId: positiveId(item.purchaseOrderItemId), description: requiredText(item.description),
      quantity, unitCost, lineTotal: Number.isFinite(Number(item.lineTotal)) ? Number(item.lineTotal) : Math.round(quantity * unitCost * 100) / 100
    };
  }).filter((i: any) => i.description && Number.isFinite(i.quantity) && i.quantity > 0 && Number.isFinite(i.unitCost) && i.unitCost >= 0);

  if (!items.length) return res.status(400).json({ error: "Supplier invoice needs at least one line" });
  if (purchaseOrderId) {
    const poIds = new Set(poItems.map((i) => i.id));
    if (items.some((i: any) => i.purchaseOrderItemId && !poIds.has(i.purchaseOrderItemId))) return res.status(400).json({ error: "An invoice line is linked to the wrong purchase order" });
  }

  const computedSubtotal = Math.round(items.reduce((sum: number, i: any) => sum + i.lineTotal, 0) * 100) / 100;
  const subtotal = Number.isFinite(Number(req.body?.subtotal)) ? Number(req.body.subtotal) : computedSubtotal;
  const vat = Number.isFinite(Number(req.body?.vat)) ? Number(req.body.vat) : Math.round(subtotal * 0.2 * 100) / 100;
  const total = Number.isFinite(Number(req.body?.total)) ? Number(req.body.total) : Math.round((subtotal + vat) * 100) / 100;

  try {
    const [invoice] = await db.insert(supplierInvoicesTable).values({
      companyId: req.companyId!, supplierId, supplierAccountId: positiveId(req.body?.supplierAccountId),
      purchaseOrderId, invoiceNumber, invoiceDate, dueDate: optionalDate(req.body?.dueDate),
      subtotal: String(subtotal), vat: String(vat), total: String(total), status: "received",
      notes: optionalText(req.body?.notes), createdByUserId: req.userId ?? null,
    }).returning();
    const createdItems = await db.insert(supplierInvoiceItemsTable).values(items.map((item: any) => ({
      companyId: req.companyId!, supplierInvoiceId: invoice.id, purchaseOrderItemId: item.purchaseOrderItemId,
      description: item.description, quantity: String(item.quantity), unitCost: String(item.unitCost), lineTotal: String(item.lineTotal),
    }))).returning();
    res.status(201).json({ ...invoice, subtotal, vat, total, items: createdItems });
  } catch (error: any) {
    if (String(error?.message ?? "").toLowerCase().includes("unique")) return res.status(409).json({ error: "That supplier invoice number is already recorded" });
    throw error;
  }
});

router.post("/procurement/supplier-invoices/:id/match", requirePermission("purchasing.manage"), async (req, res) => {
  const id = positiveId(req.params.id);
  if (!id) return res.status(400).json({ error: "Invalid supplier invoice" });
  const [invoice] = await db.select().from(supplierInvoicesTable).where(and(
    eq(supplierInvoicesTable.id, id), eq(supplierInvoicesTable.companyId, req.companyId!)
  )).limit(1);
  if (!invoice) return res.status(404).json({ error: "Supplier invoice not found" });
  if (!invoice.purchaseOrderId) return res.status(409).json({ error: "Link this invoice to a purchase order before matching" });

  const poItems = await db.select().from(purchaseOrderItemsTable).where(and(
    eq(purchaseOrderItemsTable.companyId, req.companyId!), eq(purchaseOrderItemsTable.purchaseOrderId, invoice.purchaseOrderId)
  ));
  const invoiceItems = await db.select().from(supplierInvoiceItemsTable).where(and(
    eq(supplierInvoiceItemsTable.companyId, req.companyId!), eq(supplierInvoiceItemsTable.supplierInvoiceId, id)
  ));
  const received = await db.select({
    purchaseOrderItemId: goodsReceiptItemsTable.purchaseOrderItemId,
    received: sql<string>`coalesce(sum(case when ${goodsReceiptItemsTable.condition} = 'accepted' then ${goodsReceiptItemsTable.quantityReceived} else 0 end),0)`
  }).from(goodsReceiptItemsTable)
    .innerJoin(goodsReceiptsTable, eq(goodsReceiptsTable.id, goodsReceiptItemsTable.goodsReceiptId))
    .where(and(eq(goodsReceiptItemsTable.companyId, req.companyId!), eq(goodsReceiptsTable.purchaseOrderId, invoice.purchaseOrderId)))
    .groupBy(goodsReceiptItemsTable.purchaseOrderItemId);

  const receivedMap = new Map(received.map((r) => [r.purchaseOrderItemId, money(r.received)]));
  const invByPoItem = new Map<number, typeof invoiceItems>();
  for (const item of invoiceItems) {
    if (!item.purchaseOrderItemId) continue;
    const arr = invByPoItem.get(item.purchaseOrderItemId) ?? []; arr.push(item); invByPoItem.set(item.purchaseOrderItemId, arr);
  }

  const lineResults = poItems.map((poItem) => {
    const invoices = invByPoItem.get(poItem.id) ?? [];
    const invoicedQty = invoices.reduce((s, i) => s + money(i.quantity), 0);
    const invoicedAmount = invoices.reduce((s, i) => s + money(i.lineTotal), 0);
    const expectedQty = money(poItem.quantity);
    const receivedQty = poItem.unit === "delivery" ? expectedQty : money(receivedMap.get(poItem.id));
    const expectedAmount = money(poItem.lineTotal);
    const expectedUnit = money(poItem.unitCost);
    const effectiveInvoiceUnit = invoicedQty > 0 ? invoicedAmount / invoicedQty : 0;
    const issues: string[] = [];
    if (!invoices.length) issues.push("No invoice line linked");
    if (Math.abs(invoicedQty - expectedQty) > 0.001) issues.push(`Invoice quantity ${invoicedQty} vs ordered ${expectedQty}`);
    if (poItem.unit !== "delivery" && receivedQty + 0.001 < invoicedQty) issues.push(`Invoiced ${invoicedQty} but only ${receivedQty} received`);
    if (invoices.length && Math.abs(effectiveInvoiceUnit - expectedUnit) > 0.01) issues.push(`Unit cost ${effectiveInvoiceUnit.toFixed(2)} vs PO ${expectedUnit.toFixed(2)}`);
    if (invoices.length && Math.abs(invoicedAmount - expectedAmount) > 0.02) issues.push(`Line amount variance £${(invoicedAmount - expectedAmount).toFixed(2)}`);
    return {
      purchaseOrderItemId: poItem.id, description: poItem.description, orderedQty: expectedQty, receivedQty,
      invoicedQty, poUnitCost: expectedUnit, invoiceUnitCost: Math.round(effectiveInvoiceUnit * 10000) / 10000,
      expectedAmount, invoicedAmount: Math.round(invoicedAmount * 100) / 100, issues,
    };
  });
  const unlinkedInvoiceLines = invoiceItems.filter((i) => !i.purchaseOrderItemId).length;
  const issues = lineResults.flatMap((l) => l.issues.map((issue) => `${l.description}: ${issue}`));
  if (unlinkedInvoiceLines) issues.push(`${unlinkedInvoiceLines} invoice line(s) are not linked to a PO line`);

  const [po] = await db.select().from(purchaseOrdersTable).where(and(
    eq(purchaseOrdersTable.id, invoice.purchaseOrderId), eq(purchaseOrdersTable.companyId, req.companyId!)
  )).limit(1);
  const poTotal = money(po?.total);
  if (Math.abs(money(invoice.total) - poTotal) > 0.02) issues.push(`Invoice total £${money(invoice.total).toFixed(2)} vs PO total £${poTotal.toFixed(2)}`);

  const status = issues.length ? "variance" : "matched";
  const summary = {
    status, purchaseOrderId: invoice.purchaseOrderId, checkedAt: new Date().toISOString(),
    invoiceTotal: money(invoice.total), poTotal, issueCount: issues.length, issues, lines: lineResults,
  };
  const [updated] = await db.update(supplierInvoicesTable).set({ status, matchSummary: summary })
    .where(and(eq(supplierInvoicesTable.id, id), eq(supplierInvoicesTable.companyId, req.companyId!))).returning();

  await db.insert(auditEventsTable).values({
    companyId: req.companyId!, userId: req.userId ?? null, actorType: "system", actorLabel: "CREWON Procurement",
    action: "procurement.invoice.three_way_match", entityType: "supplier_invoice", entityId: String(id),
    metadata: { status, issueCount: issues.length, purchaseOrderId: invoice.purchaseOrderId },
  });
  res.json({ ...updated, subtotal: money(updated.subtotal), vat: money(updated.vat), total: money(updated.total), matchSummary: summary });
});



// ── CREWON Authority ────────────────────────────────────────────────────────
router.get("/procurement/authority", requirePermission("purchasing.read"), async (req, res) => {
  const [existing] = await db.select().from(procurementAuthorityTable)
    .where(eq(procurementAuthorityTable.companyId, req.companyId!)).limit(1);
  res.json(existing ? {
    ...existing,
    autoApprovePurchaseLimit: money(existing.autoApprovePurchaseLimit),
  } : {
    companyId: req.companyId!, mode: "assist", autoApprovePurchaseLimit: 0,
    preferredSuppliersOnly: false, requireKnownPriceSource: true,
  });
});

router.put("/procurement/authority", requirePermission("purchasing.manage"), async (req, res) => {
  const mode = requiredText(req.body?.mode) || "assist";
  if (!["observe", "assist", "operate"].includes(mode)) return res.status(400).json({ error: "Authority mode must be observe, assist or operate" });
  const limit = Math.max(0, Number(req.body?.autoApprovePurchaseLimit) || 0);
  const values = {
    companyId: req.companyId!, mode, autoApprovePurchaseLimit: String(limit),
    preferredSuppliersOnly: Boolean(req.body?.preferredSuppliersOnly),
    requireKnownPriceSource: req.body?.requireKnownPriceSource !== false,
  };
  const [existing] = await db.select().from(procurementAuthorityTable).where(eq(procurementAuthorityTable.companyId, req.companyId!)).limit(1);
  const [row] = existing
    ? await db.update(procurementAuthorityTable).set(values).where(eq(procurementAuthorityTable.id, existing.id)).returning()
    : await db.insert(procurementAuthorityTable).values(values).returning();
  await db.insert(auditEventsTable).values({
    companyId: req.companyId!, userId: req.userId ?? null, actorType: "user",
    action: "procurement.authority.updated", entityType: "procurement_authority", entityId: String(row.id),
    metadata: { mode, autoApprovePurchaseLimit: limit, preferredSuppliersOnly: values.preferredSuppliersOnly },
  });
  res.json({ ...row, autoApprovePurchaseLimit: money(row.autoApprovePurchaseLimit) });
});

// ── Estimate / BOM -> Procurement planning ──────────────────────────────────
router.post("/procurement/quotes/:quoteId/plan", requirePermission("purchasing.manage"), async (req, res) => {
  const quoteId = positiveId(req.params.quoteId);
  if (!quoteId) return res.status(400).json({ error: "Invalid quote" });
  const [quote] = await db.select().from(quotesTable)
    .where(and(eq(quotesTable.id, quoteId), eq(quotesTable.companyId, req.companyId!))).limit(1);
  if (!quote) return res.status(404).json({ error: "Quote not found" });

  const rawMaterials = Array.isArray(quote.materials) ? quote.materials as any[] : [];
  if (!rawMaterials.length) return res.status(400).json({ error: "This estimate has no materials to procure" });

  const products = await db.select().from(procurementProductsTable)
    .where(and(eq(procurementProductsTable.companyId, req.companyId!), eq(procurementProductsTable.status, "active")));

  await db.delete(materialRequirementsTable).where(and(
    eq(materialRequirementsTable.companyId, req.companyId!),
    eq(materialRequirementsTable.quoteId, quoteId),
    eq(materialRequirementsTable.source, "quote"),
  ));

  const requirements = rawMaterials.map((item: any) => {
    const description = requiredText(item.name ?? item.description ?? item.material);
    const quantity = Number(item.quantity ?? item.qty ?? 0);
    const unit = requiredText(item.unit) || "each";
    const explicitProductId = positiveId(item.productId);
    const exact = products.find((p) =>
      normText(p.name) === normText(description) ||
      (p.sku && item.sku && normText(p.sku) === normText(item.sku)) ||
      (p.manufacturerPartNumber && item.manufacturerPartNumber && normText(p.manufacturerPartNumber) === normText(item.manufacturerPartNumber))
    );
    const ranked = products
      .map((p) => ({ p, score: Math.max(
        similarityScore(description, p.name),
        p.description ? similarityScore(description, p.description) * 0.8 : 0,
        p.manufacturerPartNumber ? similarityScore(item.manufacturerPartNumber ?? description, p.manufacturerPartNumber) : 0
      ) }))
      .sort((a, b) => b.score - a.score);
    const fuzzy = ranked[0]?.score >= 0.72 ? ranked[0] : null;
    const product = explicitProductId ? products.find((p) => p.id === explicitProductId) : (exact ?? fuzzy?.p);
    const matchConfidence = explicitProductId || exact ? 1 : (fuzzy?.score ?? 0);
    const waste = Math.max(0, Number(item.wastePercent ?? product?.defaultWastePercent ?? 0) || 0);
    const adjustedQty = Math.round(quantity * (1 + waste / 100) * 1000) / 1000;
    return {
      companyId: req.companyId!, quoteId, jobId: quote.jobId, productId: product?.id ?? null,
      description, quantity: String(adjustedQty), unit, wastePercent: String(waste), source: "quote",
      metadata: {
        originalQuantity: quantity, matchConfidence,
        suggestedProductId: !product && ranked[0]?.score >= 0.35 ? ranked[0].p.id : null,
        suggestedProductName: !product && ranked[0]?.score >= 0.35 ? ranked[0].p.name : null,
        suggestedScore: !product && ranked[0]?.score >= 0.35 ? ranked[0].score : null,
      }
    };
  }).filter((item: any) => item.description && money(item.quantity) > 0);

  if (!requirements.length) return res.status(400).json({ error: "No usable material lines were found in the estimate" });
  const created = await db.insert(materialRequirementsTable).values(requirements).returning();

  const productIds = [...new Set(created.map((r) => r.productId).filter(Boolean))] as number[];
  const priceRows = productIds.length ? await db.select({
    productId: supplierPricesTable.productId, supplierId: supplierPricesTable.supplierId,
    supplierName: suppliersTable.name, preferred: suppliersTable.preferred,
    supplierAccountId: supplierPricesTable.supplierAccountId, supplierSku: supplierPricesTable.supplierSku,
    unitCost: supplierPricesTable.unitCost, quantityBreak: supplierPricesTable.quantityBreak,
    availability: supplierPricesTable.availability, leadTimeDays: supplierPricesTable.leadTimeDays,
    source: supplierPricesTable.source, validFrom: supplierPricesTable.validFrom,
    minimumOrder: supplierAccountsTable.minimumOrder, deliveryCharge: supplierAccountsTable.deliveryCharge,
    freeDeliveryThreshold: supplierAccountsTable.freeDeliveryThreshold, deliveryLeadTimeDays: supplierAccountsTable.deliveryLeadTimeDays,
  }).from(supplierPricesTable)
    .innerJoin(suppliersTable, eq(suppliersTable.id, supplierPricesTable.supplierId))
    .leftJoin(supplierAccountsTable, eq(supplierAccountsTable.id, supplierPricesTable.supplierAccountId))
    .where(and(eq(supplierPricesTable.companyId, req.companyId!), inArray(supplierPricesTable.productId, productIds)))
    .orderBy(desc(supplierPricesTable.validFrom)) : [];

  const [authority] = await db.select().from(procurementAuthorityTable)
    .where(eq(procurementAuthorityTable.companyId, req.companyId!)).limit(1);
  const preferredOnly = authority?.preferredSuppliersOnly ?? false;
  const requireKnown = authority?.requireKnownPriceSource ?? true;

  const lines = created.map((requirement) => {
    const qty = money(requirement.quantity);
    const candidates = new Map<string, typeof priceRows[number]>();
    for (const price of priceRows) {
      if (price.productId !== requirement.productId) continue;
      if (preferredOnly && !price.preferred) continue;
      if (requireKnown && !knownPriceSource(price.source)) continue;
      if (money(price.quantityBreak) > qty) continue;
      const key = `${price.supplierId}:${price.supplierAccountId ?? 0}`;
      if (!candidates.has(key)) candidates.set(key, price);
    }
    const alternatives = [...candidates.values()].map((price) => ({
      supplierId: price.supplierId, supplierName: price.supplierName, preferred: price.preferred,
      supplierAccountId: price.supplierAccountId, supplierSku: price.supplierSku,
      unitCost: money(price.unitCost), lineTotal: Math.round(money(price.unitCost) * qty * 100) / 100,
      availability: price.availability, leadTimeDays: price.leadTimeDays ?? price.deliveryLeadTimeDays,
      source: price.source, minimumOrder: money(price.minimumOrder), deliveryCharge: money(price.deliveryCharge),
      freeDeliveryThreshold: money(price.freeDeliveryThreshold),
    })).sort((a, b) => a.lineTotal - b.lineTotal);
    return {
      requirementId: requirement.id, productId: requirement.productId, description: requirement.description,
      quantity: qty, unit: requirement.unit, metadata: requirement.metadata, alternatives, best: alternatives[0] ?? null
    };
  });

  const missing = lines.filter((line) => !line.best);

  // Delivery/minimum-order-aware basket optimiser. It starts at cheapest line prices, then
  // greedily swaps lines where consolidating suppliers lowers the total landed cost.
  const pricedLines = lines.filter((line) => line.alternatives.length);
  let selection = pricedLines.map((line) => ({ line, choice: line.alternatives[0] }));
  const landedCost = (candidateSelection: typeof selection) => {
    const groups = new Map<string, { subtotal: number; account: any; supplierName: string }>();
    for (const item of candidateSelection) {
      const c = item.choice; const key = `${c.supplierId}:${c.supplierAccountId ?? 0}`;
      const g = groups.get(key) ?? { subtotal: 0, account: c, supplierName: c.supplierName };
      g.subtotal += c.lineTotal; groups.set(key, g);
    }
    let lineSubtotal = 0, deliveryFees = 0; const invalid: string[] = [];
    for (const item of candidateSelection) lineSubtotal += item.choice.lineTotal;
    for (const [, group] of groups) {
      const delivery = accountDeliveryCost(group.account, group.subtotal);
      if (!delivery.valid) invalid.push(`${group.supplierName} minimum order ${delivery.minimumOrder}`);
      deliveryFees += delivery.fee;
    }
    return { total: Math.round((lineSubtotal + deliveryFees) * 100) / 100, lineSubtotal: Math.round(lineSubtotal * 100) / 100, deliveryFees: Math.round(deliveryFees * 100) / 100, valid: invalid.length === 0, invalid };
  };
  for (let pass = 0; pass < 3; pass++) {
    let improved = false;
    for (let i = 0; i < selection.length; i++) {
      for (const alternative of selection[i].line.alternatives.slice(1, 5)) {
        const baseline = landedCost(selection);
        const trial = selection.map((entry, idx) => idx === i ? { ...entry, choice: alternative } : entry);
        const score = landedCost(trial);
        if (score.valid && (!baseline.valid || score.total + 0.01 < baseline.total)) {
          selection = trial; improved = true; break;
        }
      }
    }
    if (!improved) break;
  }
  const optimised = landedCost(selection);
  const selectedByRequirement = new Map(selection.map((entry) => [entry.line.requirementId, entry.choice]));
  const optimisedLines = lines.map((line) => ({ ...line, best: selectedByRequirement.get(line.requirementId) ?? line.best }));

  const supplierKeys = [...new Set(pricedLines.flatMap((line) => line.alternatives.map((a) => `${a.supplierId}:${a.supplierAccountId ?? 0}`)))];
  const singleSupplier = supplierKeys.map((key) => {
    const selected = pricedLines.map((line) => line.alternatives.find((a) => `${a.supplierId}:${a.supplierAccountId ?? 0}` === key)).filter(Boolean) as any[];
    if (selected.length !== pricedLines.length) return null;
    const subtotal = Math.round(selected.reduce((s, x) => s + x.lineTotal, 0) * 100) / 100;
    const delivery = accountDeliveryCost(selected[0], subtotal);
    if (!delivery.valid) return null;
    return {
      supplierId: selected[0].supplierId, supplierAccountId: selected[0].supplierAccountId,
      supplierName: selected[0].supplierName, subtotal, delivery: delivery.fee,
      total: Math.round((subtotal + delivery.fee) * 100) / 100,
    };
  }).filter(Boolean).sort((a: any, b: any) => a.total - b.total);

  const estimatedSubtotal = optimised.lineSubtotal;
  const landedTotal = optimised.total;
  const bestSingle = singleSupplier[0]?.total ?? landedTotal;
  const savings = Math.max(0, Math.round((bestSingle - landedTotal) * 100) / 100);

  await db.update(procurementPlansTable).set({ status: "superseded" })
    .where(and(eq(procurementPlansTable.companyId, req.companyId!), eq(procurementPlansTable.quoteId, quoteId), eq(procurementPlansTable.status, "ready")));

  const recommendation = {
    lines: optimisedLines, singleSupplierOptions: singleSupplier, preferredSuppliersOnly: preferredOnly,
    requireKnownPriceSource: requireKnown, estimatedLineSubtotal: estimatedSubtotal,
    deliveryFees: optimised.deliveryFees, landedTotal, optimiser: "delivery_minimum_order_aware_v1",
  };
  const [plan] = await db.insert(procurementPlansTable).values({
    companyId: req.companyId!, quoteId, jobId: quote.jobId,
    status: missing.length || !optimised.valid ? "draft" : "ready",
    strategy: "landed_cost", estimatedSubtotal: String(landedTotal), savingsVsSingleSupplier: String(savings),
    missingItemCount: missing.length, recommendation, createdByUserId: req.userId ?? null,
  }).returning();

  await db.insert(auditEventsTable).values({
    companyId: req.companyId!, userId: req.userId ?? null, actorType: "user",
    action: "procurement.plan.created", entityType: "procurement_plan", entityId: String(plan.id),
    metadata: { quoteId, lines: lines.length, missing: missing.length, landedTotal, deliveryFees: optimised.deliveryFees, savings },
  });
  res.status(201).json({ ...plan, estimatedSubtotal: landedTotal, savingsVsSingleSupplier: savings, recommendation });
});

router.get("/procurement/material-requirements/unmatched", requirePermission("purchasing.read"), async (req, res) => {
  const requirements = await db.select().from(materialRequirementsTable)
    .where(and(eq(materialRequirementsTable.companyId, req.companyId!), sql`${materialRequirementsTable.productId} is null`))
    .orderBy(desc(materialRequirementsTable.createdAt));
  const products = await db.select().from(procurementProductsTable)
    .where(and(eq(procurementProductsTable.companyId, req.companyId!), eq(procurementProductsTable.status, "active")));
  res.json(requirements.map((r) => ({
    ...r, quantity: money(r.quantity), wastePercent: money(r.wastePercent),
    suggestions: products.map((p) => ({ id: p.id, name: p.name, sku: p.sku, manufacturer: p.manufacturer, score: Math.max(similarityScore(r.description, p.name), p.description ? similarityScore(r.description, p.description) * 0.8 : 0) }))
      .filter((x) => x.score >= 0.25).sort((a, b) => b.score - a.score).slice(0, 5),
  })));
});

router.post("/procurement/material-requirements/:id/match", requirePermission("purchasing.manage"), async (req, res) => {
  const id = positiveId(req.params.id), productId = positiveId(req.body?.productId);
  if (!id || !productId) return res.status(400).json({ error: "Requirement and product are required" });
  const [product] = await db.select().from(procurementProductsTable)
    .where(and(eq(procurementProductsTable.id, productId), eq(procurementProductsTable.companyId, req.companyId!))).limit(1);
  if (!product) return res.status(404).json({ error: "Catalogue product not found" });
  const [row] = await db.update(materialRequirementsTable)
    .set({ productId, metadata: { confirmedMatch: true, confirmedByUserId: req.userId ?? null } })
    .where(and(eq(materialRequirementsTable.id, id), eq(materialRequirementsTable.companyId, req.companyId!))).returning();
  if (!row) return res.status(404).json({ error: "Material requirement not found" });
  await db.insert(auditEventsTable).values({
    companyId: req.companyId!, userId: req.userId ?? null, actorType: "user",
    action: "procurement.material_match.confirmed", entityType: "material_requirement", entityId: String(id),
    metadata: { productId, productName: product.name },
  });
  res.json(row);
});

router.get("/procurement/plans", requirePermission("purchasing.read"), async (req, res) => {
  const rows = await db.select().from(procurementPlansTable)
    .where(eq(procurementPlansTable.companyId, req.companyId!)).orderBy(desc(procurementPlansTable.createdAt));
  res.json(rows.map((row) => ({ ...row, estimatedSubtotal: money(row.estimatedSubtotal), savingsVsSingleSupplier: money(row.savingsVsSingleSupplier) })));
});

router.post("/procurement/plans/:id/create-pos", requirePermission("purchasing.manage"), async (req, res) => {
  const id = positiveId(req.params.id);
  if (!id) return res.status(400).json({ error: "Invalid procurement plan" });
  const [plan] = await db.select().from(procurementPlansTable)
    .where(and(eq(procurementPlansTable.id, id), eq(procurementPlansTable.companyId, req.companyId!))).limit(1);
  if (!plan) return res.status(404).json({ error: "Procurement plan not found" });
  if (plan.missingItemCount > 0) return res.status(409).json({ error: "Resolve unpriced/unmatched BOM lines before creating purchase orders" });

  const rec = (plan.recommendation ?? {}) as any;
  const lines = Array.isArray(rec.lines) ? rec.lines : [];
  const groups = new Map<number, any[]>();
  for (const line of lines) {
    if (!line.best?.supplierId) continue;
    const arr = groups.get(line.best.supplierId) ?? [];
    arr.push(line);
    groups.set(line.best.supplierId, arr);
  }
  if (!groups.size) return res.status(409).json({ error: "Plan has no priced supplier recommendations" });

  const [authority] = await db.select().from(procurementAuthorityTable).where(eq(procurementAuthorityTable.companyId, req.companyId!)).limit(1);
  const mode = authority?.mode ?? "assist";
  const autoLimit = money(authority?.autoApprovePurchaseLimit);
  const createdPos: any[] = [];
  for (const [supplierId, supplierLines] of groups.entries()) {
    const goodsSubtotal = Math.round(supplierLines.reduce((sum, line) => sum + money(line.best.lineTotal), 0) * 100) / 100;
    const deliveryInfo = accountDeliveryCost(supplierLines[0].best, goodsSubtotal);
    if (!deliveryInfo.valid) return res.status(409).json({ error: `${supplierLines[0].best.supplierName} basket is below its minimum order` });
    const deliveryFee = deliveryInfo.fee;
    const subtotal = Math.round((goodsSubtotal + deliveryFee) * 100) / 100;
    const vat = Math.round(subtotal * 0.2 * 100) / 100;
    const total = subtotal + vat;
    const canAutoApprove = mode === "operate" && autoLimit > 0 && total <= autoLimit;
    const status = canAutoApprove ? "approved" : "approval_required";
    const next = await db.select({ maxId: sql<number>`coalesce(max(${purchaseOrdersTable.id}), 0)::int` }).from(purchaseOrdersTable).where(eq(purchaseOrdersTable.companyId, req.companyId!));
    const poNumber = `PO-${String((next[0]?.maxId ?? 0) + 1).padStart(5, "0")}`;
    const [po] = await db.insert(purchaseOrdersTable).values({
      companyId: req.companyId!, poNumber, supplierId, supplierAccountId: supplierLines[0].best.supplierAccountId ?? null,
      jobId: plan.jobId, quoteId: plan.quoteId, status, subtotal: String(subtotal), vat: String(vat), total: String(total),
      notes: `Created from CREWON procurement plan #${plan.id}`, createdByUserId: req.userId ?? null,
      approvedByUserId: canAutoApprove ? req.userId ?? null : null, approvedAt: canAutoApprove ? new Date() : null,
    }).returning();
    const poItems = supplierLines.map((line) => ({
      companyId: req.companyId!, purchaseOrderId: po.id, productId: line.productId ?? null, description: line.description,
      supplierSku: line.best.supplierSku ?? null, quantity: String(line.quantity), unit: line.unit,
      unitCost: String(line.best.unitCost), lineTotal: String(line.best.lineTotal),
    }));
    if (deliveryFee > 0) poItems.push({
      companyId: req.companyId!, purchaseOrderId: po.id, productId: null, description: "Delivery",
      supplierSku: null, quantity: "1", unit: "delivery", unitCost: String(deliveryFee), lineTotal: String(deliveryFee),
    });
    await db.insert(purchaseOrderItemsTable).values(poItems);
    createdPos.push({ ...po, subtotal, vat, total, autoApproved: canAutoApprove });
  }
  await db.update(procurementPlansTable).set({ status: "converted" })
    .where(and(eq(procurementPlansTable.id, plan.id), eq(procurementPlansTable.companyId, req.companyId!)));
  await db.insert(auditEventsTable).values({
    companyId: req.companyId!, userId: req.userId ?? null, actorType: "system",
    actorLabel: "CREWON Procurement", action: "procurement.plan.converted_to_pos",
    entityType: "procurement_plan", entityId: String(plan.id),
    metadata: { purchaseOrderIds: createdPos.map((po) => po.id), authorityMode: mode, autoApprovePurchaseLimit: autoLimit },
  });
  res.status(201).json({ purchaseOrders: createdPos });
});

export default router;
