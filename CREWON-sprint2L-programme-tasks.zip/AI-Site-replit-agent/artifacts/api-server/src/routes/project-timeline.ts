import { Router } from "express";
import { and, desc, eq } from "drizzle-orm";
import {
  db, jobsTable, siteDiariesTable, siteEvidenceTable, siteProgressUpdatesTable,
  siteMaterialRequestsTable, siteIssuesTable, deliveriesTable, purchaseOrdersTable,
  suppliersTable, goodsReceiptsTable, projectVariationsTable, projectCommercialSnapshotsTable,
  workforceTimeEntriesTable, workforceProfilesTable, marginProtectionAlertsTable
} from "@workspace/db";
import { hasPermission } from "../lib/permissions";

const router=Router();
const positiveId=(v:unknown)=>{const n=Number(v);return Number.isInteger(n)&&n>0?n:null};
const money=(v:unknown)=>Number(v??0);
const text=(v:unknown)=>typeof v==="string"?v.trim():"";

function canRead(req:any){
  return hasPermission(req,"jobs.read")||hasPermission(req,"jobs.update")||hasPermission(req,"jobs.manage")||hasPermission(req,"workforce.read")||hasPermission(req,"finance.read")||hasPermission(req,"finance.manage");
}
function canWrite(req:any){
  return hasPermission(req,"jobs.update")||hasPermission(req,"jobs.manage")||hasPermission(req,"workforce.approve")||hasPermission(req,"workforce.manage");
}

router.get("/projects/:jobId/timeline",async(req,res)=>{
  if(!canRead(req))return res.status(403).json({error:"You do not have permission to view project evidence"});
  const jobId=positiveId(req.params.jobId);if(!jobId)return res.status(400).json({error:"Invalid project"});
  const [job]=await db.select().from(jobsTable).where(and(eq(jobsTable.companyId,req.companyId!),eq(jobsTable.id,jobId))).limit(1);
  if(!job)return res.status(404).json({error:"Project not found"});

  const [diaries,evidence,progress,materials,issues,deliveries,receipts,variations,snapshots,timesheets,alerts]=await Promise.all([
    db.select().from(siteDiariesTable).where(and(eq(siteDiariesTable.companyId,req.companyId!),eq(siteDiariesTable.jobId,jobId))).orderBy(desc(siteDiariesTable.createdAt)),
    db.select().from(siteEvidenceTable).where(and(eq(siteEvidenceTable.companyId,req.companyId!),eq(siteEvidenceTable.jobId,jobId))).orderBy(desc(siteEvidenceTable.createdAt)),
    db.select().from(siteProgressUpdatesTable).where(and(eq(siteProgressUpdatesTable.companyId,req.companyId!),eq(siteProgressUpdatesTable.jobId,jobId))).orderBy(desc(siteProgressUpdatesTable.createdAt)),
    db.select().from(siteMaterialRequestsTable).where(and(eq(siteMaterialRequestsTable.companyId,req.companyId!),eq(siteMaterialRequestsTable.jobId,jobId))).orderBy(desc(siteMaterialRequestsTable.createdAt)),
    db.select().from(siteIssuesTable).where(and(eq(siteIssuesTable.companyId,req.companyId!),eq(siteIssuesTable.jobId,jobId))).orderBy(desc(siteIssuesTable.createdAt)),
    db.select({
      id:deliveriesTable.id,status:deliveriesTable.status,reference:deliveriesTable.reference,scheduledAt:deliveriesTable.scheduledAt,
      receivedAt:deliveriesTable.receivedAt,createdAt:deliveriesTable.createdAt,supplierName:suppliersTable.name,poNumber:purchaseOrdersTable.poNumber
    }).from(deliveriesTable).leftJoin(suppliersTable,eq(suppliersTable.id,deliveriesTable.supplierId))
      .leftJoin(purchaseOrdersTable,eq(purchaseOrdersTable.id,deliveriesTable.purchaseOrderId))
      .where(and(eq(deliveriesTable.companyId,req.companyId!),eq(deliveriesTable.jobId,jobId))).orderBy(desc(deliveriesTable.createdAt)),
    db.select({
      id:goodsReceiptsTable.id,purchaseOrderId:goodsReceiptsTable.purchaseOrderId,reference:goodsReceiptsTable.reference,
      notes:goodsReceiptsTable.notes,receivedAt:goodsReceiptsTable.receivedAt,poNumber:purchaseOrdersTable.poNumber
    }).from(goodsReceiptsTable).innerJoin(purchaseOrdersTable,eq(purchaseOrdersTable.id,goodsReceiptsTable.purchaseOrderId))
      .where(and(eq(goodsReceiptsTable.companyId,req.companyId!),eq(purchaseOrdersTable.jobId,jobId))).orderBy(desc(goodsReceiptsTable.receivedAt)),
    db.select().from(projectVariationsTable).where(and(eq(projectVariationsTable.companyId,req.companyId!),eq(projectVariationsTable.jobId,jobId))).orderBy(desc(projectVariationsTable.createdAt)),
    db.select().from(projectCommercialSnapshotsTable).where(and(eq(projectCommercialSnapshotsTable.companyId,req.companyId!),eq(projectCommercialSnapshotsTable.jobId,jobId))).orderBy(desc(projectCommercialSnapshotsTable.calculatedAt)).limit(12),
    db.select({
      id:workforceTimeEntriesTable.id,workerName:workforceProfilesTable.name,workDate:workforceTimeEntriesTable.workDate,
      regularHours:workforceTimeEntriesTable.regularHours,overtimeHours:workforceTimeEntriesTable.overtimeHours,totalCost:workforceTimeEntriesTable.totalCost,
      status:workforceTimeEntriesTable.status,createdAt:workforceTimeEntriesTable.createdAt
    }).from(workforceTimeEntriesTable).innerJoin(workforceProfilesTable,eq(workforceProfilesTable.id,workforceTimeEntriesTable.workerId))
      .where(and(eq(workforceTimeEntriesTable.companyId,req.companyId!),eq(workforceTimeEntriesTable.jobId,jobId))).orderBy(desc(workforceTimeEntriesTable.workDate)).limit(100),
    db.select().from(marginProtectionAlertsTable).where(and(eq(marginProtectionAlertsTable.companyId,req.companyId!),eq(marginProtectionAlertsTable.jobId,jobId))).orderBy(desc(marginProtectionAlertsTable.createdAt)).limit(50)
  ]);

  const events:any[]=[];
  const add=(type:string,dateValue:any,title:string,detail:string,data:any={},severity?:string)=>{
    if(!dateValue)return;
    events.push({type,date:new Date(dateValue).toISOString(),title,detail,severity:severity||null,data});
  };

  for(const d of diaries)add("site_diary",d.createdAt,d.summary||"Site diary",d.transcript.slice(0,280),{
    id:d.id,status:d.status,progressPercent:d.progressPercent===null?null:money(d.progressPercent),
    evidence:evidence.filter(e=>e.diaryId===d.id).map(e=>({id:e.id,dataUrl:e.dataUrl,caption:e.caption,mimeType:e.mimeType,fileName:e.fileName}))
  });
  for(const p of progress)add("progress",p.createdAt,`Progress updated to ${money(p.progressPercent).toFixed(0)}%`,p.summary,{id:p.id,blockers:p.blockers,progressPercent:money(p.progressPercent)});
  for(const m of materials)add("material_request",m.createdAt,`${money(m.quantity)} ${m.unit} · ${m.description}`,m.reason||"Material request from site",{id:m.id,status:m.status,urgency:m.urgency},m.urgency==="critical"?"critical":m.urgency==="urgent"?"high":undefined);
  for(const i of issues)add("site_issue",i.createdAt,i.title,i.description,{id:i.id,status:i.status,issueType:i.issueType,potentialVariation:i.potentialVariation,estimatedImpact:money(i.estimatedImpact),
    evidence:evidence.filter(e=>e.entityType==="site_issue"&&e.entityId===i.id).map(e=>({id:e.id,dataUrl:e.dataUrl,caption:e.caption,mimeType:e.mimeType,fileName:e.fileName}))
  },i.severity);
  for(const d of deliveries){
    add("delivery",d.receivedAt||d.scheduledAt||d.createdAt,`${d.supplierName||"Supplier"} delivery · ${d.poNumber||d.reference||`#${d.id}`}`,`Status: ${d.status.replaceAll("_"," ")}`,{
      ...d,evidence:evidence.filter(e=>e.entityType==="delivery"&&e.entityId===d.id).map(e=>({id:e.id,dataUrl:e.dataUrl,caption:e.caption,mimeType:e.mimeType,fileName:e.fileName}))
    });
  }
  for(const r of receipts)add("goods_received",r.receivedAt,`Goods received · ${r.poNumber}`,r.reference||r.notes||"Goods receipt recorded",{id:r.id,purchaseOrderId:r.purchaseOrderId});
  for(const v of variations)add("variation",v.createdAt,`Variation ${v.reference||`#${v.id}`} · ${v.status}`,v.description,{id:v.id,value:money(v.value),estimatedCost:money(v.estimatedCost),status:v.status},v.status==="pending"?"medium":undefined);
  for(const s of snapshots)add("margin",s.calculatedAt,`Projected margin ${money(s.forecastMarginPercent).toFixed(1)}%`,`Margin movement ${money(s.marginMovementPoints).toFixed(1)} pts`,{id:s.id,riskLevel:s.riskLevel,forecastMargin:money(s.forecastMargin),forecastMarginPercent:money(s.forecastMarginPercent)},s.riskLevel);
  for(const ts of timesheets)add("labour",ts.workDate,`${ts.workerName} · ${(money(ts.regularHours)+money(ts.overtimeHours)).toFixed(2)}h`,`Timesheet ${ts.status} · £${money(ts.totalCost).toFixed(2)}`,{id:ts.id,status:ts.status,totalCost:money(ts.totalCost)});
  for(const a of alerts)add("commercial_alert",a.createdAt,a.title,a.explanation,{id:a.id,status:a.status,recommendedAction:a.recommendedAction,financialImpact:money(a.financialImpact)},a.severity);

  // General evidence not already attached to a specific event.
  for(const e of evidence.filter(e=>!e.diaryId&&!e.entityType))add("evidence",e.createdAt,e.caption||e.fileName||"Project photo","General project evidence",{id:e.id,dataUrl:e.dataUrl,mimeType:e.mimeType,fileName:e.fileName});

  events.sort((a,b)=>new Date(b.date).getTime()-new Date(a.date).getTime());
  res.json({
    job,
    summary:{
      diaries:diaries.length,photos:evidence.length,openIssues:issues.filter(i=>["open","reviewing","escalated"].includes(i.status)).length,
      openMaterialRequests:materials.filter(m=>["requested","approved","ordered"].includes(m.status)).length,
      pendingVariations:variations.filter(v=>v.status==="pending").length,
      latestProgress:progress[0]?money(progress[0].progressPercent):0
    },
    events
  });
});

router.post("/projects/:jobId/evidence",async(req,res)=>{
  if(!canWrite(req))return res.status(403).json({error:"You do not have permission to add project evidence"});
  const jobId=positiveId(req.params.jobId);if(!jobId)return res.status(400).json({error:"Invalid project"});
  const [job]=await db.select().from(jobsTable).where(and(eq(jobsTable.companyId,req.companyId!),eq(jobsTable.id,jobId))).limit(1);
  if(!job)return res.status(404).json({error:"Project not found"});
  const dataUrl=text(req.body?.dataUrl),mimeType=text(req.body?.mimeType)||"image/jpeg";
  if(!dataUrl.startsWith("data:image/")||dataUrl.length>7_000_000)return res.status(400).json({error:"A valid compressed image is required"});
  const entityType=text(req.body?.entityType)||null,entityId=positiveId(req.body?.entityId);
  if(entityType&&!["site_issue","delivery","progress","general"].includes(entityType))return res.status(400).json({error:"Invalid evidence link type"});
  const [row]=await db.insert(siteEvidenceTable).values({
    companyId:req.companyId!,jobId,diaryId:null,entityType:entityType||"general",entityId,
    evidenceType:"photo",fileName:text(req.body?.fileName)||null,mimeType,dataUrl,caption:text(req.body?.caption)||null,
    metadata:{source:text(req.body?.source)||"project_timeline"}
  }).returning();
  res.status(201).json(row);
});

export default router;
