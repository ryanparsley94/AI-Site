import express, { type Express, type Request, type Response } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { isPublicCrossOriginPath, isTrustedBrowserOrigin, rejectUntrustedBrowserOrigin } from "./middlewares/origin-security";

// Extend Request type to carry the raw body buffer for webhook signature verification
declare global {
  namespace Express {
    interface Request {
      rawBody?: Buffer;
      companyId?: number;
      userId?: number;
      actorType?: "user" | "bootstrap-admin";
      userRole?: string;
      userPermissions?: Record<string, boolean>;
    }
  }
}

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
// CORS is open only for the public embeddable widget/support endpoints.
// Authenticated dashboard routes accept same-origin traffic or explicitly
// configured CREWON_APP_ORIGINS only.
app.use(cors((corsReq, callback) => {
  const req = corsReq as Request;
  const origin = req.get("origin");
  if (isPublicCrossOriginPath(req.path)) {
    callback(null, { origin: origin || true, credentials: false });
    return;
  }
  if (!origin || isTrustedBrowserOrigin(req, origin)) {
    callback(null, { origin: origin || false, credentials: true });
    return;
  }
  callback(null, { origin: false, credentials: false });
}));
app.use(rejectUntrustedBrowserOrigin);
app.use(cookieParser());

// Capture raw body buffer before JSON parsing so webhook handlers can verify
// Resend (svix) signatures against the unmodified payload.
app.use(
  express.json({
    verify: (req: Request, _res: Response, buf: Buffer) => {
      req.rawBody = buf;
    },
  }),
);
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

export default app;
