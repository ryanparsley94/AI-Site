import app from "./app";
import { logger } from "./lib/logger";
import { pool } from "@workspace/db";
import { STARTUP_MIGRATIONS } from "./lib/startup-migrations";

// ─── Startup migration runner ─────────────────────────────────────────────────
// CREWON deployments must be able to upgrade an existing Replit prototype
// without requiring a manual database console step. Every migration bundled
// here is idempotent and is executed before the HTTP server starts accepting
// traffic.
async function runMigrations(): Promise<void> {
  const client = await pool.connect();
  try {
    for (const migration of STARTUP_MIGRATIONS) {
      await client.query("BEGIN");
      try {
        await client.query(migration.sql);
        await client.query("COMMIT");
        logger.info({ migration: migration.name }, "Database migration applied");
      } catch (error) {
        await client.query("ROLLBACK");
        throw Object.assign(new Error(`Migration failed: ${migration.name}`), { cause: error });
      }
    }
  } catch (err) {
    logger.error({ err }, "Migration failed — aborting startup");
    process.exit(1);
  } finally {
    client.release();
  }
}

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error("PORT environment variable is required but was not provided.");
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

runMigrations().then(() => {
  app.listen(port, (err) => {
    if (err) {
      logger.error({ err }, "Error listening on port");
      process.exit(1);
    }

    logger.info({ port }, "CREWON server listening");
  });
});
