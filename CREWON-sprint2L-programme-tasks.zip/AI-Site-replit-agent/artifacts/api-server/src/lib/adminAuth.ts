/**
 * Bootstrap admin authentication for the CREWON prototype.
 *
 * This is deliberately a transitional authentication layer. Commercial
 * multi-user login will move to the users/company_members model, but the
 * bootstrap password must still be secure while that work is completed.
 *
 * Security properties:
 *   - no session is issued without a correct SESSION_SECRET
 *   - constant-time password comparison
 *   - HttpOnly signed cookie
 *   - company id and issued-at time are cryptographically bound to the cookie
 *   - server-side age validation (not just browser cookie expiry)
 *   - SameSite=Lax so top-level OAuth callbacks can retain the session
 */
import { createHmac, timingSafeEqual, randomBytes } from "crypto";
import type { Request, Response, NextFunction } from "express";

export const COOKIE_NAME = "bai_admin"; // retained for compatibility with existing sessions/front-end
const MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000; // 7 days
const OAUTH_STATE_MAX_AGE_MS = 10 * 60 * 1000; // 10 minutes

function getSecret(): string | null {
  return process.env.SESSION_SECRET ?? null;
}

function sign(value: string, secret: string): string {
  const hmac = createHmac("sha256", secret);
  hmac.update(value);
  const sig = hmac.digest("hex").slice(0, 32);
  return `${value}.${sig}`;
}

function verify(signed: string, secret: string): boolean {
  try {
    const dotIdx = signed.lastIndexOf(".");
    if (dotIdx < 1) return false;
    const value = signed.slice(0, dotIdx);
    const expected = sign(value, secret);
    const a = Buffer.from(signed);
    const b = Buffer.from(expected);
    if (a.length !== b.length) return false;
    return timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

/** Constant-time comparison of a submitted bootstrap password. */
export function isAdminPasswordValid(password: string): boolean {
  const secret = getSecret();
  if (!secret) return false;
  try {
    const a = Buffer.from(password);
    const b = Buffer.from(secret);
    if (a.length !== b.length) return false;
    return timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

export type SessionPrincipal = {
  companyId: number;
  userId: number | null;
  actorType: "user" | "bootstrap-admin";
  issuedAt: number;
};

function parseSessionToken(cookie: string, secret: string): SessionPrincipal | null {
  if (!verify(cookie, secret)) return null;
  const dotIdx = cookie.lastIndexOf(".");
  const unsigned = dotIdx > 0 ? cookie.slice(0, dotIdx) : "";

  // Commercial user format: user:<userId>:<companyId>:<issuedAt>:<nonce>
  const user = /^user:(\d+):(\d+):(\d+):([a-f0-9]{32})$/.exec(unsigned);
  if (user) {
    const userId = Number(user[1]);
    const companyId = Number(user[2]);
    const issuedAt = Number(user[3]);
    if (!Number.isInteger(userId) || userId <= 0 || !Number.isInteger(companyId) || companyId <= 0 || !Number.isFinite(issuedAt)) return null;
    const age = Date.now() - issuedAt;
    if (age < 0 || age > MAX_AGE_MS) return null;
    return { userId, companyId, actorType: "user", issuedAt };
  }

  // Bootstrap format: admin:<companyId>:<issuedAt>:<nonce>
  const current = /^admin:(\d+):(\d+):([a-f0-9]{32})$/.exec(unsigned);
  if (current) {
    const companyId = Number(current[1]);
    const issuedAt = Number(current[2]);
    if (!Number.isInteger(companyId) || companyId <= 0 || !Number.isFinite(issuedAt)) return null;
    const age = Date.now() - issuedAt;
    if (age < 0 || age > MAX_AGE_MS) return null;
    return { userId: null, companyId, actorType: "bootstrap-admin", issuedAt };
  }

  // Transitional compatibility with sessions issued earlier in Sprint 1.
  const previous = /^admin:(\d+):([a-f0-9]{32})$/.exec(unsigned);
  if (previous) {
    const companyId = Number(previous[1]);
    if (Number.isInteger(companyId) && companyId > 0) {
      return { userId: null, companyId, actorType: "bootstrap-admin", issuedAt: Date.now() };
    }
  }

  return null;
}

/** Issue a bootstrap admin session after password validation. */
export function issueSessionIfValid(
  password: string,
  req: Request,
  res: Response,
  companyId: number,
): boolean {
  const secret = getSecret();
  if (!secret || !isAdminPasswordValid(password)) return false;

  const nonce = randomBytes(16).toString("hex");
  const token = sign(`admin:${companyId}:${Date.now()}:${nonce}`, secret);
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: MAX_AGE_MS,
    path: "/api",
  });
  return true;
}

/** Issue a signed session for a real CREWON user/company membership. */
export function issueUserSession(userId: number, companyId: number, res: Response): boolean {
  const secret = getSecret();
  if (!secret || !Number.isInteger(userId) || userId <= 0 || !Number.isInteger(companyId) || companyId <= 0) return false;
  const nonce = randomBytes(16).toString("hex");
  const token = sign(`user:${userId}:${companyId}:${Date.now()}:${nonce}`, secret);
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: MAX_AGE_MS,
    path: "/api",
  });
  return true;
}

/** Return the authenticated principal (real user or transitional bootstrap admin). */
export function getSessionPrincipal(req: Request): SessionPrincipal | null {
  const secret = getSecret();
  if (!secret) return null;
  const cookie = req.cookies?.[COOKIE_NAME] as string | undefined;
  if (!cookie) return null;
  return parseSessionToken(cookie, secret);
}

/** Check whether the current request carries a valid, non-expired session. */
export function hasValidSession(req: Request): boolean {
  return getSessionPrincipal(req) !== null;
}

/** Return the company id embedded in the signed session, if present. */
export function getSessionCompanyId(req: Request): number | null {
  return getSessionPrincipal(req)?.companyId ?? null;
}

/** Middleware: require a valid bootstrap admin session cookie. */
export function adminOnly(req: Request, res: Response, next: NextFunction): void {
  if (!hasValidSession(req)) {
    res.status(401).json({ error: "Unauthorized — admin session required" });
    return;
  }
  next();
}

/** Create a short-lived signed OAuth state value bound to a CREWON company. */
export function createOAuthState(companyId: number): string {
  const secret = getSecret();
  if (!secret) throw new Error("SESSION_SECRET is required for OAuth state");
  const nonce = randomBytes(16).toString("hex");
  return sign(`oauth:${companyId}:${Date.now()}:${nonce}`, secret);
}

/** Validate OAuth state, company binding and 10-minute expiry. */
export function verifyOAuthState(state: string | undefined, companyId: number): boolean {
  const secret = getSecret();
  if (!secret || !state || !verify(state, secret)) return false;

  const dotIdx = state.lastIndexOf(".");
  const unsigned = dotIdx > 0 ? state.slice(0, dotIdx) : "";
  const match = /^oauth:(\d+):(\d+):[a-f0-9]{32}$/.exec(unsigned);
  if (!match) return false;
  if (Number(match[1]) !== companyId) return false;
  const issuedAt = Number(match[2]);
  if (!Number.isFinite(issuedAt)) return false;
  const age = Date.now() - issuedAt;
  return age >= 0 && age <= OAUTH_STATE_MAX_AGE_MS;
}
