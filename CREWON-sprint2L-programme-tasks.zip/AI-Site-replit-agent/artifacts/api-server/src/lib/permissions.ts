import type { Request, Response, NextFunction } from "express";

export const ROLE_PERMISSIONS: Record<string, string[]> = {
  owner: ["*"],
  office_manager: ["team.manage", "crm.manage", "sales.manage", "jobs.manage", "purchasing.manage", "finance.manage", "inbox.manage", "settings.manage", "workforce.manage"],
  estimator: ["crm.read", "sales.manage", "jobs.read", "purchasing.read", "inbox.read"],
  project_manager: ["crm.read", "jobs.manage", "purchasing.manage", "finance.read", "inbox.read", "workforce.manage"],
  supervisor: ["jobs.update", "purchasing.read", "purchasing.request", "inbox.read", "workforce.approve", "workforce.read"],
  operative: ["jobs.read", "jobs.update_own", "workforce.submit_own"],
  finance: ["crm.read", "finance.manage", "jobs.read", "purchasing.read", "workforce.read"],
};

export function hasPermission(req: Request, permission: string): boolean {
  if (req.actorType === "bootstrap-admin" || req.userRole === "owner") return true;
  const explicit = req.userPermissions ?? {};
  if (explicit[permission] === true || explicit["*"] === true) return true;
  if (explicit[permission] === false) return false;
  const rolePerms = ROLE_PERMISSIONS[req.userRole ?? ""] ?? [];
  if (rolePerms.includes("*") || rolePerms.includes(permission)) return true;
  const [domain] = permission.split(".");
  return rolePerms.includes(`${domain}.manage`);
}

export function requirePermission(permission: string) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!hasPermission(req, permission)) {
      res.status(403).json({ error: "You do not have permission to perform this CREWON action", permission });
      return;
    }
    next();
  };
}
