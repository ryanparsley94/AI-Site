import { db, companiesTable, companyMembersTable, usersTable } from "@workspace/db";
import { and, eq } from "drizzle-orm";
import type { Request, Response, NextFunction } from "express";
import { getSessionPrincipal } from "./adminAuth";

/**
 * Legacy-compatible company bootstrap.
 *
 * CREWON is moving from a single-company prototype to multi-company SaaS.
 * Until onboarding is fully wired, the bootstrap password signs the first
 * company id into the session cookie.
 */
export async function getOrCreateDefaultCompany() {
  const existing = await db.select().from(companiesTable).orderBy(companiesTable.id).limit(1);
  if (existing.length > 0) return existing[0]!;

  const [created] = await db
    .insert(companiesTable)
    .values({
      name: "Your Company",
      phone: "00000000000",
      email: null,
      website: null,
      address: null,
      timezone: "Europe/London",
    })
    .returning();
  return created;
}

export async function getCompanyById(companyId: number) {
  const [company] = await db.select().from(companiesTable).where(eq(companiesTable.id, companyId));
  return company ?? null;
}

/**
 * Resolve the signed company context. For real users we also re-check active
 * membership on every request so removing a user from a company takes effect
 * immediately rather than waiting for a seven-day cookie to expire.
 */
export async function requireCompanyContext(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const principal = getSessionPrincipal(req);
    let companyId = principal?.companyId ?? null;

    if (!companyId) {
      const company = await getOrCreateDefaultCompany();
      companyId = company.id;
    }

    if (principal?.userId) {
      const [membership] = await db
        .select({
          role: companyMembersTable.role,
          permissions: companyMembersTable.permissions,
          userStatus: usersTable.status,
        })
        .from(companyMembersTable)
        .innerJoin(usersTable, eq(usersTable.id, companyMembersTable.userId))
        .where(
          and(
            eq(companyMembersTable.companyId, companyId),
            eq(companyMembersTable.userId, principal.userId),
          ),
        )
        .limit(1);

      if (!membership || membership.userStatus !== "active") {
        res.status(403).json({ error: "Your CREWON access to this company has been removed or disabled" });
        return;
      }

      req.userId = principal.userId;
      req.userRole = membership.role;
      req.userPermissions = (membership.permissions ?? {}) as Record<string, boolean>;
      req.actorType = "user";
    } else {
      req.actorType = "bootstrap-admin";
      req.userRole = "owner";
      req.userPermissions = {};
    }

    req.companyId = companyId;
    next();
  } catch (error) {
    req.log?.error({ error }, "Failed to resolve company context");
    res.status(500).json({ error: "Unable to resolve company context" });
  }
}
