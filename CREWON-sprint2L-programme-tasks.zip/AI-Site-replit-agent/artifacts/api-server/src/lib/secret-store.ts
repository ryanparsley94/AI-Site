/**
 * Small encrypted-at-rest secret wrapper for OAuth tokens.
 *
 * Format: enc:v1:<iv_b64url>:<tag_b64url>:<ciphertext_b64url>
 *
 * Backwards compatibility:
 *   Existing plaintext values are returned unchanged by decryptSecret().
 *   As soon as a provider reconnects or refreshes, the token is written encrypted.
 *
 * Configure OAUTH_TOKEN_SECRET in production. If it is absent we derive a key
 * from SESSION_SECRET so existing deployments keep working, but a dedicated
 * secret is strongly preferred.
 */
import { createCipheriv, createDecipheriv, createHash, randomBytes } from "crypto";

const PREFIX = "enc:v1:";

function getKey(): Buffer {
  const source = process.env.OAUTH_TOKEN_SECRET ?? process.env.SESSION_SECRET;
  if (!source) {
    throw new Error("OAUTH_TOKEN_SECRET or SESSION_SECRET must be configured to store OAuth tokens securely");
  }
  return createHash("sha256").update(source).digest();
}

export function encryptSecret(value: string | null | undefined): string | null {
  if (!value) return null;
  if (value.startsWith(PREFIX)) return value;

  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", getKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();

  return `${PREFIX}${iv.toString("base64url")}:${tag.toString("base64url")}:${ciphertext.toString("base64url")}`;
}

export function decryptSecret(value: string | null | undefined): string | null {
  if (!value) return null;
  // Legacy plaintext token: leave readable so existing installations do not break.
  if (!value.startsWith(PREFIX)) return value;

  const payload = value.slice(PREFIX.length);
  const parts = payload.split(":");
  if (parts.length !== 3) throw new Error("Encrypted secret has an invalid format");
  const [ivEncoded, tagEncoded, ciphertextEncoded] = parts;
  if (!ivEncoded || !tagEncoded || !ciphertextEncoded) {
    throw new Error("Encrypted secret is incomplete");
  }

  const decipher = createDecipheriv(
    "aes-256-gcm",
    getKey(),
    Buffer.from(ivEncoded, "base64url"),
  );
  decipher.setAuthTag(Buffer.from(tagEncoded, "base64url"));
  const plaintext = Buffer.concat([
    decipher.update(Buffer.from(ciphertextEncoded, "base64url")),
    decipher.final(),
  ]);
  return plaintext.toString("utf8");
}
