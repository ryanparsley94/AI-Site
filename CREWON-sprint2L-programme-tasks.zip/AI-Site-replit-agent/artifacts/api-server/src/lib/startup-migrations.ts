/**
 * Runtime database migrations bundled with the API server.
 *
 * Replit's deployment bundles TypeScript into one dist file, so standalone SQL
 * files are not guaranteed to be present at runtime. Keep deployment-critical
 * idempotent migrations here as well as in lib/db/migrations for auditability.
 */
export const STARTUP_MIGRATIONS = [
  { name: "legacy-prototype-tables", sql: String.raw`-- Legacy runtime migrations retained from the Replit prototype.
ALTER TABLE jobs ADD COLUMN IF NOT EXISTS company_id integer;

CREATE TABLE IF NOT EXISTS tasks (
  id serial PRIMARY KEY,
  title text NOT NULL,
  priority text NOT NULL DEFAULT 'medium',
  status text NOT NULL DEFAULT 'pending',
  source text NOT NULL DEFAULT 'manual',
  due_date timestamptz,
  company_id integer,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS marketing_drafts (
  id serial PRIMARY KEY,
  job_id integer,
  job_title text NOT NULL,
  client_name text NOT NULL,
  client_phone text,
  company_name text NOT NULL DEFAULT '',
  type text NOT NULL DEFAULT 'review_request',
  status text NOT NULL DEFAULT 'pending',
  draft_message text,
  edited_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS marketing_drafts_job_type_unique
  ON marketing_drafts (job_id, type)
  WHERE job_id IS NOT NULL;` },
  { name: "crewon-identity-audit", sql: String.raw`-- CREWON foundation: multi-user company membership + immutable audit trail.
-- Safe to run repeatedly.

CREATE TABLE IF NOT EXISTS users (
  id            serial PRIMARY KEY,
  email         text NOT NULL UNIQUE,
  name          text NOT NULL,
  password_hash text,
  status        text NOT NULL DEFAULT 'active',
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS company_members (
  id          serial PRIMARY KEY,
  company_id  integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id     integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role        text NOT NULL DEFAULT 'operative',
  permissions jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS company_members_company_user_uidx
  ON company_members(company_id, user_id);

CREATE TABLE IF NOT EXISTS audit_events (
  id          serial PRIMARY KEY,
  company_id  integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id     integer REFERENCES users(id) ON DELETE SET NULL,
  actor_type  text NOT NULL DEFAULT 'user',
  actor_label text,
  action      text NOT NULL,
  entity_type text,
  entity_id   text,
  metadata    jsonb NOT NULL DEFAULT '{}'::jsonb,
  ip_address  text,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS audit_events_company_created_idx
  ON audit_events(company_id, created_at);
CREATE INDEX IF NOT EXISTS audit_events_entity_idx
  ON audit_events(entity_type, entity_id);` },
  { name: "crewon-company-scoping", sql: String.raw`-- CREWON foundation: make business data company-scoped.
-- This migration upgrades the original single-company prototype safely.
-- Existing unscoped rows are assigned to the earliest company record.

DO $$
DECLARE
  default_company_id integer;
BEGIN
  SELECT id INTO default_company_id FROM companies ORDER BY id LIMIT 1;

  IF default_company_id IS NULL THEN
    INSERT INTO companies (name, phone, timezone)
    VALUES ('Your Company', '00000000000', 'Europe/London')
    RETURNING id INTO default_company_id;
  END IF;

  ALTER TABLE assistants       ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE contacts         ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE calls            ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE certificates     ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE conversations    ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE email_threads    ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE integrations     ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE invoices         ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE quotes           ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE marketing_drafts ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE jobs             ADD COLUMN IF NOT EXISTS company_id integer;
  ALTER TABLE tasks            ADD COLUMN IF NOT EXISTS company_id integer;

  UPDATE assistants       SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE contacts         SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE calls            SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE certificates     SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE conversations    SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE email_threads    SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE integrations     SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE invoices         SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE quotes           SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE marketing_drafts SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE jobs             SET company_id = default_company_id WHERE company_id IS NULL;
  UPDATE tasks            SET company_id = default_company_id WHERE company_id IS NULL;

  ALTER TABLE assistants       ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE contacts         ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE calls            ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE certificates     ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE conversations    ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE email_threads    ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE integrations     ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE invoices         ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE quotes           ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE marketing_drafts ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE jobs             ALTER COLUMN company_id SET NOT NULL;
  ALTER TABLE tasks            ALTER COLUMN company_id SET NOT NULL;

  -- Add foreign keys if they do not already exist. Constraint names are explicit
  -- so repeated deployments can safely detect them.
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='assistants_company_id_fkey') THEN
    ALTER TABLE assistants ADD CONSTRAINT assistants_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='contacts_company_id_fkey') THEN
    ALTER TABLE contacts ADD CONSTRAINT contacts_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='calls_company_id_fkey') THEN
    ALTER TABLE calls ADD CONSTRAINT calls_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='certificates_company_id_fkey') THEN
    ALTER TABLE certificates ADD CONSTRAINT certificates_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='conversations_company_id_fkey') THEN
    ALTER TABLE conversations ADD CONSTRAINT conversations_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='email_threads_company_id_fkey') THEN
    ALTER TABLE email_threads ADD CONSTRAINT email_threads_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='integrations_company_id_fkey') THEN
    ALTER TABLE integrations ADD CONSTRAINT integrations_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='invoices_company_id_fkey') THEN
    ALTER TABLE invoices ADD CONSTRAINT invoices_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='quotes_company_id_fkey') THEN
    ALTER TABLE quotes ADD CONSTRAINT quotes_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='marketing_drafts_company_id_fkey') THEN
    ALTER TABLE marketing_drafts ADD CONSTRAINT marketing_drafts_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='jobs_company_id_fkey') THEN
    ALTER TABLE jobs ADD CONSTRAINT jobs_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='tasks_company_id_fkey') THEN
    ALTER TABLE tasks ADD CONSTRAINT tasks_company_id_fkey FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE;
  END IF;
END $$;

-- The old schema allowed only one provider globally. Drop that uniqueness and
-- replace it with one provider connection per company.
ALTER TABLE integrations DROP CONSTRAINT IF EXISTS integrations_provider_unique;
CREATE UNIQUE INDEX IF NOT EXISTS integrations_company_provider_uidx
  ON integrations(company_id, provider);

CREATE INDEX IF NOT EXISTS assistants_company_idx       ON assistants(company_id);
CREATE INDEX IF NOT EXISTS contacts_company_idx         ON contacts(company_id);
CREATE INDEX IF NOT EXISTS calls_company_idx            ON calls(company_id);
CREATE INDEX IF NOT EXISTS certificates_company_idx     ON certificates(company_id);
CREATE INDEX IF NOT EXISTS conversations_company_idx    ON conversations(company_id);
CREATE INDEX IF NOT EXISTS email_threads_company_idx    ON email_threads(company_id);
CREATE INDEX IF NOT EXISTS invoices_company_idx         ON invoices(company_id);
CREATE INDEX IF NOT EXISTS quotes_company_idx           ON quotes(company_id);
CREATE INDEX IF NOT EXISTS marketing_drafts_company_idx ON marketing_drafts(company_id);
CREATE INDEX IF NOT EXISTS jobs_company_idx             ON jobs(company_id);
CREATE INDEX IF NOT EXISTS tasks_company_idx            ON tasks(company_id);

-- Apply CREWON's default electric-blue accent only where the original prototype
-- still has the old construction-orange defaults. Existing customer custom colours are preserved.
UPDATE companies SET quote_accent_color = '#1687ff' WHERE quote_accent_color = '#f97316';
UPDATE companies SET widget_color = '#1687ff' WHERE widget_color = '#f97316';` },
  { name: "crewon-team-permissions", sql: String.raw`CREATE TABLE IF NOT EXISTS team_invitations (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  email text NOT NULL,
  role text NOT NULL DEFAULT 'operative',
  permissions jsonb NOT NULL DEFAULT '{}'::jsonb,
  token_hash text NOT NULL UNIQUE,
  invited_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'pending',
  expires_at timestamptz NOT NULL,
  accepted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS team_invitations_company_status_idx ON team_invitations(company_id, status);` },
  { name: "crewon-procurement", sql: String.raw`-- CREWON Procurement foundation: supplier trade accounts, product catalogue,
-- customer-specific pricing, RFQs, purchase orders and deliveries.

CREATE TABLE IF NOT EXISTS suppliers (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name text NOT NULL,
  phone text,
  email text,
  website text,
  address text,
  preferred boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'active',
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS suppliers_company_idx ON suppliers(company_id);
CREATE INDEX IF NOT EXISTS suppliers_company_name_idx ON suppliers(company_id, name);

CREATE TABLE IF NOT EXISTS supplier_accounts (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  supplier_id integer NOT NULL REFERENCES suppliers(id) ON DELETE CASCADE,
  account_name text NOT NULL,
  account_number text,
  branch text,
  pricing_method text NOT NULL DEFAULT 'manual',
  currency text NOT NULL DEFAULT 'GBP',
  delivery_terms text,
  is_default boolean NOT NULL DEFAULT false,
  last_synced_at timestamptz,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS supplier_accounts_company_idx ON supplier_accounts(company_id);
CREATE INDEX IF NOT EXISTS supplier_accounts_supplier_idx ON supplier_accounts(supplier_id);

CREATE TABLE IF NOT EXISTS procurement_products (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  sku text,
  name text NOT NULL,
  description text,
  category text,
  manufacturer text,
  manufacturer_part_number text,
  unit text NOT NULL DEFAULT 'each',
  default_waste_percent numeric(6,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS procurement_products_company_idx ON procurement_products(company_id);
CREATE INDEX IF NOT EXISTS procurement_products_company_name_idx ON procurement_products(company_id, name);

CREATE TABLE IF NOT EXISTS supplier_prices (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  product_id integer NOT NULL REFERENCES procurement_products(id) ON DELETE CASCADE,
  supplier_id integer NOT NULL REFERENCES suppliers(id) ON DELETE CASCADE,
  supplier_account_id integer REFERENCES supplier_accounts(id) ON DELETE SET NULL,
  supplier_sku text,
  supplier_description text,
  unit_cost numeric(12,4) NOT NULL,
  quantity_break numeric(12,3) NOT NULL DEFAULT 1,
  availability text,
  lead_time_days integer,
  source text NOT NULL DEFAULT 'manual',
  valid_from timestamptz NOT NULL DEFAULT now(),
  valid_to timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS supplier_prices_company_product_idx ON supplier_prices(company_id, product_id);
CREATE INDEX IF NOT EXISTS supplier_prices_company_supplier_idx ON supplier_prices(company_id, supplier_id);
CREATE INDEX IF NOT EXISTS supplier_prices_product_valid_idx ON supplier_prices(product_id, valid_from DESC);

CREATE TABLE IF NOT EXISTS rfqs (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer REFERENCES jobs(id) ON DELETE SET NULL,
  quote_id integer REFERENCES quotes(id) ON DELETE SET NULL,
  title text NOT NULL,
  status text NOT NULL DEFAULT 'draft',
  due_at timestamptz,
  notes text,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS rfqs_company_status_idx ON rfqs(company_id, status);

CREATE TABLE IF NOT EXISTS rfq_items (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  rfq_id integer NOT NULL REFERENCES rfqs(id) ON DELETE CASCADE,
  product_id integer REFERENCES procurement_products(id) ON DELETE SET NULL,
  description text NOT NULL,
  quantity numeric(12,3) NOT NULL,
  unit text NOT NULL DEFAULT 'each'
);
CREATE INDEX IF NOT EXISTS rfq_items_rfq_idx ON rfq_items(rfq_id);

CREATE TABLE IF NOT EXISTS rfq_responses (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  rfq_id integer NOT NULL REFERENCES rfqs(id) ON DELETE CASCADE,
  supplier_id integer NOT NULL REFERENCES suppliers(id) ON DELETE CASCADE,
  supplier_account_id integer REFERENCES supplier_accounts(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'received',
  reference text,
  subtotal numeric(12,2),
  vat numeric(12,2),
  total numeric(12,2),
  notes text,
  received_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS rfq_responses_rfq_idx ON rfq_responses(rfq_id);

CREATE TABLE IF NOT EXISTS purchase_orders (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  po_number text NOT NULL,
  supplier_id integer NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
  supplier_account_id integer REFERENCES supplier_accounts(id) ON DELETE SET NULL,
  job_id integer REFERENCES jobs(id) ON DELETE SET NULL,
  quote_id integer REFERENCES quotes(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'draft',
  delivery_address text,
  required_by timestamptz,
  subtotal numeric(12,2) NOT NULL DEFAULT 0,
  vat numeric(12,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  notes text,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  approved_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  approved_at timestamptz,
  ordered_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS purchase_orders_company_number_uidx ON purchase_orders(company_id, po_number);
CREATE INDEX IF NOT EXISTS purchase_orders_company_status_idx ON purchase_orders(company_id, status);
CREATE INDEX IF NOT EXISTS purchase_orders_job_idx ON purchase_orders(job_id);

CREATE TABLE IF NOT EXISTS purchase_order_items (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  purchase_order_id integer NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  product_id integer REFERENCES procurement_products(id) ON DELETE SET NULL,
  description text NOT NULL,
  supplier_sku text,
  quantity numeric(12,3) NOT NULL,
  unit text NOT NULL DEFAULT 'each',
  unit_cost numeric(12,4) NOT NULL,
  line_total numeric(12,2) NOT NULL
);
CREATE INDEX IF NOT EXISTS purchase_order_items_po_idx ON purchase_order_items(purchase_order_id);

CREATE TABLE IF NOT EXISTS deliveries (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  purchase_order_id integer REFERENCES purchase_orders(id) ON DELETE SET NULL,
  supplier_id integer REFERENCES suppliers(id) ON DELETE SET NULL,
  job_id integer REFERENCES jobs(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'scheduled',
  reference text,
  scheduled_at timestamptz,
  received_at timestamptz,
  delivery_address text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS deliveries_company_status_idx ON deliveries(company_id, status);
CREATE INDEX IF NOT EXISTS deliveries_job_idx ON deliveries(job_id);
` },
  { name: "crewon-bom-authority", sql: String.raw`CREATE TABLE IF NOT EXISTS material_requirements (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  quote_id integer REFERENCES quotes(id) ON DELETE CASCADE,
  job_id integer REFERENCES jobs(id) ON DELETE SET NULL,
  product_id integer REFERENCES procurement_products(id) ON DELETE SET NULL,
  description text NOT NULL,
  quantity numeric(12,3) NOT NULL,
  unit text NOT NULL DEFAULT 'each',
  waste_percent numeric(6,2) NOT NULL DEFAULT 0,
  required_by timestamptz,
  status text NOT NULL DEFAULT 'required',
  source text NOT NULL DEFAULT 'quote',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS material_requirements_company_quote_idx ON material_requirements(company_id, quote_id);
CREATE TABLE IF NOT EXISTS procurement_authority (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  mode text NOT NULL DEFAULT 'assist',
  auto_approve_purchase_limit numeric(12,2) NOT NULL DEFAULT 0,
  preferred_suppliers_only boolean NOT NULL DEFAULT false,
  require_known_price_source boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS procurement_authority_company_uidx ON procurement_authority(company_id);
CREATE TABLE IF NOT EXISTS procurement_plans (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  quote_id integer REFERENCES quotes(id) ON DELETE CASCADE,
  job_id integer REFERENCES jobs(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'draft',
  strategy text NOT NULL DEFAULT 'best_line_price',
  estimated_subtotal numeric(12,2) NOT NULL DEFAULT 0,
  savings_vs_single_supplier numeric(12,2) NOT NULL DEFAULT 0,
  missing_item_count integer NOT NULL DEFAULT 0,
  recommendation jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS procurement_plans_company_quote_idx ON procurement_plans(company_id, quote_id);
` },
  { name: "crewon-procurement-controls", sql: String.raw`ALTER TABLE supplier_accounts ADD COLUMN IF NOT EXISTS minimum_order numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE supplier_accounts ADD COLUMN IF NOT EXISTS delivery_charge numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE supplier_accounts ADD COLUMN IF NOT EXISTS free_delivery_threshold numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE supplier_accounts ADD COLUMN IF NOT EXISTS delivery_lead_time_days integer;

CREATE TABLE IF NOT EXISTS goods_receipts (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  purchase_order_id integer NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  delivery_id integer REFERENCES deliveries(id) ON DELETE SET NULL,
  reference text,
  received_at timestamptz NOT NULL DEFAULT now(),
  received_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS goods_receipts_company_po_idx ON goods_receipts(company_id, purchase_order_id);

CREATE TABLE IF NOT EXISTS goods_receipt_items (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  goods_receipt_id integer NOT NULL REFERENCES goods_receipts(id) ON DELETE CASCADE,
  purchase_order_item_id integer NOT NULL REFERENCES purchase_order_items(id) ON DELETE RESTRICT,
  quantity_received numeric(12,3) NOT NULL,
  condition text NOT NULL DEFAULT 'accepted',
  notes text
);
CREATE INDEX IF NOT EXISTS goods_receipt_items_company_poitem_idx ON goods_receipt_items(company_id, purchase_order_item_id);

CREATE TABLE IF NOT EXISTS supplier_invoices (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  supplier_id integer NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
  supplier_account_id integer REFERENCES supplier_accounts(id) ON DELETE SET NULL,
  purchase_order_id integer REFERENCES purchase_orders(id) ON DELETE SET NULL,
  invoice_number text NOT NULL,
  invoice_date timestamptz NOT NULL,
  due_date timestamptz,
  subtotal numeric(12,2) NOT NULL DEFAULT 0,
  vat numeric(12,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'received',
  match_summary jsonb NOT NULL DEFAULT '{}'::jsonb,
  notes text,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS supplier_invoices_company_po_idx ON supplier_invoices(company_id, purchase_order_id);
CREATE UNIQUE INDEX IF NOT EXISTS supplier_invoices_company_supplier_number_uidx ON supplier_invoices(company_id, supplier_id, invoice_number);

CREATE TABLE IF NOT EXISTS supplier_invoice_items (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  supplier_invoice_id integer NOT NULL REFERENCES supplier_invoices(id) ON DELETE CASCADE,
  purchase_order_item_id integer REFERENCES purchase_order_items(id) ON DELETE SET NULL,
  description text NOT NULL,
  quantity numeric(12,3) NOT NULL,
  unit_cost numeric(12,4) NOT NULL,
  line_total numeric(12,2) NOT NULL
);
CREATE INDEX IF NOT EXISTS supplier_invoice_items_company_invoice_idx ON supplier_invoice_items(company_id, supplier_invoice_id);
` },
  { name: "crewon-margin-protection", sql: String.raw`CREATE TABLE IF NOT EXISTS project_commercial_snapshots (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  quote_id integer REFERENCES quotes(id) ON DELETE SET NULL,
  contract_value numeric(14,2) NOT NULL DEFAULT 0,
  baseline_cost numeric(14,2) NOT NULL DEFAULT 0,
  baseline_margin numeric(14,2) NOT NULL DEFAULT 0,
  baseline_margin_percent numeric(7,2) NOT NULL DEFAULT 0,
  committed_procurement numeric(14,2) NOT NULL DEFAULT 0,
  invoiced_procurement numeric(14,2) NOT NULL DEFAULT 0,
  procurement_variance numeric(14,2) NOT NULL DEFAULT 0,
  approved_variations numeric(14,2) NOT NULL DEFAULT 0,
  pending_variations numeric(14,2) NOT NULL DEFAULT 0,
  labour_actual numeric(14,2) NOT NULL DEFAULT 0,
  other_actual numeric(14,2) NOT NULL DEFAULT 0,
  forecast_final_cost numeric(14,2) NOT NULL DEFAULT 0,
  forecast_revenue numeric(14,2) NOT NULL DEFAULT 0,
  forecast_margin numeric(14,2) NOT NULL DEFAULT 0,
  forecast_margin_percent numeric(7,2) NOT NULL DEFAULT 0,
  margin_movement numeric(14,2) NOT NULL DEFAULT 0,
  margin_movement_points numeric(7,2) NOT NULL DEFAULT 0,
  risk_level text NOT NULL DEFAULT 'low',
  drivers jsonb NOT NULL DEFAULT '[]'::jsonb,
  calculated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS project_commercial_snapshots_company_job_idx ON project_commercial_snapshots(company_id, job_id, calculated_at DESC);

CREATE TABLE IF NOT EXISTS project_cost_adjustments (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  type text NOT NULL,
  description text NOT NULL,
  amount numeric(14,2) NOT NULL,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS project_cost_adjustments_company_job_idx ON project_cost_adjustments(company_id, job_id);

CREATE TABLE IF NOT EXISTS project_variations (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  reference text,
  description text NOT NULL,
  value numeric(14,2) NOT NULL,
  estimated_cost numeric(14,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending',
  client_approval_reference text,
  approved_at timestamptz,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS project_variations_company_job_idx ON project_variations(company_id, job_id);

CREATE TABLE IF NOT EXISTS margin_protection_alerts (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  snapshot_id integer REFERENCES project_commercial_snapshots(id) ON DELETE SET NULL,
  severity text NOT NULL,
  category text NOT NULL,
  title text NOT NULL,
  explanation text NOT NULL,
  recommended_action text,
  financial_impact numeric(14,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'open',
  acknowledged_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  acknowledged_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS margin_protection_alerts_company_job_status_idx ON margin_protection_alerts(company_id, job_id, status);
` },
  { name: "crewon-margin-recovery", sql: String.raw`CREATE TABLE IF NOT EXISTS margin_recovery_actions (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  snapshot_id integer REFERENCES project_commercial_snapshots(id) ON DELETE SET NULL,
  category text NOT NULL,
  title text NOT NULL,
  action text NOT NULL,
  estimated_recovery numeric(14,2) NOT NULL DEFAULT 0,
  authority_mode text NOT NULL DEFAULT 'assist',
  status text NOT NULL DEFAULT 'proposed',
  requires_human_approval boolean NOT NULL DEFAULT true,
  approved_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  approved_at timestamptz,
  actioned_at timestamptz,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS margin_recovery_actions_company_job_idx ON margin_recovery_actions(company_id,job_id,status);
` },
  { name: "crewon-workforce-labour", sql: String.raw`CREATE TABLE IF NOT EXISTS workforce_profiles (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id integer REFERENCES users(id) ON DELETE SET NULL,
  name text NOT NULL,
  worker_type text NOT NULL DEFAULT 'employee',
  trade text,
  phone text,
  email text,
  cost_rate numeric(10,2) NOT NULL DEFAULT 0,
  charge_rate numeric(10,2) NOT NULL DEFAULT 0,
  overtime_multiplier numeric(6,2) NOT NULL DEFAULT 1.5,
  active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS workforce_profiles_company_user_uidx ON workforce_profiles(company_id,user_id);

CREATE TABLE IF NOT EXISTS workforce_allocations (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  worker_id integer NOT NULL REFERENCES workforce_profiles(id) ON DELETE CASCADE,
  role text,
  planned_hours numeric(10,2) NOT NULL DEFAULT 0,
  planned_cost numeric(12,2) NOT NULL DEFAULT 0,
  start_date timestamptz,
  end_date timestamptz,
  status text NOT NULL DEFAULT 'allocated',
  notes text,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS workforce_allocations_company_job_idx ON workforce_allocations(company_id,job_id);

CREATE TABLE IF NOT EXISTS workforce_time_entries (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  worker_id integer NOT NULL REFERENCES workforce_profiles(id) ON DELETE CASCADE,
  allocation_id integer REFERENCES workforce_allocations(id) ON DELETE SET NULL,
  work_date timestamptz NOT NULL,
  started_at timestamptz,
  ended_at timestamptz,
  regular_hours numeric(10,2) NOT NULL DEFAULT 0,
  overtime_hours numeric(10,2) NOT NULL DEFAULT 0,
  cost_rate numeric(10,2) NOT NULL DEFAULT 0,
  overtime_multiplier numeric(6,2) NOT NULL DEFAULT 1.5,
  total_cost numeric(12,2) NOT NULL DEFAULT 0,
  notes text,
  status text NOT NULL DEFAULT 'submitted',
  submitted_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  approved_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  approved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS workforce_time_entries_company_job_status_idx ON workforce_time_entries(company_id,job_id,status);
CREATE INDEX IF NOT EXISTS workforce_time_entries_worker_date_idx ON workforce_time_entries(worker_id,work_date);

CREATE TABLE IF NOT EXISTS site_progress_updates (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  worker_id integer REFERENCES workforce_profiles(id) ON DELETE SET NULL,
  progress_percent numeric(6,2) NOT NULL DEFAULT 0,
  summary text NOT NULL,
  blockers text,
  submitted_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS site_progress_updates_company_job_idx ON site_progress_updates(company_id,job_id,created_at DESC);
` },
  { name: "crewon-supervisor", sql: String.raw`CREATE TABLE IF NOT EXISTS site_material_requests (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  requested_by_worker_id integer REFERENCES workforce_profiles(id) ON DELETE SET NULL,
  requested_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  product_id integer REFERENCES procurement_products(id) ON DELETE SET NULL,
  description text NOT NULL,
  quantity numeric(12,3) NOT NULL,
  unit text NOT NULL DEFAULT 'each',
  needed_by timestamptz,
  urgency text NOT NULL DEFAULT 'normal',
  reason text,
  status text NOT NULL DEFAULT 'requested',
  procurement_reference text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS site_material_requests_company_job_status_idx ON site_material_requests(company_id,job_id,status);

CREATE TABLE IF NOT EXISTS site_issues (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  reported_by_worker_id integer REFERENCES workforce_profiles(id) ON DELETE SET NULL,
  reported_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  issue_type text NOT NULL DEFAULT 'site',
  title text NOT NULL,
  description text NOT NULL,
  severity text NOT NULL DEFAULT 'medium',
  potential_variation text NOT NULL DEFAULT 'no',
  estimated_impact numeric(12,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'open',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);
CREATE INDEX IF NOT EXISTS site_issues_company_job_status_idx ON site_issues(company_id,job_id,status);
` },
  { name: "crewon-site-diary", sql: String.raw`CREATE TABLE IF NOT EXISTS site_diaries (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  worker_id integer REFERENCES workforce_profiles(id) ON DELETE SET NULL,
  submitted_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  source text NOT NULL DEFAULT 'voice_transcript',
  transcript text NOT NULL,
  summary text,
  weather_note text,
  progress_percent numeric(6,2),
  structured_output jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'draft',
  created_at timestamptz NOT NULL DEFAULT now(),
  committed_at timestamptz
);
CREATE INDEX IF NOT EXISTS site_diaries_company_job_idx ON site_diaries(company_id,job_id,created_at DESC);

CREATE TABLE IF NOT EXISTS site_evidence (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  diary_id integer REFERENCES site_diaries(id) ON DELETE CASCADE,
  evidence_type text NOT NULL DEFAULT 'photo',
  file_name text,
  mime_type text NOT NULL DEFAULT 'image/jpeg',
  data_url text NOT NULL,
  caption text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS site_evidence_company_job_idx ON site_evidence(company_id,job_id,created_at DESC);
` },
  { name: "crewon-project-timeline", sql: String.raw`ALTER TABLE site_evidence ADD COLUMN IF NOT EXISTS entity_type text;
ALTER TABLE site_evidence ADD COLUMN IF NOT EXISTS entity_id integer;
CREATE INDEX IF NOT EXISTS site_evidence_entity_idx ON site_evidence(company_id,job_id,entity_type,entity_id);
` },
  { name: "crewon-programme", sql: String.raw`CREATE TABLE IF NOT EXISTS project_milestones (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  target_date timestamptz,
  completed_at timestamptz,
  status text NOT NULL DEFAULT 'planned',
  sort_order integer NOT NULL DEFAULT 0,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS project_milestones_company_job_idx ON project_milestones(company_id,job_id,sort_order);

CREATE TABLE IF NOT EXISTS project_tasks (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  milestone_id integer REFERENCES project_milestones(id) ON DELETE SET NULL,
  parent_task_id integer,
  title text NOT NULL,
  description text,
  trade text,
  status text NOT NULL DEFAULT 'not_started',
  planned_start timestamptz,
  planned_finish timestamptz,
  actual_start timestamptz,
  actual_finish timestamptz,
  planned_hours numeric(10,2) NOT NULL DEFAULT 0,
  progress_percent numeric(6,2) NOT NULL DEFAULT 0,
  critical_path boolean NOT NULL DEFAULT false,
  blocker_reason text,
  sort_order integer NOT NULL DEFAULT 0,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by_user_id integer REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS project_tasks_company_job_status_idx ON project_tasks(company_id,job_id,status);

CREATE TABLE IF NOT EXISTS project_task_dependencies (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  task_id integer NOT NULL REFERENCES project_tasks(id) ON DELETE CASCADE,
  depends_on_task_id integer NOT NULL REFERENCES project_tasks(id) ON DELETE CASCADE,
  dependency_type text NOT NULL DEFAULT 'finish_to_start',
  lag_days integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS project_task_dependencies_job_idx ON project_task_dependencies(company_id,job_id);

CREATE TABLE IF NOT EXISTS project_task_assignments (
  id serial PRIMARY KEY,
  company_id integer NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  job_id integer NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  task_id integer NOT NULL REFERENCES project_tasks(id) ON DELETE CASCADE,
  worker_id integer NOT NULL REFERENCES workforce_profiles(id) ON DELETE CASCADE,
  planned_hours numeric(10,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS project_task_assignments_job_task_idx ON project_task_assignments(company_id,job_id,task_id);
` }
] as const;
