import { randomBytes, scryptSync, timingSafeEqual } from "crypto";

const KEY_LENGTH = 64;
const PREFIX = "scrypt:v1";

/** Hash a user password with Node's memory-hard scrypt KDF. */
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, KEY_LENGTH);
  return `${PREFIX}:${salt}:${derived.toString("hex")}`;
}

/** Verify a password against a CREWON scrypt hash. */
export function verifyPassword(password: string, encoded: string | null | undefined): boolean {
  if (!encoded) return false;
  const parts = encoded.split(":");
  if (parts.length !== 4 || `${parts[0]}:${parts[1]}` !== PREFIX) return false;
  const salt = parts[2];
  const expectedHex = parts[3];
  if (!salt || !expectedHex) return false;

  try {
    const expected = Buffer.from(expectedHex, "hex");
    const actual = scryptSync(password, salt, expected.length);
    return expected.length === actual.length && timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}
