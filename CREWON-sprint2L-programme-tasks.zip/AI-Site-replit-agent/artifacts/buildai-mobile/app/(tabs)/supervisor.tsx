import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Image, RefreshControl, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';
import { OfflineBanner } from '@/components/OfflineBanner';
import * as ImagePicker from 'expo-image-picker';

const BASE = process.env.EXPO_PUBLIC_DOMAIN ? `https://${process.env.EXPO_PUBLIC_DOMAIN}/api` : '/api';
async function api<T=any>(path:string, init?:RequestInit):Promise<T>{
  const r=await fetch(`${BASE}${path}`,{credentials:'include',headers:{'Content-Type':'application/json',...(init?.headers||{})},...init});
  const body=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(body?.error || `Request failed (${r.status})`);
  return body as T;
}
type Crew={workerId:number;workerName:string;role?:string|null;status:string};
type Material={id:number;description:string;quantity:number|string;unit:string;urgency:string;status:string};
type Issue={id:number;title:string;description:string;severity:string;status:string;potentialVariation:string};
type Delivery={id:number;supplierName?:string|null;poNumber?:string|null;reference?:string|null;scheduledAt?:string|null;status:string};
type Progress={progressPercent:number|string;summary:string;blockers?:string|null}|null;
type Job={id:number;title:string;address?:string|null;contactName:string;contactPhone:string;scheduledAt:string;status:string;crew:Crew[];progress:Progress;materialRequests:Material[];issues:Issue[];deliveries:Delivery[]};
type Timesheet={id:number;jobId:number;workerName:string;regularHours:number;overtimeHours:number;totalCost:number;workDate:string;notes?:string|null};
type Today={supervisor?:{id:number;name:string}|null;jobs:Job[];pendingTimesheets:Timesheet[];counts:{jobs:number;pendingTimesheets:number;materialRequests:number;issues:number;deliveries:number}};
type DiaryAnalysis={summary:string;progressPercent:number|null;progressSummary:string;blockers:string;materialRequests:Array<{description:string;quantity:number|null;unit:string;urgency:string;reason:string}>;issues:Array<{title:string;description:string;issueType:string;severity:string;potentialVariation:string;estimatedImpact:number|null}>;potentialVariations:Array<{title:string;reason:string;evidence:string}>;followUpQuestions:string[]};
type PhotoEvidence={uri:string;dataUrl:string;fileName:string;mimeType:string};

export default function SupervisorScreen(){
  const colors=useColors(); const insets=useSafeAreaInsets(); const online=useNetworkStatus();
  const [data,setData]=useState<Today|null>(null); const [loading,setLoading]=useState(true); const [refreshing,setRefreshing]=useState(false);
  const [selectedJob,setSelectedJob]=useState<string>(''); const [materialOpen,setMaterialOpen]=useState(false); const [issueOpen,setIssueOpen]=useState(false); const [progressOpen,setProgressOpen]=useState(false);
  const [material,setMaterial]=useState({description:'',quantity:'1',unit:'each',urgency:'normal',reason:''});
  const [issue,setIssue]=useState({title:'',description:'',severity:'medium',potentialVariation:'review',estimatedImpact:''});
  const [progress,setProgress]=useState({progressPercent:'',summary:'',blockers:''});
  const [diaryOpen,setDiaryOpen]=useState(false); const [diaryText,setDiaryText]=useState(''); const [diaryAnalysis,setDiaryAnalysis]=useState<DiaryAnalysis|null>(null); const [diaryId,setDiaryId]=useState<number|null>(null); const [diaryPhotos,setDiaryPhotos]=useState<PhotoEvidence[]>([]); const [analysing,setAnalysing]=useState(false);


  const load=useCallback(async()=>{try{setData(await api<Today>('/supervisor/today'));}catch(e:any){if(online)Alert.alert('CREWON Supervisor',e.message);}finally{setLoading(false);setRefreshing(false);}},[online]);
  useEffect(()=>{void load();},[load]);
  useEffect(()=>{if(!selectedJob&&data?.jobs[0])setSelectedJob(String(data.jobs[0].id));},[data,selectedJob]);
  const job=useMemo(()=>data?.jobs.find(j=>String(j.id)===selectedJob),[data,selectedJob]);

  const mutate=async(fn:()=>Promise<any>,success:string)=>{if(!online)return Alert.alert('Offline','Reconnect before submitting this update.');try{await fn();Alert.alert('CREWON',success);await load();}catch(e:any){Alert.alert('CREWON',e.message)}};
  const submitMaterial=()=>mutate(()=>api('/supervisor/material-requests',{method:'POST',body:JSON.stringify({jobId:Number(selectedJob),description:material.description,quantity:Number(material.quantity),unit:material.unit,urgency:material.urgency,reason:material.reason})}).then(()=>{setMaterial({description:'',quantity:'1',unit:'each',urgency:'normal',reason:''});setMaterialOpen(false)}),'Material request sent to Procurement');
  const submitIssue=()=>mutate(()=>api('/supervisor/issues',{method:'POST',body:JSON.stringify({jobId:Number(selectedJob),...issue,estimatedImpact:Number(issue.estimatedImpact||0)})}).then(()=>{setIssue({title:'',description:'',severity:'medium',potentialVariation:'review',estimatedImpact:''});setIssueOpen(false)}),'Site issue recorded');
  const submitProgress=()=>mutate(()=>api(`/workforce/jobs/${selectedJob}/progress`,{method:'POST',body:JSON.stringify({progressPercent:Number(progress.progressPercent),summary:progress.summary,blockers:progress.blockers})}).then(()=>{setProgress({progressPercent:'',summary:'',blockers:''});setProgressOpen(false)}),'Progress updated');
  const approveTime=(id:number,status:'approved'|'rejected')=>mutate(()=>api(`/workforce/time-entries/${id}/status`,{method:'PATCH',body:JSON.stringify({status})}),`Timesheet ${status}`);
  const captureEvidence=async(entityType:string,entityId:number)=>{
    if(!selectedJob)return;
    const permission=await ImagePicker.requestCameraPermissionsAsync();
    if(!permission.granted)return Alert.alert('Camera permission','CREWON needs camera access to attach site evidence.');
    const result=await ImagePicker.launchCameraAsync({mediaTypes:['images'],quality:0.6,base64:true,allowsEditing:false});
    if(result.canceled||!result.assets[0]?.base64)return;
    const a=result.assets[0],mime=a.mimeType||'image/jpeg';
    try{
      await api(`/projects/${selectedJob}/evidence`,{method:'POST',body:JSON.stringify({
        entityType,entityId,fileName:a.fileName||`${entityType}-${Date.now()}.jpg`,mimeType:mime,
        dataUrl:`data:${mime};base64,${a.base64}`,caption:`Supervisor evidence · ${entityType}`,source:'mobile_supervisor'
      })});
      Alert.alert('CREWON','Photo evidence attached to the project timeline.');
    }catch(e:any){Alert.alert('CREWON',e.message)}
  };
  const addDiaryPhoto=async()=>{
    const permission=await ImagePicker.requestCameraPermissionsAsync();
    if(!permission.granted)return Alert.alert('Camera permission','CREWON needs camera access to attach site evidence.');
    const result=await ImagePicker.launchCameraAsync({mediaTypes:['images'],quality:0.6,base64:true,allowsEditing:false});
    if(result.canceled||!result.assets[0])return;
    const a=result.assets[0]; if(!a.base64)return Alert.alert('CREWON','Could not prepare that photo.');
    const mime=a.mimeType||'image/jpeg';
    setDiaryPhotos(v=>[...v,{uri:a.uri,dataUrl:`data:${mime};base64,${a.base64}`,fileName:a.fileName||`site-${Date.now()}.jpg`,mimeType:mime}].slice(0,8));
  };
  const analyseDiary=async()=>{
    if(!selectedJob||!diaryText.trim())return Alert.alert('Site diary','Dictate or type your site update first.');
    setAnalysing(true);
    try{
      const analysis=await api<DiaryAnalysis>('/site-diary/analyse',{method:'POST',body:JSON.stringify({jobId:Number(selectedJob),transcript:diaryText})});
      setDiaryAnalysis(analysis);
    }catch(e:any){Alert.alert('CREWON',e.message)}finally{setAnalysing(false)}
  };
  const saveDiary=async()=>{
    if(!selectedJob||!diaryAnalysis)return;
    setAnalysing(true);
    try{
      const saved=await api<any>('/site-diary',{method:'POST',body:JSON.stringify({
        jobId:Number(selectedJob),source:'voice_transcript',transcript:diaryText,structuredOutput:diaryAnalysis,
        evidence:diaryPhotos.map(p=>({fileName:p.fileName,mimeType:p.mimeType,dataUrl:p.dataUrl}))
      })});
      setDiaryId(saved.id); Alert.alert('CREWON','Diary saved. Review the extracted actions, then commit them to the project.');
    }catch(e:any){Alert.alert('CREWON',e.message)}finally{setAnalysing(false)}
  };
  const commitDiary=async()=>{
    if(!diaryId)return;
    setAnalysing(true);
    try{
      const result=await api<any>(`/site-diary/${diaryId}/commit`,{method:'POST'});
      Alert.alert('Site diary committed',`Progress: ${result.results?.progress?'updated':'no change'}\nMaterial requests: ${result.results?.materials||0}\nIssues: ${result.results?.issues||0}`);
      setDiaryText('');setDiaryAnalysis(null);setDiaryId(null);setDiaryPhotos([]);setDiaryOpen(false);await load();
    }catch(e:any){Alert.alert('CREWON',e.message)}finally{setAnalysing(false)}
  };

  if(loading&&!data)return <View style={[styles.center,{backgroundColor:colors.background}]}><ActivityIndicator color={colors.primary} size="large"/></View>;

  return <ScrollView style={{backgroundColor:colors.background}} contentContainerStyle={{paddingTop:insets.top+10,paddingBottom:insets.bottom+110,paddingHorizontal:16}} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={()=>{setRefreshing(true);void load()}} tintColor={colors.primary}/>}>
    {!online?<OfflineBanner stale/>:null}
    <View style={styles.header}><View><Text style={[styles.eyebrow,{color:colors.primary}]}>CREWON SUPERVISOR</Text><Text style={[styles.title,{color:colors.foreground}]}>Today on site</Text><Text style={[styles.subtitle,{color:colors.mutedForeground}]}>{data?.supervisor?.name?`Morning, ${data.supervisor.name}. `:''}Jobs, crew, deliveries and issues in one place.</Text></View></View>

    <View style={styles.metrics}>
      <Metric icon="briefcase" value={data?.counts.jobs??0} label="Jobs" colors={colors}/>
      <Metric icon="clock" value={data?.counts.pendingTimesheets??0} label="Approvals" colors={colors}/>
      <Metric icon="package" value={data?.counts.deliveries??0} label="Deliveries" colors={colors}/>
      <Metric icon="alert-triangle" value={data?.counts.issues??0} label="Issues" colors={colors}/>
    </View>

    <Text style={[styles.sectionTitle,{color:colors.foreground}]}>Today’s jobs</Text>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap:8,paddingBottom:8}}>
      {data?.jobs.map(j=><TouchableOpacity key={j.id} onPress={()=>setSelectedJob(String(j.id))} style={[styles.jobChip,{borderColor:String(j.id)===selectedJob?colors.primary:colors.border,backgroundColor:String(j.id)===selectedJob?colors.primary+'16':colors.card}]}><Text style={[styles.jobChipTitle,{color:colors.foreground}]} numberOfLines={1}>{j.title}</Text><Text style={[styles.jobChipMeta,{color:colors.mutedForeground}]}>{new Date(j.scheduledAt).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'})} · {j.crew.length} crew</Text></TouchableOpacity>)}
    </ScrollView>

    {job?<>
      <View style={[styles.heroCard,{backgroundColor:colors.card,borderColor:colors.border}]}>
        <View style={styles.heroTop}><View style={{flex:1}}><Text style={[styles.heroTitle,{color:colors.foreground}]}>{job.title}</Text>{job.address?<Text style={[styles.heroMeta,{color:colors.mutedForeground}]}>{job.address}</Text>:null}</View><View style={[styles.statusPill,{backgroundColor:colors.primary+'18'}]}><Text style={[styles.statusText,{color:colors.primary}]}>{job.status.replaceAll('_',' ')}</Text></View></View>
        <View style={styles.progressRow}><Text style={[styles.smallLabel,{color:colors.mutedForeground}]}>Progress</Text><Text style={[styles.progressValue,{color:colors.foreground}]}>{Number(job.progress?.progressPercent??0).toFixed(0)}%</Text></View>
        <View style={[styles.progressTrack,{backgroundColor:colors.muted}]}><View style={[styles.progressFill,{backgroundColor:colors.primary,width:`${Math.min(100,Math.max(0,Number(job.progress?.progressPercent??0)))}%`}]} /></View>
        {job.progress?.summary?<Text style={[styles.progressSummary,{color:colors.mutedForeground}]}>{job.progress.summary}</Text>:null}
      </View>

      <View style={styles.quickGrid}>
        <Quick icon="trending-up" label="Progress" color={colors.primary} onPress={()=>setProgressOpen(v=>!v)} colors={colors}/>
        <Quick icon="package" label="Materials" color="#7c3aed" onPress={()=>setMaterialOpen(v=>!v)} colors={colors}/>
        <Quick icon="alert-circle" label="Issue" color="#e11d48" onPress={()=>setIssueOpen(v=>!v)} colors={colors}/>
        <Quick icon="mic" label="Diary" color="#2563eb" onPress={()=>setDiaryOpen(v=>!v)} colors={colors}/>
        <Quick icon="phone" label="Customer" color="#059669" onPress={()=>{import('react-native').then(({Linking})=>Linking.openURL(`tel:${job.contactPhone}`))}} colors={colors}/>
      </View>

      {diaryOpen?<FormCard title="Voice Site Diary" colors={colors}>
        <View style={[styles.diaryHint,{backgroundColor:colors.primary+'10'}]}><Feather name="mic" size={16} color={colors.primary}/><Text style={[styles.diaryHintText,{color:colors.mutedForeground}]}>Use your phone keyboard microphone to dictate naturally. CREWON will structure the transcript, but nothing is added to the job until you review and commit it.</Text></View>
        <Field colors={colors} placeholder="Example: We’re about 45% complete. Client asked for two extra sockets in the kitchen. Need 3 more sheets of 12.5mm plasterboard tomorrow. Delivery was short by two boxes..." multiline style={{minHeight:120,textAlignVertical:'top'}} value={diaryText} onChangeText={setDiaryText}/>
        <View style={styles.diaryActions}><TouchableOpacity onPress={addDiaryPhoto} style={[styles.secondaryButton,{borderColor:colors.border}]}><Feather name="camera" size={15} color={colors.primary}/><Text style={[styles.secondaryButtonText,{color:colors.foreground}]}>Add photo</Text></TouchableOpacity><TouchableOpacity onPress={analyseDiary} disabled={analysing} style={[styles.secondaryButton,{borderColor:colors.primary,opacity:analysing?0.6:1}]}>{analysing?<ActivityIndicator size="small" color={colors.primary}/>:<Feather name="zap" size={15} color={colors.primary}/>}<Text style={[styles.secondaryButtonText,{color:colors.primary}]}>Analyse diary</Text></TouchableOpacity></View>
        {diaryPhotos.length?<ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap:8}}>{diaryPhotos.map((ph,i)=><View key={i} style={styles.photoWrap}><Image source={{uri:ph.uri}} style={styles.photo}/><TouchableOpacity onPress={()=>setDiaryPhotos(v=>v.filter((_,x)=>x!==i))} style={styles.photoRemove}><Feather name="x" size={12} color="#fff"/></TouchableOpacity></View>)}</ScrollView>:null}
        {diaryAnalysis?<View style={[styles.analysisCard,{borderColor:colors.border,backgroundColor:colors.background}]}>
          <Text style={[styles.analysisTitle,{color:colors.foreground}]}>CREWON extracted</Text>
          <Text style={[styles.analysisSummary,{color:colors.mutedForeground}]}>{diaryAnalysis.summary}</Text>
          {diaryAnalysis.progressPercent!==null?<AnalysisLine icon="trending-up" text={`Progress ${diaryAnalysis.progressPercent}% · ${diaryAnalysis.progressSummary}`} colors={colors}/>:null}
          {diaryAnalysis.materialRequests.map((m,i)=><AnalysisLine key={`m${i}`} icon="package" text={`${m.quantity??'?'} ${m.unit} · ${m.description} · ${m.urgency}`} colors={colors}/>)}
          {diaryAnalysis.issues.map((x,i)=><AnalysisLine key={`i${i}`} icon="alert-triangle" text={`${x.title} · ${x.severity}${x.potentialVariation!=='no'?' · variation review':''}`} colors={colors}/>)}
          {diaryAnalysis.followUpQuestions?.length?<View style={{marginTop:8}}><Text style={[styles.followTitle,{color:colors.foreground}]}>Needs clarification before CREWON can act</Text>{diaryAnalysis.followUpQuestions.map((q,i)=><Text key={i} style={[styles.followText,{color:colors.mutedForeground}]}>• {q}</Text>)}</View>:null}
          {!diaryId?<PrimaryButton label="Save reviewed diary" onPress={saveDiary} colors={colors}/>:<PrimaryButton label="Commit confirmed actions to project" onPress={commitDiary} colors={colors}/>}
        </View>:null}
      </FormCard>:null}

      {progressOpen?<FormCard title="Site progress" colors={colors}><Field placeholder="Progress %" keyboardType="numeric" value={progress.progressPercent} onChangeText={v=>setProgress({...progress,progressPercent:v})} colors={colors}/><Field placeholder="What has been completed?" value={progress.summary} onChangeText={v=>setProgress({...progress,summary:v})} colors={colors}/><Field placeholder="Blockers / delays (optional)" value={progress.blockers} onChangeText={v=>setProgress({...progress,blockers:v})} colors={colors}/><PrimaryButton label="Update progress" onPress={submitProgress} colors={colors}/></FormCard>:null}

      {materialOpen?<FormCard title="Request materials" colors={colors}><Field placeholder="Material / description" value={material.description} onChangeText={v=>setMaterial({...material,description:v})} colors={colors}/><View style={styles.two}><Field style={{flex:1}} placeholder="Qty" keyboardType="numeric" value={material.quantity} onChangeText={v=>setMaterial({...material,quantity:v})} colors={colors}/><Field style={{flex:1}} placeholder="Unit" value={material.unit} onChangeText={v=>setMaterial({...material,unit:v})} colors={colors}/></View><View style={styles.pills}>{['normal','urgent','critical'].map(u=><TouchableOpacity key={u} onPress={()=>setMaterial({...material,urgency:u})} style={[styles.choice,{borderColor:material.urgency===u?colors.primary:colors.border,backgroundColor:material.urgency===u?colors.primary+'18':colors.background}]}><Text style={{color:material.urgency===u?colors.primary:colors.mutedForeground,textTransform:'capitalize',fontFamily:'Inter_500Medium'}}>{u}</Text></TouchableOpacity>)}</View><Field placeholder="Why / where needed?" value={material.reason} onChangeText={v=>setMaterial({...material,reason:v})} colors={colors}/><PrimaryButton label="Send to Procurement" onPress={submitMaterial} colors={colors}/></FormCard>:null}

      {issueOpen?<FormCard title="Report site issue" colors={colors}><Field placeholder="Short title" value={issue.title} onChangeText={v=>setIssue({...issue,title:v})} colors={colors}/><Field placeholder="Describe what happened / client instruction" multiline value={issue.description} onChangeText={v=>setIssue({...issue,description:v})} colors={colors}/><View style={styles.pills}>{['medium','high','critical'].map(u=><TouchableOpacity key={u} onPress={()=>setIssue({...issue,severity:u})} style={[styles.choice,{borderColor:issue.severity===u?colors.primary:colors.border,backgroundColor:issue.severity===u?colors.primary+'18':colors.background}]}><Text style={{color:issue.severity===u?colors.primary:colors.mutedForeground,textTransform:'capitalize',fontFamily:'Inter_500Medium'}}>{u}</Text></TouchableOpacity>)}</View><Field placeholder="Estimated cost impact £ (optional)" keyboardType="numeric" value={issue.estimatedImpact} onChangeText={v=>setIssue({...issue,estimatedImpact:v})} colors={colors}/><PrimaryButton label="Record & escalate" onPress={submitIssue} colors={colors}/></FormCard>:null}

      <Section title={`Crew · ${job.crew.length}`} colors={colors}>{job.crew.length?job.crew.map(c=><Row key={c.workerId} icon="user" title={c.workerName} detail={c.role||'Site team'} colors={colors}/>):<Empty text="No crew allocated yet." colors={colors}/>}</Section>
      <Section title={`Deliveries · ${job.deliveries.length}`} colors={colors}>{job.deliveries.length?job.deliveries.map(d=><View key={d.id} style={[styles.deliveryRow,{borderBottomColor:colors.border}]}><View style={[styles.rowIcon,{backgroundColor:colors.muted}]}><Feather name="truck" size={14} color={colors.mutedForeground}/></View><View style={{flex:1}}><Text style={[styles.rowTitle,{color:colors.foreground}]}>{d.supplierName||'Supplier delivery'}</Text><Text style={[styles.rowDetail,{color:colors.mutedForeground}]}>{`${d.poNumber||d.reference||'Delivery'} · ${d.status.replaceAll('_',' ')}${d.scheduledAt?` · ${new Date(d.scheduledAt).toLocaleString('en-GB',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}`:''}`}</Text></View><TouchableOpacity onPress={()=>captureEvidence('delivery',d.id)} style={[styles.cameraButton,{borderColor:colors.border}]}><Feather name="camera" size={15} color={colors.primary}/></TouchableOpacity></View>):<Empty text="No live deliveries." colors={colors}/>}</Section>
      <Section title={`Material requests · ${job.materialRequests.length}`} colors={colors}>{job.materialRequests.length?job.materialRequests.map(r=><Row key={r.id} icon="package" title={`${r.quantity} ${r.unit} · ${r.description}`} detail={`${r.urgency} · ${r.status}`} colors={colors}/>):<Empty text="No open material requests." colors={colors}/>}</Section>
      <Section title={`Site issues · ${job.issues.length}`} colors={colors}>{job.issues.length?job.issues.map(i=><Row key={i.id} icon="alert-triangle" title={i.title} detail={`${i.severity} · ${i.status}${i.potentialVariation!=='no'?' · variation review':''}`} colors={colors}/>):<Empty text="No open site issues." colors={colors}/>}</Section>
    </>:<View style={[styles.emptyCard,{borderColor:colors.border}]}><Text style={{color:colors.mutedForeground}}>No jobs allocated today.</Text></View>}

    {data?.pendingTimesheets?.length?<Section title={`Timesheets awaiting approval · ${data.pendingTimesheets.length}`} colors={colors}>{data.pendingTimesheets.map(t=><View key={t.id} style={[styles.approval,{borderColor:colors.border}]}><View style={{flex:1}}><Text style={[styles.rowTitle,{color:colors.foreground}]}>{t.workerName}</Text><Text style={[styles.rowDetail,{color:colors.mutedForeground}]}>{(t.regularHours+t.overtimeHours).toFixed(2)}h · £{t.totalCost.toFixed(2)} · {new Date(t.workDate).toLocaleDateString('en-GB')}</Text>{t.notes?<Text style={[styles.rowDetail,{color:colors.mutedForeground}]}>{t.notes}</Text>:null}</View><View style={{gap:6}}><TouchableOpacity onPress={()=>approveTime(t.id,'approved')} style={[styles.miniButton,{backgroundColor:colors.primary}]}><Feather name="check" color="#fff" size={14}/></TouchableOpacity><TouchableOpacity onPress={()=>approveTime(t.id,'rejected')} style={[styles.miniButton,{borderWidth:1,borderColor:colors.border}]}><Feather name="x" color={colors.mutedForeground} size={14}/></TouchableOpacity></View></View>)}</Section>:null}
  </ScrollView>
}

function Metric({icon,value,label,colors}:{icon:any;value:number;label:string;colors:any}){return <View style={[styles.metric,{backgroundColor:colors.card,borderColor:colors.border}]}><Feather name={icon} size={16} color={colors.primary}/><Text style={[styles.metricValue,{color:colors.foreground}]}>{value}</Text><Text style={[styles.metricLabel,{color:colors.mutedForeground}]}>{label}</Text></View>}
function Quick({icon,label,onPress,color,colors}:{icon:any;label:string;onPress:()=>void;color:string;colors:any}){return <TouchableOpacity onPress={onPress} style={[styles.quick,{backgroundColor:colors.card,borderColor:colors.border}]}><View style={[styles.quickIcon,{backgroundColor:color+'16'}]}><Feather name={icon} size={18} color={color}/></View><Text style={[styles.quickText,{color:colors.foreground}]}>{label}</Text></TouchableOpacity>}
function Section({title,children,colors}:{title:string;children:React.ReactNode;colors:any}){return <View style={styles.section}><Text style={[styles.sectionTitle,{color:colors.foreground}]}>{title}</Text><View style={[styles.sectionCard,{backgroundColor:colors.card,borderColor:colors.border}]}>{children}</View></View>}
function Row({icon,title,detail,colors}:{icon:any;title:string;detail:string;colors:any}){return <View style={[styles.row,{borderBottomColor:colors.border}]}><View style={[styles.rowIcon,{backgroundColor:colors.muted}]}><Feather name={icon} size={14} color={colors.mutedForeground}/></View><View style={{flex:1}}><Text style={[styles.rowTitle,{color:colors.foreground}]}>{title}</Text><Text style={[styles.rowDetail,{color:colors.mutedForeground}]}>{detail}</Text></View></View>}
function Empty({text,colors}:{text:string;colors:any}){return <Text style={[styles.empty,{color:colors.mutedForeground}]}>{text}</Text>}
function AnalysisLine({icon,text,colors}:{icon:any;text:string;colors:any}){return <View style={styles.analysisLine}><Feather name={icon} size={14} color={colors.primary}/><Text style={[styles.analysisLineText,{color:colors.foreground}]}>{text}</Text></View>}
function FormCard({title,children,colors}:{title:string;children:React.ReactNode;colors:any}){return <View style={[styles.formCard,{backgroundColor:colors.card,borderColor:colors.border}]}><Text style={[styles.formTitle,{color:colors.foreground}]}>{title}</Text>{children}</View>}
function Field({colors,style,...props}:any){return <TextInput placeholderTextColor={colors.mutedForeground} style={[styles.input,{borderColor:colors.border,color:colors.foreground,backgroundColor:colors.background},style]} {...props}/>}
function PrimaryButton({label,onPress,colors}:{label:string;onPress:()=>void;colors:any}){return <TouchableOpacity onPress={onPress} style={[styles.primary,{backgroundColor:colors.primary}]}><Text style={styles.primaryText}>{label}</Text></TouchableOpacity>}

const styles=StyleSheet.create({
 center:{flex:1,alignItems:'center',justifyContent:'center'},header:{marginBottom:16},eyebrow:{fontSize:11,fontFamily:'Inter_700Bold',letterSpacing:1.5},title:{fontSize:28,fontFamily:'Inter_700Bold',marginTop:3},subtitle:{fontSize:13,fontFamily:'Inter_400Regular',lineHeight:19,marginTop:4,maxWidth:330},
 metrics:{flexDirection:'row',gap:8,marginBottom:20},metric:{flex:1,borderWidth:1,borderRadius:10,padding:10,minHeight:82},metricValue:{fontSize:20,fontFamily:'Inter_700Bold',marginTop:6},metricLabel:{fontSize:10,fontFamily:'Inter_500Medium'},
 sectionTitle:{fontSize:16,fontFamily:'Inter_700Bold',marginBottom:9},jobChip:{width:185,borderWidth:1,borderRadius:10,padding:11},jobChipTitle:{fontSize:13,fontFamily:'Inter_600SemiBold'},jobChipMeta:{fontSize:11,fontFamily:'Inter_400Regular',marginTop:4},
 heroCard:{borderWidth:1,borderRadius:12,padding:15,marginTop:7},heroTop:{flexDirection:'row',gap:10},heroTitle:{fontSize:18,fontFamily:'Inter_700Bold'},heroMeta:{fontSize:12,fontFamily:'Inter_400Regular',marginTop:3},statusPill:{paddingHorizontal:9,paddingVertical:5,borderRadius:12,alignSelf:'flex-start'},statusText:{fontSize:10,fontFamily:'Inter_600SemiBold',textTransform:'capitalize'},
 progressRow:{flexDirection:'row',justifyContent:'space-between',marginTop:15},smallLabel:{fontSize:11,fontFamily:'Inter_500Medium'},progressValue:{fontSize:12,fontFamily:'Inter_700Bold'},progressTrack:{height:7,borderRadius:4,overflow:'hidden',marginTop:6},progressFill:{height:'100%',borderRadius:4},progressSummary:{fontSize:12,fontFamily:'Inter_400Regular',marginTop:8},
 quickGrid:{flexDirection:'row',gap:8,marginVertical:14},quick:{flex:1,borderWidth:1,borderRadius:10,alignItems:'center',paddingVertical:11,gap:5},quickIcon:{width:32,height:32,borderRadius:9,alignItems:'center',justifyContent:'center'},quickText:{fontSize:10,fontFamily:'Inter_600SemiBold'},
 formCard:{borderWidth:1,borderRadius:12,padding:13,gap:9,marginBottom:15},formTitle:{fontSize:15,fontFamily:'Inter_700Bold'},input:{borderWidth:1,borderRadius:8,paddingHorizontal:11,paddingVertical:10,fontSize:13,fontFamily:'Inter_400Regular'},two:{flexDirection:'row',gap:8},pills:{flexDirection:'row',gap:7},choice:{borderWidth:1,borderRadius:16,paddingVertical:7,paddingHorizontal:12},primary:{borderRadius:8,paddingVertical:12,alignItems:'center'},primaryText:{color:'#fff',fontFamily:'Inter_600SemiBold',fontSize:13},
 section:{marginTop:17},sectionCard:{borderWidth:1,borderRadius:11,overflow:'hidden'},row:{flexDirection:'row',gap:10,padding:12,borderBottomWidth:StyleSheet.hairlineWidth},rowIcon:{width:31,height:31,borderRadius:8,alignItems:'center',justifyContent:'center'},rowTitle:{fontSize:13,fontFamily:'Inter_600SemiBold'},rowDetail:{fontSize:11,fontFamily:'Inter_400Regular',marginTop:2,textTransform:'capitalize'},empty:{fontSize:12,fontFamily:'Inter_400Regular',padding:15},emptyCard:{borderWidth:1,borderRadius:10,padding:20,alignItems:'center'},
  diaryHint:{flexDirection:'row',gap:8,padding:10,borderRadius:8,alignItems:'flex-start'},diaryHintText:{fontSize:11,fontFamily:'Inter_400Regular',lineHeight:16,flex:1},diaryActions:{flexDirection:'row',gap:8},secondaryButton:{flex:1,borderWidth:1,borderRadius:8,paddingVertical:10,alignItems:'center',justifyContent:'center',flexDirection:'row',gap:6},secondaryButtonText:{fontSize:12,fontFamily:'Inter_600SemiBold'},photoWrap:{position:'relative'},photo:{width:96,height:96,borderRadius:9},photoRemove:{position:'absolute',right:4,top:4,width:22,height:22,borderRadius:11,backgroundColor:'rgba(0,0,0,.65)',alignItems:'center',justifyContent:'center'},analysisCard:{borderWidth:1,borderRadius:10,padding:11,gap:8},analysisTitle:{fontSize:13,fontFamily:'Inter_700Bold'},analysisSummary:{fontSize:12,fontFamily:'Inter_400Regular',lineHeight:17},analysisLine:{flexDirection:'row',gap:8,alignItems:'flex-start'},analysisLineText:{fontSize:12,fontFamily:'Inter_500Medium',lineHeight:17,flex:1},followTitle:{fontSize:11,fontFamily:'Inter_600SemiBold'},followText:{fontSize:11,fontFamily:'Inter_400Regular',lineHeight:16},
 deliveryRow:{flexDirection:'row',gap:10,padding:12,borderBottomWidth:StyleSheet.hairlineWidth,alignItems:'center'},cameraButton:{width:34,height:34,borderRadius:8,borderWidth:1,alignItems:'center',justifyContent:'center'}, approval:{flexDirection:'row',padding:12,borderBottomWidth:StyleSheet.hairlineWidth,gap:10},miniButton:{width:30,height:30,borderRadius:7,alignItems:'center',justifyContent:'center'}
});
